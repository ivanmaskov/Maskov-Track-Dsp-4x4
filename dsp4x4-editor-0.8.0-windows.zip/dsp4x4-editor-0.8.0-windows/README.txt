DSP 4x4 Editor 0.8.0 for Windows
=================================

Unofficial editor for the t.racks DSP 4x4 Mini, by Maskov. Not affiliated
with Thomann or t.racks. Works on Windows 10 and 11 with Microsoft Edge (built in) or
Google Chrome. No installation or drivers are needed.

Start
-----
1. Unzip this folder somewhere permanent, for example Documents.
2. Plug in the DSP and switch it on.
3. Double-click "DSP 4x4 Editor.cmd".
4. Under "Connect via" choose USB, click Connect, then pick the DSP in the
   list the browser shows and click Connect there. The browser remembers
   this permission.

You can also open dsp4x4-editor.html directly in Edge or Chrome.
Firefox can't be used: it doesn't support USB devices.

For a USB-to-RS-232 adapter choose "Serial port" instead.

Good to know
------------
- The DSP doesn't report its settings back to this editor. The editor starts
  from your last session, so press "Send all" once after connecting to make
  the DSP match the screen.
- Close the original t.racks editor first; it can keep the DSP busy.
- Presets: choose "Presets" to save your settings by name; load them again
  from the "Preset" list above the mixer. They're kept in the browser on
  this computer, so use "Export to file" to back them up.
- Compare A-E holds five complete sets of settings. Click a letter (or press
  1-5) to switch; only the settings that differ are sent to the DSP.
- Delay can be typed in milliseconds, metres or feet.
- EQ: double-click a point to reset that band; double-click empty space in
  the graph to reset the whole EQ of that output.
- Import REW (in each output's EQ): loads a filter file saved from Room EQ
  Wizard ("Save filter settings to file") into that output. Only 7 EQ bands
  are possible, so only the first 7 filters are imported; set REW to 7.
- Test signal: pink noise, white noise or a sine tone from the DSP's own
  generator. Its Volume slider works as a master on top of the Out1-Out4
  faders while it plays, so you can still balance the outputs with their
  faders. When you stop it, the outputs are back at their fader levels.
  Start with the volume low.
- To open the editor automatically when you log in, double-click
  "Start with Windows.cmd" (undo with "Stop starting with Windows.cmd").
  Once you've allowed the DSP once, the editor reconnects to it by itself.
- Phones and other computers: network access needs the Linux version of the
  editor (a browser page on Windows can't accept connections). Any device on
  the network can then use it, Windows PCs included.
- Tested and working on a real t.racks DSP 4x4 Mini.
- If the DSP doesn't appear in the browser's list, check the cable and look
  in Device Manager for "USB Input Device" with VID_0168&PID_0821.

Author and credits
------------------
Author: Maskov.
- openDSP-4x4 by glassontin (https://github.com/glassontin/opendsp-4x4):
  its USB captures of a real DSP 4x4 Mini were used to check and correct
  this editor's protocol.
- t.racks DSP 4x4 Mini Editor V1.05 (Thomann): the protocol was worked out
  from the original editor for interoperability. None of its code or
  graphics are included.
- Written with the help of Claude, an AI model by Anthropic.
No third-party code is included. MIT licence.
