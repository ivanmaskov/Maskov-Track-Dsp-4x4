@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\DSP 4x4 Editor.lnk" 2>nul
echo The DSP 4x4 Editor will no longer open when you log in.
pause
