@echo off
setlocal
set "TARGET=%~dp0DSP 4x4 Editor.cmd"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\DSP 4x4 Editor.lnk');" ^
  "$s.TargetPath=$env:TARGET;$s.WorkingDirectory=(Split-Path $env:TARGET);$s.WindowStyle=7;$s.Description='DSP 4x4 Editor';$s.Save()"
if errorlevel 1 (echo Could not create the shortcut.& pause & exit /b 1)
echo The DSP 4x4 Editor will now open when you log in to Windows.
echo Run "Stop starting with Windows.cmd" to undo this.
pause
