@echo off
setlocal
set "PAGE=%~dp0dsp4x4-editor.html"
for %%B in (
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
  "%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
) do if exist %%B (
  start "" %%B --app="%PAGE%"
  exit /b 0
)
echo Microsoft Edge or Google Chrome is needed to run the DSP 4x4 Editor.
echo Install one of them, or open dsp4x4-editor.html in it directly.
pause
