// Minimal QR code encoder (byte mode, error correction level M, versions 1–10).
// Returns a square array of booleans (true = dark), without the quiet zone.
"use strict";
const QR=(()=>{
  // per version: [ec codewords per block, [[blocks, data codewords per block], ...]]
  const EC_M=[null,[10,[[1,16]]],[16,[[1,28]]],[26,[[1,44]]],[18,[[2,32]]],[24,[[2,43]]],[16,[[4,27]]],[18,[[4,31]]],[22,[[2,38],[2,39]]],[22,[[3,36],[2,37]]],[26,[[4,43],[1,44]]]];
  const ALIGN=[null,[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50]];
  // GF(256) with polynomial 0x11D
  const EXP=new Array(512),LOG=new Array(256);
  for(let i=0,x=1;i<255;i++){EXP[i]=x;LOG[x]=i;x<<=1;if(x&256)x^=0x11d}
  for(let i=255;i<512;i++)EXP[i]=EXP[i-255];
  const mul=(a,b)=>a&&b?EXP[LOG[a]+LOG[b]]:0;
  function rsGen(n){let g=[1];for(let i=0;i<n;i++){const ng=new Array(g.length+1).fill(0);for(let j=0;j<g.length;j++){ng[j]^=g[j];ng[j+1]^=mul(g[j],EXP[i])}g=ng}return g}
  function rsRem(data,n){const g=rsGen(n),r=data.concat(new Array(n).fill(0));
    for(let i=0;i<data.length;i++){const c=r[i];if(c)for(let j=0;j<g.length;j++)r[i+j]^=mul(g[j],c)}return r.slice(data.length)}
  const dataCap=v=>EC_M[v][1].reduce((a,[b,d])=>a+b*d,0);
  function encode(text){
    const bytes=[...new TextEncoder().encode(text)];
    let v=1;while(v<=10&&4+(v<10?8:16)+8*bytes.length>8*dataCap(v))v++;
    if(v>10)throw new Error("text too long for QR");
    // bit stream
    const bits=[];const put=(val,n)=>{for(let i=n-1;i>=0;i--)bits.push((val>>>i)&1)};
    put(4,4);put(bytes.length,v<10?8:16);bytes.forEach(b=>put(b,8));
    const cap=8*dataCap(v);put(0,Math.min(4,cap-bits.length));while(bits.length%8)bits.push(0);
    const data=[];for(let i=0;i<bits.length;i+=8)data.push(parseInt(bits.slice(i,i+8).join(""),2));
    for(let p=0;data.length<dataCap(v);p^=1)data.push(p?0x11:0xec);
    // blocks + error correction, interleaved
    const [ecn,groups]=EC_M[v],blocks=[];let k=0;
    for(const [n,d] of groups)for(let i=0;i<n;i++){const b=data.slice(k,k+d);k+=d;blocks.push({d:b,e:rsRem(b,ecn)})}
    const out=[];const maxd=Math.max(...blocks.map(b=>b.d.length));
    for(let i=0;i<maxd;i++)for(const b of blocks)if(i<b.d.length)out.push(b.d[i]);
    for(let i=0;i<ecn;i++)for(const b of blocks)out.push(b.e[i]);
    // matrix
    const size=17+4*v,M=[...Array(size)].map(()=>new Array(size).fill(null)),F=[...Array(size)].map(()=>new Array(size).fill(false));
    const set=(r,c,dark)=>{M[r][c]=dark;F[r][c]=true};
    const finder=(r,c)=>{for(let i=-1;i<=7;i++)for(let j=-1;j<=7;j++){const y=r+i,x=c+j;if(y<0||x<0||y>=size||x>=size)continue;
      const on=i>=0&&i<=6&&j>=0&&j<=6&&(i===0||i===6||j===0||j===6||(i>=2&&i<=4&&j>=2&&j<=4));set(y,x,on)}};
    finder(0,0);finder(0,size-7);finder(size-7,0);
    for(let i=8;i<size-8;i++){set(6,i,i%2===0);set(i,6,i%2===0)}
    const al=ALIGN[v];
    // alignment patterns everywhere except where they'd overlap the three finder patterns
    const last=al[al.length-1];
    for(const r of al)for(const c of al){if((r===6&&c===6)||(r===6&&c===last)||(r===last&&c===6))continue;
      for(let i=-2;i<=2;i++)for(let j=-2;j<=2;j++)set(r+i,c+j,Math.max(Math.abs(i),Math.abs(j))!==1)}
    set(size-8,8,true); // dark module
    // reserve format / version areas
    for(let i=0;i<9;i++){if(!F[8][i])F[8][i]=true;if(!F[i][8])F[i][8]=true}
    for(let i=0;i<8;i++){F[8][size-1-i]=true;F[size-1-i][8]=true}
    if(v>=7)for(let i=0;i<6;i++)for(let j=0;j<3;j++){F[i][size-11+j]=true;F[size-11+j][i]=true}
    // place data
    const dbits=[];out.forEach(b=>{for(let i=7;i>=0;i--)dbits.push((b>>i)&1)});
    let bi=0,up=true;
    for(let c=size-1;c>0;c-=2){if(c===6)c--;
      for(let t=0;t<size;t++){const r=up?size-1-t:t;
        for(const x of [c,c-1])if(!F[r][x]){M[r][x]=bi<dbits.length?!!dbits[bi]:false;bi++}}
      up=!up}
    // masks
    const MASKS=[(r,c)=>(r+c)%2===0,(r)=>r%2===0,(r,c)=>c%3===0,(r,c)=>(r+c)%3===0,(r,c)=>(((r/2)|0)+((c/3)|0))%2===0,
      (r,c)=>(r*c)%2+(r*c)%3===0,(r,c)=>((r*c)%2+(r*c)%3)%2===0,(r,c)=>((r+c)%2+(r*c)%3)%2===0];
    const fmtBits=mask=>{let d=(0<<3)|mask,b=d<<10;for(let i=14;i>=10;i--)if(b>>i&1)b^=0x537<<(i-10);return((d<<10)|b)^0x5412};
    const verBits=()=>{let b=v<<12;for(let i=17;i>=12;i--)if(b>>i&1)b^=0x1f25<<(i-12);return(v<<12)|b};
    function build(mask){
      const G=M.map((row,r)=>row.map((m,c)=>F[r][c]&&!isData(r,c)?m:(m!==null?m!==MASKS[mask](r,c):false)));
      const f=fmtBits(mask);
      for(let i=0;i<15;i++){const bit=!!(f>>i&1);
        // around top-left finder
        if(i<6)G[i][8]=bit;else if(i<8)G[i+1][8]=bit;else G[size-15+i][8]=bit;
        if(i<8)G[8][size-1-i]=bit;else if(i<9)G[8][15-i]=bit;else G[8][14-i]=bit}
      G[size-8][8]=true;
      if(v>=7){const vb=verBits();for(let i=0;i<18;i++){const bit=!!(vb>>i&1),a=(i/3)|0,b=i%3;G[a][size-11+b]=bit;G[size-11+b][a]=bit}}
      return G}
    const dataMask=[...Array(size)].map(()=>new Array(size).fill(false));
    // data modules = those placed in the data pass (not function patterns)
    function isData(r,c){return dataMask[r][c]}
    // mark data modules: rerun the placement walk on F
    {let up2=true;for(let c=size-1;c>0;c-=2){if(c===6)c--;for(let t=0;t<size;t++){const r=up2?size-1-t:t;for(const x of [c,c-1])if(!F[r][x])dataMask[r][x]=true}up2=!up2}}
    function penalty(G){let p=0;
      for(let r=0;r<size;r++)for(const line of [G[r],G.map(row=>row[r])]){let run=1;for(let i=1;i<size;i++){if(line[i]===line[i-1]){run++;if(run===5)p+=3;else if(run>5)p++}else run=1}
        const s=line.map(x=>x?1:0).join("");for(const pat of ["10111010000","00001011101"]){let i=s.indexOf(pat);while(i>=0){p+=40;i=s.indexOf(pat,i+1)}}}
      for(let r=0;r<size-1;r++)for(let c=0;c<size-1;c++){const x=G[r][c];if(x===G[r][c+1]&&x===G[r+1][c]&&x===G[r+1][c+1])p+=3}
      const dark=G.flat().filter(Boolean).length;p+=Math.floor(Math.abs(dark*20-size*size*10)/(size*size))*10;
      return p}
    let best=null,bp=Infinity;for(let m=0;m<8;m++){const G=build(m),p=penalty(G);if(p<bp){bp=p;best=G}}
    return best;
  }
  // Draw into a canvas, with a 4-module quiet zone
  function draw(canvas,text,px=6){
    const G=encode(text),n=G.length+8;canvas.width=canvas.height=n*px;
    const x=canvas.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,n*px,n*px);x.fillStyle="#000";
    G.forEach((row,r)=>row.forEach((on,c)=>{if(on)x.fillRect((c+4)*px,(r+4)*px,px,px)}));
  }
  return{encode,draw};
})();
