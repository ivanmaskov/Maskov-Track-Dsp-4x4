// DSP 4x4 Editor — shared core used by the desktop editor and the phone remote.
// Pure functions only: value scales, packet encoding, state <-> commands.
"use strict";
const XO=["Bypass","Butterworth 6 dB","Bessel 6 dB","Butterworth 12 dB","Bessel 12 dB","Linkwitz-Riley 12 dB","Butterworth 18 dB","Bessel 18 dB","Butterworth 24 dB","Bessel 24 dB","Linkwitz-Riley 24 dB"];
const PEQT=["Peak","Low Shelf","High Shelf","Low Cut","High Cut","Allpass 1","Allpass 2"];
const RATIOS=["1.0","1.1","1.3","1.5","1.7","2.0","2.5","3.0","3.5","4.0","5.0","6.0","8.0","10","20","Limit"];
const IN=["InA","InB","InC","InD"], OUT=["Out1","Out2","Out3","Out4"];
const APP={name:"DSP 4x4 Editor",version:"@VERSION@",author:"Maskov"};
// Test signal generator (command 0x39, the original editor's "Input Signal Select")
const SIG=["Off","Pink noise","White noise","Sine wave"];
const SINE_HZ=[20,25,31.5,40,50,63,80,100,125,160,200,250,315,400,500,630,800,1000,1250,1600,2000,2500,3150,4000,5000,6300,8000,10000,12500,16000,20000];
const fmtSine=hz=>hz>=1000?(hz/1000)+" kHz":hz+" Hz";

// ---------- value scales (same as the DSP) ----------
const lvlDb=r=>r<80?-60+r*0.5:(r-280)/10;
const lvlRaw=db=>db< -20?Math.round((db+60)*2):Math.round(db*10)+280;
const fIdx=hz=>Math.max(0,Math.min(300,Math.round(Math.log(hz/1000)/Math.log(1.023373891996775)+170)));
const fHz=i=>1000*Math.pow(1.023373891996775,i-170);
const qIdx=q=>Math.max(0,Math.min(100,100-Math.round(Math.log(128/q)/Math.log(1.0596))));
const qVal=i=>128/Math.pow(1.0596,100-i);
const fmtHz=hz=>hz>=1000?(hz/1000).toFixed(hz>=10000?1:2)+" kHz":hz.toFixed(1)+" Hz";
const fmtDb=db=>(db>0?"+":"")+db.toFixed(1)+" dB";

// ---------- protocol (port of src/proto.rs; used when running without the server) ----------
const STANDALONE=location.protocol==="file:"||new URLSearchParams(location.search).has("standalone");
const P=(()=>{
  const rr=x=>Math.sign(x)*Math.round(Math.abs(x)); // Rust f64::round (half away from zero)
  const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
  const le=v=>[v&255,(v>>8)&255];
  const level=db=>{db=clamp(db,-60,12);return db< -20?rr((db+60)*2):rr(db*10)+280};
  const freq=hz=>clamp(rr(Math.log(hz/1000)/Math.log(1.023373891996775)+170),0,300);
  const eqg=db=>clamp(rr(db*10)+120,0,240);
  const q=v=>clamp(100-rr(Math.log(128/v)/Math.log(1.0596)),0,100);
  const thr=(db,max)=>rr(clamp(db,-90,max)*2)+180;
  const tm=(ms,lo,hi)=>clamp(Math.max(rr(ms)-1,0),lo,hi);
  const delay=ms=>clamp(rr(ms*48),0,32640);
  const chan=c=>{const t=String(c).trim().toLowerCase();let m;
    if((m=t.match(/^in([a-d])$/)))return m[1].charCodeAt(0)-97;
    if((m=t.match(/^in([1-4])$/)))return +m[1]-1;
    if((m=t.match(/^out([1-4])$/)))return +m[1]+3;
    if(/^[0-7]$/.test(t))return +t; throw new Error("unknown channel "+c)};
  const num=(o,k)=>{const v=parseFloat(o[k]);if(!isFinite(v))throw new Error(`'${k}' must be a number`);return v};
  const on=(o,k,d)=>o[k]===undefined||o[k]===""?d:["1","true","on","yes"].includes(String(o[k]).toLowerCase());
  const outOnly=ch=>{if(ch<4)throw new Error("only available on outputs (Out1..Out4)")};
  function encode(dev,cmd,data){const f=[0x10,0x02,0x00,dev,data.length+1,cmd,...data,0x10,0x03];f.push(f.reduce((a,b)=>a^b,0));return f}
  function build(o){ // same key=value form the server accepts
    if(o.type==="signal"){const src=+o.source,fr=+(o.freq??17);
      if(!(src>=0&&src<=3))throw new Error("signal source must be 0..3");if(!(fr>=0&&fr<=30))throw new Error("sine frequency index must be 0..30");
      return[0x39,[src,fr]]}
    const ch=chan(o.ch);
    switch(o.type){
      case "gain":{const db=num(o,"db");if(db< -60||db>12)throw new Error("level must be -60..+12 dB");return[0x34,[ch,...le(level(db))]]}
      case "mute":return[0x35,[ch,+on(o,"on",true)]];
      case "phase":return[0x36,[ch,+on(o,"invert",true)]];
      case "delay":outOnly(ch);return[0x38,[ch,...le(delay(num(o,"ms")))]];
      case "hpf":case "lpf":{outOnly(ch);const sl=+o.slope;if(!(sl>=0&&sl<11))throw new Error("slope index out of range");return[o.type==="hpf"?0x32:0x31,[ch,...le(freq(num(o,"hz"))),sl]]}
      case "peq":{outOnly(ch);const b=+o.band;if(!(b>=1&&b<=7))throw new Error("band must be 1..7");const k=+(o.kind||0);
        return[0x33,[ch,b-1,...le(eqg(num(o,"db"))),...le(freq(num(o,"hz"))),q(num(o,"q")),k,+on(o,"bypass",false)]]}
      case "comp":{outOnly(ch);const r=String(o.ratio).toLowerCase()==="limit"?15:RATIOS.slice(0,15).findIndex(x=>Math.abs(parseFloat(x)-parseFloat(o.ratio))<1e-6);
        if(r<0)throw new Error("bad ratio");
        return[0x30,[ch,r,+(o.knee||0),...le(tm(num(o,"attack"),0,998)),...le(tm(num(o,"release"),9,2999)),...le(thr(num(o,"threshold"),20))]]}
      case "gate":{if(ch>3)throw new Error("noise gate is only on inputs");
        return[0x3e,[ch,...le(tm(num(o,"attack"),0,998)),...le(tm(num(o,"release"),0,2999)),...le(tm(num(o,"hold"),9,998)),...le(thr(num(o,"threshold"),0))]]}
      case "route":{outOnly(ch);const m=+o.inputs;if(!(m>=0&&m<=15))throw new Error("routing mask must be 0..15");return[0x3a,[ch,m]]}
    }
    throw new Error("unknown command "+o.type);
  }
  class Parser{constructor(){this.b=[]}
    push(bytes){this.b.push(...bytes);const out=[];
      for(;;){let i=-1;for(let k=0;k+1<this.b.length;k++)if(this.b[k]===0x10&&this.b[k+1]===0x02){i=k;break}
        if(i<0){this.b=this.b.length&&this.b[this.b.length-1]===0x10?[0x10]:[];break}
        if(i>0)this.b.splice(0,i);
        if(this.b.length<5)break;
        const len=this.b[4];if(len===0){this.b.splice(0,2);continue}
        const tot=len+8;if(this.b.length<tot)break;
        const f=this.b.splice(0,tot),x=f.slice(0,-1).reduce((a,c)=>a^c,0);
        out.push(f[tot-3]===0x10&&f[tot-2]===0x03&&x===f[tot-1]?{ok:true,dev:f[2]||f[3],cmd:f[5],data:f.slice(6,tot-3)}:{ok:false,raw:f})}
      return out}}
  // documented RS-232 remote protocol: 7B 7D id cmd d1 d2 d3 7D 7B (level and mute only)
  function remote(o,dev){const ch=chan(o.ch);
    if(o.type==="gain"){const r=level(num(o,"db"));return[0x7b,0x7d,dev,ch<4?0x44:0x45,ch%4,r>>8,r&255,0x7d,0x7b]}
    if(o.type==="mute")return[0x7b,0x7d,dev,0x42,ch<4?0:1,ch%4,+on(o,"on",true),0x7d,0x7b];
    return null}
  return{encode,build,Parser,remote};
})();
const hx=b=>[...b].map(x=>x.toString(16).padStart(2,"0").toUpperCase()).join(" ");

// ---------- state ----------
// EQ bands start (and reset) flat at these frequencies, Q 1.4, Peak
const EQ_HZ=[63,160,400,1000,2500,6300,16000];
const flatBand=b=>({hz:fIdx(EQ_HZ[b]),db:0,q:qIdx(1.4),type:0,bypass:false});
function defaults(){
  return {
    inputs:IN.map(()=>({gain:280,mute:false,phase:false,gate:{thr:-90,atk:100,hold:100,rel:3000}})),
    outputs:OUT.map((_,i)=>({gain:280,mute:false,phase:false,delay:0,route:1<<i,
      hpf:{hz:fIdx(20),slope:0},lpf:{hz:fIdx(20000),slope:0},
      comp:{thr:20,ratio:0,knee:0,atk:50,rel:500},
      peq:EQ_HZ.map((_,b)=>flatBand(b))}))
  };
}
// fill in fields added in later versions
function normalize(st){st.outputs.forEach(o=>{o.eqBypass=!!o.eqBypass;o.hpf.slope=Math.min(10,o.hpf.slope|0);o.lpf.slope=Math.min(10,o.lpf.slope|0)});return st}
const clone=o=>JSON.parse(JSON.stringify(o));
function valid(j){return j&&Array.isArray(j.inputs)&&j.inputs.length===4&&Array.isArray(j.outputs)&&j.outputs.length===4&&j.outputs.every(o=>Array.isArray(o.peq)&&o.peq.length===7)}

// Level meters: 3 bytes per channel (see PROTOCOL.md)
function levelsFromData(d){
  return [0,1,2,3,4,5,6,7].map(k=>{const a=d[3*k],b=d[3*k+1],c=d[3*k+2];
    if(a===undefined||(a===255&&b===255&&c===255))return -Infinity;
    const v=b*16777216+a*65536+c*256;return v<=0?-Infinity:20*Math.log10(v*7.450580596923828e-9)+28})}

// ---------- commands from a state ----------
const chName=ch=>ch<4?IN[ch]:OUT[ch-4];
const stripOf=(st,ch)=>ch<4?st.inputs[ch]:st.outputs[ch-4];
// PEQ needs two "type" keys (command + filter type), so the filter type travels as "kind".
// "Bypass EQ" bypasses every band of an output; each band keeps its own setting.
const C={
  gain:(st,ch)=>({type:"gain",ch:chName(ch),db:lvlDb(stripOf(st,ch).gain)}),
  mute:(st,ch)=>({type:"mute",ch:chName(ch),on:+stripOf(st,ch).mute}),
  phase:(st,ch)=>({type:"phase",ch:chName(ch),invert:+stripOf(st,ch).phase}),
  gate:(st,i)=>{const g=st.inputs[i].gate;return{type:"gate",ch:IN[i],threshold:g.thr,attack:g.atk,hold:g.hold,release:g.rel}},
  route:(st,o)=>({type:"route",ch:OUT[o],inputs:st.outputs[o].route}),
  xo:(st,o,k)=>({type:k,ch:OUT[o],hz:fHz(st.outputs[o][k].hz).toFixed(2),slope:st.outputs[o][k].slope}),
  comp:(st,o)=>{const c=st.outputs[o].comp;return{type:"comp",ch:OUT[o],threshold:c.thr,ratio:RATIOS[c.ratio],knee:c.knee,attack:c.atk,release:c.rel}},
  delay:(st,o)=>({type:"delay",ch:OUT[o],ms:(st.outputs[o].delay/48).toFixed(4)}),
  peq:(st,o,b)=>{const os=st.outputs[o],p=os.peq[b];return{type:"peq",ch:OUT[o],band:b+1,hz:fHz(p.hz).toFixed(2),db:p.db.toFixed(1),q:qVal(p.q).toFixed(4),kind:p.type,bypass:+(p.bypass||!!os.eqBypass)}},
};
C.signal=g=>({type:"signal",ch:"-",source:g.source,freq:g.freq});

// Test signal state lives next to the compare slots (not in presets), so phone and computer share it.
// level: raw level (0..280 = -60..0 dB) used for Out1–Out4 while the signal plays.
function genOf(cmp){const g=(cmp&&cmp.gen)||{};
  return{source:[0,1,2,3].includes(g.source)?g.source:0,freq:Number.isInteger(g.freq)&&g.freq>=0&&g.freq<=30?g.freq:17,level:Number.isInteger(g.level)&&g.level>=0&&g.level<=280?g.level:lvlRaw(-30)}}
// The generator has no level of its own, so its volume works like a master on Out1–Out4:
// while it plays, every output level sent to the DSP is (generator volume + that output's fader),
// so the output faders still balance the outputs without moving the generator volume.
// The faders keep showing your own levels; switching the generator off sends those unchanged.
const genOutDb=(g,db)=>Math.max(-60,Math.min(12,Math.round((lvlDb(g.level)+db)*10)/10));
function genAdjust(g,p){return g.source&&p.type==="gain"&&OUT.includes(p.ch)?{...p,db:genOutDb(g,+p.db)}:p}
const genLevels=(g,st)=>[4,5,6,7].map(ch=>C.gain(st,ch));
function genCommands(g,st){return g.source?[...genLevels(g,st),C.signal(g)]:[C.signal(g),...genLevels(g,st)]}

// ---------- Room EQ Wizard (REW) filter import ----------
// Reads REW's "Save filter settings to file" text (also Equalizer APO style lines):
//   Filter  1: ON  PK       Fc   69.00 Hz  Gain  -5.30 dB  Q   7.49
// The DSP has 7 EQ bands per output, so at most the first 7 active filters are used.
const REW_TYPES={PK:0,PEQ:0,PEAK:0,MODAL:0,LS:1,LSC:1,LSQ:1,HS:2,HSC:2,HSQ:2,HP:3,HPQ:3,LP:4,LPQ:4};
function parseRew(text){
  const used=[],notes=[];let found=0,off=0;
  const num=s=>parseFloat(String(s).replace(",","."));
  for(const line of String(text).split(/\r?\n/)){
    const m=line.match(/^\s*Filter\s*(\d+)\s*:\s*(ON|OFF)\s+(\S+)(.*)$/i);if(!m)continue;
    const n=+m[1],type=m[3].toUpperCase(),rest=m[4];
    if(type==="NONE")continue;
    found++;
    if(m[2].toUpperCase()==="OFF"){off++;continue}
    if(!(type in REW_TYPES)){notes.push(`Filter ${n} (${m[3]}) skipped: the DSP has no such filter type.`);continue}
    const fm=rest.match(/Fc\s+([\d.,]+)\s*(k?)Hz/i),gm=rest.match(/Gain\s+([-+]?[\d.,]+)/i),qm=rest.match(/\bQ\s+([\d.,]+)/i);
    if(!fm){notes.push(`Filter ${n} skipped: no frequency.`);continue}
    let hz=num(fm[1])*(fm[2]?1000:1),k=REW_TYPES[type],db=gm?num(gm[1]):0,q=qm?num(qm[1]):(k===0?NaN:0.71);
    if(k===0&&!(q>0)){notes.push(`Filter ${n} skipped: no Q.`);continue}
    if(k>=3)db=0;
    if(used.length>=7){notes.push(`Filter ${n} not imported: only 7 EQ bands are available.`);continue}
    if(hz<20||hz>20000){notes.push(`Filter ${n}: ${Math.round(hz)} Hz set to ${hz<20?"20 Hz":"20 kHz"} (DSP range).`);hz=Math.min(20000,Math.max(20,hz))}
    if(Math.abs(db)>12){notes.push(`Filter ${n}: ${db.toFixed(1)} dB limited to ${db>0?"+12":"−12"} dB (DSP range).`);db=Math.sign(db)*12}
    if(q<0.4||q>128){notes.push(`Filter ${n}: Q ${q} limited to the DSP range 0.4–128.`);q=Math.min(128,Math.max(0.4,q))}
    used.push({hz:fIdx(hz),db:Math.round(db*10)/10,q:qIdx(q),type:k,bypass:false});
  }
  if(!found)throw new Error("no filters found; in REW use “Save filter settings to file” (Export) and pick that .txt file");
  if(off)notes.push(`${off} filter${off>1?"s were":" was"} switched off in REW and not imported.`);
  if(!used.length)throw new Error("none of the filters in the file can be used");
  return{bands:used,notes};
}
// Replace an output's 7 bands with the imported ones; unused bands become flat.
function applyRew(os,bands){os.peq=[0,1,2,3,4,5,6].map(b=>bands[b]?{...bands[b]}:flatBand(b))}

// Double tap (touch) or double click (mouse) on an element that also handles dragging:
// calls fn(e) when two taps land within 350 ms and 24 px without dragging in between.
function onDoubleTap(el,fn){let last=null,down=null;
  el.addEventListener("pointerdown",e=>{down={x:e.clientX,y:e.clientY}});
  el.addEventListener("pointerup",e=>{if(!down)return;const moved=Math.hypot(e.clientX-down.x,e.clientY-down.y);down=null;
    if(moved>8){last=null;return}
    const now=performance.now();
    if(last&&now-last.t<350&&Math.hypot(e.clientX-last.x,e.clientY-last.y)<24){last=null;fn(e)}else last={t:now,x:e.clientX,y:e.clientY}});
}

function allCommands(st){
  const list=[];
  for(let ch=0;ch<8;ch++)list.push(C.gain(st,ch),C.mute(st,ch),C.phase(st,ch));
  for(let i=0;i<4;i++)list.push(C.gate(st,i));
  for(let o=0;o<4;o++){list.push(C.route(st,o),C.xo(st,o,"hpf"),C.xo(st,o,"lpf"),C.comp(st,o),C.delay(st,o));
    for(let b=0;b<7;b++)list.push(C.peq(st,o,b))}
  return list;
}
const cmdKey=p=>p.type+"|"+p.ch+"|"+(p.band||"");
// Commands needed to go from state a to state b
function diffCommands(a,b){
  const before=new Map(allCommands(a).map(p=>[cmdKey(p),JSON.stringify(p)]));
  return allCommands(b).filter(p=>before.get(cmdKey(p))!==JSON.stringify(p));
}

// ---------- settings image read from the DSP (450 bytes) -> state ----------
function imageToState(img){
  const u16=i=>img[i]|img[i+1]<<8,clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
  const n={inputs:[],outputs:[]};
  for(let i=0;i<4;i++){const b=16+24*i;
    n.inputs.push({gain:u16(b+18),mute:false,phase:img[b+20]!==0,
      gate:{atk:clamp(u16(b+10)+1,1,999),rel:clamp(u16(b+12)+1,1,3000),hold:clamp(u16(b+14)+1,10,999),thr:clamp(u16(b+16)/2-90,-90,0)}})}
  for(let k=0;k<4;k++){const b=112+74*k;
    const peq=[];for(let j=0;j<7;j++){const o=b+16+6*j;peq.push({db:clamp((u16(o)-120)/10,-12,12),hz:clamp(u16(o+2),0,300),q:clamp(img[o+4],0,100),type:clamp(img[o+5],0,6),bypass:false})}
    n.outputs.push({gain:u16(b+66),mute:false,phase:img[b+68]!==0,delay:clamp(u16(b+70),0,32640),route:img[b+8]&15,eqBypass:false,
      hpf:{hz:clamp(u16(b+10),0,300),slope:clamp(img[b+14],0,10)},lpf:{hz:clamp(u16(b+12),0,300),slope:clamp(img[b+15],0,10)},
      comp:{ratio:clamp(img[b+58],0,15),knee:clamp(img[b+59],0,12),atk:clamp(u16(b+60)+1,1,999),rel:clamp(u16(b+62)+1,10,3000),thr:clamp(u16(b+64)/2-90,-90,20)},peq})}
  // sanity check before trusting the image
  const bad=img.every(b=>b===0)||[...n.inputs,...n.outputs].some(c=>c.gain>400)||[0,1,2,3].some(k=>u16(112+74*k+10)>300||u16(112+74*k+12)>300);
  if(bad)throw new Error("the settings read back don't look valid");
  return n;
}

// ---------- response curve maths (desktop graph and phone graph) ----------
const FS=48000;
function biquad(type,f,db,q){ // RBJ cookbook, returns magnitude function
  const A=Math.pow(10,db/40),w0=2*Math.PI*f/FS,c=Math.cos(w0),s=Math.sin(w0),al=s/(2*q);
  let b0,b1,b2,a0,a1,a2;
  switch(type){
    case 0:b0=1+al*A;b1=-2*c;b2=1-al*A;a0=1+al/A;a1=-2*c;a2=1-al/A;break;
    case 1:{const r=2*Math.sqrt(A)*al;b0=A*((A+1)-(A-1)*c+r);b1=2*A*((A-1)-(A+1)*c);b2=A*((A+1)-(A-1)*c-r);a0=(A+1)+(A-1)*c+r;a1=-2*((A-1)+(A+1)*c);a2=(A+1)+(A-1)*c-r;break}
    case 2:{const r=2*Math.sqrt(A)*al;b0=A*((A+1)+(A-1)*c+r);b1=-2*A*((A-1)+(A+1)*c);b2=A*((A+1)+(A-1)*c-r);a0=(A+1)-(A-1)*c+r;a1=2*((A-1)-(A+1)*c);a2=(A+1)-(A-1)*c-r;break}
    case 3:b0=(1+c)/2;b1=-(1+c);b2=(1+c)/2;a0=1+al;a1=-2*c;a2=1-al;break;
    case 4:b0=(1-c)/2;b1=1-c;b2=(1-c)/2;a0=1+al;a1=-2*c;a2=1-al;break;
    default:return()=>0;
  }
  return fr=>{const w=2*Math.PI*fr/FS,cw=Math.cos(w),sw=Math.sin(w),c2=Math.cos(2*w),s2=Math.sin(2*w);
    const nr=b0+b1*cw+b2*c2,ni=-(b1*sw+b2*s2),dr=a0+a1*cw+a2*c2,di=-(a1*sw+a2*s2);
    return 10*Math.log10((nr*nr+ni*ni)/(dr*dr+di*di))};
}
function xoMag(k,x){ // Butterworth / Linkwitz-Riley magnitude; Bessel drawn as Butterworth (shape approximation)
  if(!x.slope)return()=>0;
  const name=XO[x.slope],order=parseInt(name.match(/(\d+) dB/)[1])/6,fc=fHz(x.hz),lr=name.startsWith("Linkwitz");
  return f=>{const r=k==="hpf"?fc/f:f/fc;
    return lr? -20*Math.log10(1+Math.pow(r,order)) : -10*Math.log10(1+Math.pow(r,2*order))};
}

// ---------- delay units (48 kHz samples, sound at 343.5 m/s) ----------
const DUNIT={ms:{label:"ms",from:s=>s/48,to:v=>v*48,dp:3,max:680},m:{label:"m",from:s=>s/48000*343.5,to:v=>v/343.5*48000,dp:3,max:233.58},ft:{label:"ft",from:s=>s/48000*343.5*3.2808,to:v=>v/3.2808/343.5*48000,dp:2,max:766.33}};
const distText=v=>{const m=v/48000*343.5;return `${(v/48).toFixed(3)} ms = ${m.toFixed(3)} m = ${(m*3.2808).toFixed(2)} ft (sound at 343.5 m/s)`};
