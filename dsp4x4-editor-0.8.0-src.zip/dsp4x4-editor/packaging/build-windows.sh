#!/bin/sh
# Build the Windows package: a standalone editor page (talks to the DSP through
# Edge/Chrome's USB and serial support), a launcher and a readme, zipped.
# Run from the project root. Needs only python3.
set -eu

VERSION=$(sed -n 's/^version = "\(.*\)"/\1/p' Cargo.toml | head -1)
OUT=dist/dsp4x4-editor-${VERSION}-windows
rm -rf "$OUT" && mkdir -p "$OUT"

python3 - "$OUT" <<'EOF'
import base64, sys, pathlib
out = pathlib.Path(sys.argv[1])
html = pathlib.Path("assets/ui.html").read_text(encoding="utf-8")
html = html.replace("/*@CORE@*/", pathlib.Path("assets/core.js").read_text(encoding="utf-8"), 1)
html = html.replace("/*@QR@*/", "", 1)  # the Windows page has no network sharing
ver = next(l.split('"')[1] for l in pathlib.Path("Cargo.toml").read_text().splitlines() if l.startswith("version"))
html = html.replace("@VERSION@", ver, 1)
icon = "data:image/svg+xml;base64," + base64.b64encode(pathlib.Path("assets/dsp4x4-editor.svg").read_bytes()).decode()
assert html.count('/icon.svg') == 2, "expected the icon in <link> and <img>"
html = html.replace('"/icon.svg"', '"' + icon + '"')
(out / "dsp4x4-editor.html").write_text(html, encoding="utf-8", newline="\n")
(out / "dsp4x4-editor.svg").write_bytes(pathlib.Path("assets/dsp4x4-editor.svg").read_bytes())
EOF

# Launcher: opens the editor as an app window in Edge (preinstalled on Windows 10/11),
# or Chrome if that's all there is.
cat > "$OUT/DSP 4x4 Editor.cmd" <<'EOF'
@echo off
setlocal
set "PAGE=%~dp0dsp4x4-editor.html"
for %%B in (
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
  "%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
) do if exist %%B (
  start "" %%B --app="%PAGE%"
  exit /b 0
)
echo Microsoft Edge or Google Chrome is needed to run the DSP 4x4 Editor.
echo Install one of them, or open dsp4x4-editor.html in it directly.
pause
EOF

# Autostart: a shortcut in the user's Startup folder that runs the launcher at login
cat > "$OUT/Start with Windows.cmd" <<'WINEOF'
@echo off
setlocal
set "TARGET=%~dp0DSP 4x4 Editor.cmd"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\DSP 4x4 Editor.lnk');" ^
  "$s.TargetPath=$env:TARGET;$s.WorkingDirectory=(Split-Path $env:TARGET);$s.WindowStyle=7;$s.Description='DSP 4x4 Editor';$s.Save()"
if errorlevel 1 (echo Could not create the shortcut.& pause & exit /b 1)
echo The DSP 4x4 Editor will now open when you log in to Windows.
echo Run "Stop starting with Windows.cmd" to undo this.
pause
WINEOF

cat > "$OUT/Stop starting with Windows.cmd" <<'WINEOF'
@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\DSP 4x4 Editor.lnk" 2>nul
echo The DSP 4x4 Editor will no longer open when you log in.
pause
WINEOF

cat > "$OUT/README.txt" <<EOF
DSP 4x4 Editor ${VERSION} for Windows
=================================

Unofficial editor for the t.racks DSP 4x4 Mini, by Maskov. Not affiliated
with Thomann or t.racks. Works on Windows 10 and 11 with Microsoft Edge (built in) or
Google Chrome. No installation or drivers are needed.

Start
-----
1. Unzip this folder somewhere permanent, for example Documents.
2. Plug in the DSP and switch it on.
3. Double-click "DSP 4x4 Editor.cmd".
4. Under "Connect via" choose USB, click Connect, then pick the DSP in the
   list the browser shows and click Connect there. The browser remembers
   this permission.

You can also open dsp4x4-editor.html directly in Edge or Chrome.
Firefox can't be used: it doesn't support USB devices.

For a USB-to-RS-232 adapter choose "Serial port" instead.

Good to know
------------
- The DSP doesn't report its settings back to this editor. The editor starts
  from your last session, so press "Send all" once after connecting to make
  the DSP match the screen.
- Close the original t.racks editor first; it can keep the DSP busy.
- Presets: choose "Presets" to save your settings by name; load them again
  from the "Preset" list above the mixer. They're kept in the browser on
  this computer, so use "Export to file" to back them up.
- Compare A-E holds five complete sets of settings. Click a letter (or press
  1-5) to switch; only the settings that differ are sent to the DSP.
- Delay can be typed in milliseconds, metres or feet.
- EQ: double-click a point to reset that band; double-click empty space in
  the graph to reset the whole EQ of that output.
- Import REW (in each output's EQ): loads a filter file saved from Room EQ
  Wizard ("Save filter settings to file") into that output. Only 7 EQ bands
  are possible, so only the first 7 filters are imported; set REW to 7.
- Test signal: pink noise, white noise or a sine tone from the DSP's own
  generator. Its Volume slider works as a master on top of the Out1-Out4
  faders while it plays, so you can still balance the outputs with their
  faders. When you stop it, the outputs are back at their fader levels.
  Start with the volume low.
- To open the editor automatically when you log in, double-click
  "Start with Windows.cmd" (undo with "Stop starting with Windows.cmd").
  Once you've allowed the DSP once, the editor reconnects to it by itself.
- Phones and other computers: network access needs the Linux version of the
  editor (a browser page on Windows can't accept connections). Any device on
  the network can then use it, Windows PCs included.
- Tested and working on a real t.racks DSP 4x4 Mini.
- If the DSP doesn't appear in the browser's list, check the cable and look
  in Device Manager for "USB Input Device" with VID_0168&PID_0821.

Author and credits
------------------
Author: Maskov.
- openDSP-4x4 by glassontin (https://github.com/glassontin/opendsp-4x4):
  its USB captures of a real DSP 4x4 Mini were used to check and correct
  this editor's protocol.
- t.racks DSP 4x4 Mini Editor V1.05 (Thomann): the protocol was worked out
  from the original editor for interoperability. None of its code or
  graphics are included.
- Written with the help of Claude, an AI model by Anthropic.
No third-party code is included. MIT licence.
EOF

# Windows line endings for the .cmd and .txt
python3 - "$OUT" <<'EOF'
import sys, pathlib
for n in ("DSP 4x4 Editor.cmd", "README.txt", "Start with Windows.cmd", "Stop starting with Windows.cmd"):
    p = pathlib.Path(sys.argv[1]) / n
    p.write_bytes(p.read_bytes().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n"))
EOF

python3 - "$OUT" <<'EOF'
import sys, pathlib, zipfile
src = pathlib.Path(sys.argv[1])
z = src.parent / (src.name + ".zip")
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as f:
    for p in sorted(src.iterdir()):
        f.write(p, f"{src.name}/{p.name}")
print(z)
EOF
