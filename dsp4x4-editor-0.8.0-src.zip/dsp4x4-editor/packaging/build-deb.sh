#!/bin/sh
# Build a .deb for Debian 12+/Ubuntu 22.04+. Run from the project root.
set -eu

NAME=dsp4x4-editor
VERSION=$(sed -n 's/^version = "\(.*\)"/\1/p' Cargo.toml | head -1)
REV=1
ARCH=$(dpkg --print-architecture)
MAINTAINER=${DEB_MAINTAINER:-"ivanmaskov <ivanmaskov@gmail.com>"}

cargo build --release --locked
cargo test --release --locked --quiet

ROOT=$(mktemp -d)
trap 'rm -rf "$ROOT"' EXIT
P="$ROOT/${NAME}_${VERSION}-${REV}_${ARCH}"

install -Dm755 target/release/$NAME                 "$P/usr/bin/$NAME"
install -Dm644 packaging/70-dsp4x4-editor.rules     "$P/usr/lib/udev/rules.d/70-dsp4x4-editor.rules"
install -Dm644 packaging/$NAME.desktop              "$P/usr/share/applications/$NAME.desktop"
install -Dm644 packaging/$NAME.service              "$P/usr/lib/systemd/user/$NAME.service"
install -Dm644 assets/$NAME.svg                     "$P/usr/share/icons/hicolor/scalable/apps/$NAME.svg"
install -Dm644 README.md                            "$P/usr/share/doc/$NAME/README.md"
install -Dm644 PROTOCOL.md                          "$P/usr/share/doc/$NAME/PROTOCOL.md"
install -Dm644 LICENSE                              "$P/usr/share/doc/$NAME/copyright"
printf '%s (%s-%s) stable; urgency=medium\n\n  * Import REW: load Room EQ Wizard filter files into an output EQ (first 7 filters).\n  * Test signal: pink noise, white noise or sine from the DSP generator; its volume\n    slider is a master on top of the Out1-Out4 faders, which still balance the outputs.\n  * Double-click or double-tap the EQ to reset a band or the whole EQ.\n  * About window with author (Maskov) and credits.\n\n -- %s  %s\n' \
  "$NAME" "$VERSION" "$REV" "$MAINTAINER" "$(date -R)" | gzip -9n > "$P/usr/share/doc/$NAME/changelog.Debian.gz"
chmod 644 "$P/usr/share/doc/$NAME/changelog.Debian.gz"

# libc requirement = newest non-weak GLIBC symbol version the binary references
GLIBC=$(objdump -T target/release/$NAME | awk '$2 != "w" && /GLIBC_[0-9]/ {match($0,/GLIBC_[0-9.]+/); print substr($0,RSTART+6,RLENGTH-6)}' | sort -V | tail -1)
SIZE=$(du -ks "$P/usr" | cut -f1)

mkdir -p "$P/DEBIAN"
cat > "$P/DEBIAN/control" <<EOF
Package: $NAME
Version: $VERSION-$REV
Architecture: $ARCH
Maintainer: $MAINTAINER
Installed-Size: $SIZE
Depends: libc6 (>= $GLIBC), xdg-utils
Recommends: avahi-utils
Suggests: www-browser
Section: sound
Priority: optional
Description: unofficial editor for the t.racks DSP 4x4 Mini
 Edit input and output levels, mute, polarity, noise gates, routing,
 crossovers, 7-band parametric EQ, compressor/limiter and delay on a
 t.racks DSP 4x4 Mini loudspeaker processor over USB (level and mute
 also over RS-232). It reads the DSP's current settings when connecting.
 The editor runs locally and opens in your web browser. It can also be
 reached from phones and other computers on the local network (PIN
 protected) and can start in the background at login. A command-line
 interface is included. Not affiliated with Thomann or t.racks.
EOF

cat > "$P/DEBIAN/postinst" <<'EOF'
#!/bin/sh
set -e
if [ "$1" = configure ] && command -v udevadm >/dev/null 2>&1; then
    udevadm control --reload-rules || true
    udevadm trigger --subsystem-match=hidraw --action=change || true
fi
EOF
cat > "$P/DEBIAN/postrm" <<'EOF'
#!/bin/sh
set -e
if [ "$1" = remove ] || [ "$1" = purge ]; then
    command -v udevadm >/dev/null 2>&1 && udevadm control --reload-rules || true
fi
EOF
chmod 755 "$P/DEBIAN/postinst" "$P/DEBIAN/postrm"

mkdir -p dist
dpkg-deb --root-owner-group --build "$P" dist/ >/dev/null
echo "dist/${NAME}_${VERSION}-${REV}_${ARCH}.deb"
