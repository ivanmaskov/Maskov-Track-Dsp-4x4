//! Tiny HTTP server that hosts the editor UI (standard library only).
//!
//! By default it binds to 127.0.0.1 only. With network access switched on it
//! binds to all interfaces; other devices must then sign in with the PIN
//! (cookie token). Loopback requests check the Host header (DNS rebinding) and
//! every POST needs a custom header (blocks cross-site form posts).

use std::collections::{HashMap, VecDeque};
use std::io::{self, BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{mpsc, Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

use crate::link::{self, Kind, Link, LinkReader, Target};
use crate::params::Params;
use crate::proto::{self, Parsed};
use crate::remote;

const UI_SRC: &str = include_str!("../assets/ui.html");
const REMOTE_SRC: &str = include_str!("../assets/remote.html");
const CORE: &str = include_str!("../assets/core.js");
const LOGIN: &str = include_str!("../assets/login.html");
const MANIFEST: &str = include_str!("../assets/manifest.webmanifest");
const ICON: &str = include_str!("../assets/dsp4x4-editor.svg");

const QR_JS: &str = include_str!("../assets/qr.js");

/// Pages with the shared scripts inlined.
fn page(src: &'static str, cell: &'static std::sync::OnceLock<String>) -> &'static str {
    cell.get_or_init(|| {
        src.replacen("/*@CORE@*/", CORE, 1)
            .replacen("/*@QR@*/", QR_JS, 1)
            .replacen("@VERSION@", env!("CARGO_PKG_VERSION"), 1)
    })
}
static UI_PAGE: std::sync::OnceLock<String> = std::sync::OnceLock::new();
static REMOTE_PAGE: std::sync::OnceLock<String> = std::sync::OnceLock::new();
const LOG_MAX: usize = 400;

struct LogLine {
    id: u64,
    t: f64,
    kind: &'static str,
    text: String,
}

struct State {
    link: Option<Link>,
    generation: u64,
    dev: u8,
    log: VecDeque<LogLine>,
    next_id: u64,
    started: Instant,
    dry_run: bool,
    browser_parser: proto::Parser,
    lan: crate::lan::Settings,
    throttle: crate::lan::Throttle,
    /// Session shared between the desktop editor and phones (compare slots etc.), as JSON.
    shared: Option<String>,
    shared_rev: u64,
    /// The user disconnected on purpose: don't reconnect automatically.
    auto_paused: bool,
    port: u16,
}

impl State {
    fn log(&mut self, kind: &'static str, text: impl Into<String>) {
        let line = LogLine { id: self.next_id, t: self.started.elapsed().as_secs_f64(), kind, text: text.into() };
        self.next_id += 1;
        self.log.push_back(line);
        while self.log.len() > LOG_MAX {
            self.log.pop_front();
        }
    }
}

type Shared = Arc<Mutex<State>>;

/// Seconds since the UI last polled; used to quit after the browser tab closes.
static LAST_POLL: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

fn now_secs() -> u64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

static MDNS: Mutex<Option<std::process::Child>> = Mutex::new(None);

fn session_path() -> std::path::PathBuf {
    crate::lan::config_dir().join("session.json")
}

/// Is a dsp4x4-editor already serving on this port?
fn already_running(port: u16) -> bool {
    let Ok(mut c) = TcpStream::connect_timeout(&([127, 0, 0, 1], port).into(), Duration::from_millis(300)) else { return false };
    let _ = c.set_read_timeout(Some(Duration::from_millis(800)));
    if write!(c, "GET /api/ping HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nConnection: close\r\n\r\n").is_err() {
        return false;
    }
    let mut buf = String::new();
    let _ = c.read_to_string(&mut buf);
    buf.contains("dsp4x4-editor")
}

pub fn serve(port: u16, open_browser: bool, dry_run: bool, exit_when_idle: bool, auto_connect: bool) -> io::Result<()> {
    let reexec = std::env::var_os("DSP4X4_REEXEC").is_some();
    let open = |url: &str| {
        let _ = std::process::Command::new("xdg-open").arg(url).stdout(std::process::Stdio::null()).stderr(std::process::Stdio::null()).spawn();
    };
    if !reexec && already_running(port) {
        let url = format!("http://127.0.0.1:{port}/");
        eprintln!("dsp4x4-editor: already running at {url}");
        if open_browser {
            open(&url);
        }
        return Ok(());
    }
    let settings = crate::lan::Settings::load();
    let lan = settings.lan;
    let (listener, port) = if lan {
        let l = TcpListener::bind(("0.0.0.0", port)).map_err(|e| io::Error::new(e.kind(), format!("can't listen on port {port} for network access: {e}")))?;
        (l, port)
    } else {
        bind(port)?
    };
    let url = format!("http://127.0.0.1:{port}/");
    eprintln!("dsp4x4-editor: editor running at {url}  (Ctrl+C to quit)");
    let shared = std::fs::read_to_string(session_path()).ok().filter(|t| t.trim_start().starts_with('{'));
    let st: Shared = Arc::new(Mutex::new(State {
        link: None,
        generation: 0,
        dev: 1,
        log: VecDeque::new(),
        next_id: 1,
        started: Instant::now(),
        dry_run,
        browser_parser: proto::Parser::default(),
        lan: settings,
        throttle: Default::default(),
        shared_rev: shared.is_some() as u64,
        shared,
        auto_paused: false,
        port,
    }));
    st.lock().unwrap().log("info", if dry_run { "Dry-run mode: frames are logged, nothing is sent." } else if auto_connect { "Ready. Connecting to the DSP automatically when it's plugged in." } else { "Ready. Connect to the DSP to start." });
    if lan {
        crate::lan::spawn_discovery(port);
        *MDNS.lock().unwrap() = crate::lan::spawn_mdns(port);
        let addr = crate::lan::primary_ipv4().map(|ip| format!("http://{ip}:{port}/remote")).unwrap_or_default();
        st.lock().unwrap().log("info", format!("Network access is on. Phones: {addr}"));
        eprintln!("dsp4x4-editor: network access on; phones can open {addr}");
    }
    if open_browser && !reexec {
        open(&url);
    }
    if exit_when_idle && !lan {
        thread::spawn(|| {
            let started = now_secs();
            loop {
                thread::sleep(Duration::from_secs(5));
                let last = LAST_POLL.load(std::sync::atomic::Ordering::Relaxed);
                let idle_since = if last == 0 { started + 100 } else { last }; // allow 2 min for the browser to open
                if now_secs().saturating_sub(idle_since) > 20 {
                    eprintln!("dsp4x4-editor: editor page closed, exiting");
                    std::process::exit(0);
                }
            }
        });
    }
    if auto_connect && !dry_run {
        let st = st.clone();
        thread::spawn(move || loop {
            let idle = {
                let g = st.lock().unwrap();
                g.link.is_none() && !g.auto_paused
            };
            if idle {
                if let Some(path) = link::find_hidraw().into_iter().next() {
                    match open_link(&st, &Target::Usb(Some(path))) {
                        Ok(_) => st.lock().unwrap().log("info", "Connected to the DSP automatically."),
                        Err(e) => st.lock().unwrap().log("err", format!("Automatic connect failed: {e}")),
                    }
                }
            }
            thread::sleep(Duration::from_secs(3));
        });
    }
    for conn in listener.incoming() {
        let Ok(conn) = conn else { continue };
        let st = st.clone();
        thread::spawn(move || {
            let _ = handle(conn, st, port);
        });
    }
    Ok(())
}

/// Restart this process in place (used after switching network access on or off).
fn restart_self() {
    thread::spawn(|| {
        thread::sleep(Duration::from_millis(400));
        if let Some(mut c) = MDNS.lock().unwrap().take() {
            let _ = c.kill();
        }
        #[cfg(unix)]
        {
            use std::os::unix::process::CommandExt;
            if let Ok(exe) = std::env::current_exe() {
                let err = std::process::Command::new(exe).args(std::env::args_os().skip(1)).env("DSP4X4_REEXEC", "1").exec();
                eprintln!("dsp4x4-editor: restart failed: {err}");
            }
        }
        std::process::exit(0);
    });
}

/// Open a link, start its reader and wake the DSP. Returns the description.
fn open_link(st: &Shared, target: &Target) -> Result<(String, Kind), String> {
    let (l, r) = Link::open(target).map_err(|e| e.to_string())?;
    let (tx, rx) = mpsc::channel();
    let mut io = REPLIES.lock().unwrap();
    let mut g = st.lock().unwrap();
    g.generation += 1;
    g.auto_paused = false;
    let gen = g.generation;
    let d = l.description.clone();
    let kind = l.kind();
    g.link = Some(l);
    g.log("info", format!("Connected: {d}"));
    drop(g);
    *io = Some(rx);
    drop(io);
    spawn_reader(st.clone(), r, gen, kind, tx);
    if kind != Kind::Serial {
        wake(st);
    } else {
        st.lock().unwrap().log("info", "Over RS-232 only level and mute can be changed.");
    }
    Ok((d, kind))
}

fn bind(port: u16) -> io::Result<(TcpListener, u16)> {
    let mut last = None;
    for p in port..port.saturating_add(10) {
        match TcpListener::bind(("127.0.0.1", p)) {
            Ok(l) => return Ok((l, p)),
            Err(e) => last = Some(e),
        }
    }
    Err(last.unwrap())
}

struct Req {
    method: String,
    path: String,
    query: HashMap<String, String>,
    headers: HashMap<String, String>,
    body: Vec<u8>,
}

fn read_req(s: &TcpStream) -> io::Result<Req> {
    s.set_read_timeout(Some(Duration::from_secs(10)))?;
    let mut r = BufReader::new(s);
    let mut line = String::new();
    r.read_line(&mut line)?;
    let mut parts = line.split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let target = parts.next().unwrap_or("/").to_string();
    let mut headers = HashMap::new();
    loop {
        let mut h = String::new();
        if r.read_line(&mut h)? == 0 || h == "\r\n" || h == "\n" {
            break;
        }
        if let Some((k, v)) = h.split_once(':') {
            headers.insert(k.trim().to_ascii_lowercase(), v.trim().to_string());
        }
        if headers.len() > 64 {
            break;
        }
    }
    // body (only preset saves send one); parameters travel in the query string
    let n: usize = headers.get("content-length").and_then(|v| v.parse().ok()).unwrap_or(0);
    let mut body = Vec::new();
    if n > crate::presets::MAX_SIZE {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "body too large"));
    }
    if n > 0 {
        body = vec![0; n];
        r.read_exact(&mut body)?;
    }
    let (path, qs) = target.split_once('?').unwrap_or((&target, ""));
    Ok(Req { method, path: path.to_string(), query: parse_qs(qs), headers, body })
}

fn parse_qs(qs: &str) -> HashMap<String, String> {
    qs.split('&')
        .filter(|p| !p.is_empty())
        .map(|p| {
            let (k, v) = p.split_once('=').unwrap_or((p, ""));
            (pct(k), pct(v))
        })
        .collect()
}

fn pct(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b'+' => out.push(b' '),
            b'%' if i + 2 < b.len() => {
                let hex = std::str::from_utf8(&b[i + 1..i + 3]).ok().and_then(|h| u8::from_str_radix(h, 16).ok());
                match hex {
                    Some(v) => {
                        out.push(v);
                        i += 2;
                    }
                    None => out.push(b'%'),
                }
            }
            c => out.push(c),
        }
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn respond(s: &TcpStream, code: u16, ctype: &str, body: &str) -> io::Result<()> {
    respond_with(s, code, ctype, body, "")
}

fn respond_with(mut s: &TcpStream, code: u16, ctype: &str, body: &str, extra: &str) -> io::Result<()> {
    let reason = match code {
        200 => "OK",
        400 => "Bad Request",
        403 => "Forbidden",
        404 => "Not Found",
        405 => "Method Not Allowed",
        401 => "Unauthorized",
        409 => "Conflict",
        429 => "Too Many Requests",
        502 => "Bad Gateway",
        _ => "Error",
    };
    write!(
        s,
        "HTTP/1.1 {code} {reason}\r\nContent-Type: {ctype}\r\nContent-Length: {}\r\nCache-Control: no-store\r\n\
         X-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\nReferrer-Policy: no-referrer\r\nConnection: close\r\n{extra}\r\n{body}",
        body.len()
    )
}

fn json_str(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            '\n' => o.push_str("\\n"),
            '\r' => o.push_str("\\r"),
            '\t' => o.push_str("\\t"),
            c if (c as u32) < 0x20 => o.push_str(&format!("\\u{:04x}", c as u32)),
            c => o.push(c),
        }
    }
    o.push('"');
    o
}

fn ok(s: &TcpStream, extra: &str) -> io::Result<()> {
    respond(s, 200, "application/json", &format!("{{\"ok\":true{extra}}}"))
}

fn err(s: &TcpStream, code: u16, msg: &str) -> io::Result<()> {
    respond(s, code, "application/json", &format!("{{\"ok\":false,\"error\":{}}}", json_str(msg)))
}

fn cookie<'a>(req: &'a Req, name: &str) -> &'a str {
    req.headers
        .get("cookie")
        .and_then(|c| c.split(';').map(str::trim).find_map(|kv| kv.strip_prefix(name).and_then(|r| r.strip_prefix('='))))
        .unwrap_or("")
}

/// A Host header that is an IP literal can't be the result of DNS rebinding.
fn host_is_safe(host: &str, port: u16) -> bool {
    if host == format!("127.0.0.1:{port}") || host == format!("localhost:{port}") {
        return true;
    }
    let h = host.rsplit_once(':').map(|(h, p)| if p == port.to_string() { h } else { "" }).unwrap_or("");
    h.parse::<std::net::Ipv4Addr>().is_ok()
}

fn handle(s: TcpStream, st: Shared, port: u16) -> io::Result<()> {
    let peer = s.peer_addr()?.ip();
    let local = peer.is_loopback();
    let req = read_req(&s)?;
    let host = req.headers.get("host").map(String::as_str).unwrap_or("");
    let authed = if local {
        if !host_is_safe(host, port) {
            return err(&s, 403, "bad host");
        }
        true
    } else {
        let g = st.lock().unwrap();
        if !g.lan.lan {
            return err(&s, 403, "network access is off");
        }
        g.lan.has_token(cookie(&req, "dsp4x4"))
    };
    // available without signing in
    if req.method == "GET" {
        match req.path.as_str() {
            "/api/ping" => return respond(&s, 200, "text/plain", "dsp4x4-editor"),
            "/icon.svg" => return respond(&s, 200, "image/svg+xml", ICON),
            "/manifest.webmanifest" => return respond(&s, 200, "application/manifest+json", MANIFEST),
            _ => {}
        }
    }
    if !authed {
        if req.method == "GET" && !req.path.starts_with("/api/") {
            return respond(&s, 200, "text/html; charset=utf-8", LOGIN);
        }
        if req.method == "POST" && req.path == "/api/login" && req.headers.get("x-dsp").map(String::as_str) == Some("1") {
            let pin = req.query.get("pin").cloned().unwrap_or_default();
            let mut g = st.lock().unwrap();
            if let Some(wait) = g.throttle.blocked_for(peer) {
                return err(&s, 429, &format!("too many wrong PINs; try again in {} s", wait.as_secs() + 1));
            }
            if crate::lan::ct_eq(pin.trim().as_bytes(), g.lan.pin.as_bytes()) {
                g.throttle.ok(peer);
                let t = g.lan.new_token();
                let _ = g.lan.save();
                g.log("info", format!("A device at {peer} signed in."));
                drop(g);
                return respond_with(&s, 200, "application/json", "{\"ok\":true}", &format!("Set-Cookie: dsp4x4={t}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict\r\n"));
            }
            g.throttle.fail(peer);
            g.log("err", format!("Wrong PIN from {peer}."));
            return err(&s, 401, "wrong PIN");
        }
        return err(&s, 401, "sign in with the PIN shown in the editor on the computer");
    }
    if req.method == "GET" {
        return match req.path.as_str() {
            "/" => respond(&s, 200, "text/html; charset=utf-8", page(UI_SRC, &UI_PAGE)),
            "/remote" => respond(&s, 200, "text/html; charset=utf-8", page(REMOTE_SRC, &REMOTE_PAGE)),
            "/api/shared" => {
                let g = st.lock().unwrap();
                respond(&s, 200, "application/json", &format!("{{\"ok\":true,\"rev\":{},\"data\":{}}}", g.shared_rev, g.shared.as_deref().unwrap_or("null")))
            }
            "/api/lan" if local => {
                let g = st.lock().unwrap();
                let ip = crate::lan::primary_ipv4().map(|i| i.to_string()).unwrap_or_default();
                respond(&s, 200, "application/json", &format!(
                    "{{\"ok\":true,\"lan\":{},\"pin\":\"{}\",\"port\":{},\"ip\":{},\"host\":{},\"mdns\":{},\"autostart\":\"{}\",\"paired\":{}}}",
                    g.lan.lan, g.lan.pin, g.port, json_str(&ip), json_str(&crate::lan::hostname()), crate::lan::mdns_available(), crate::lan::autostart_status(), g.lan.tokens.len()
                ))
            }
            "/api/state" => state(&s, &st, &req),
            "/api/devices" => devices(&s),
            "/api/diagnose" => diagnose(&s),
            "/api/presets" => {
                let items: Vec<String> = crate::presets::list()
                    .iter()
                    .map(|e| format!("{{\"name\":{},\"modified\":{}}}", json_str(&e.name), e.modified))
                    .collect();
                respond(&s, 200, "application/json", &format!("{{\"ok\":true,\"dir\":{},\"presets\":[{}]}}", json_str(&crate::presets::dir().display().to_string()), items.join(",")))
            }
            "/api/preset" => match crate::presets::read(req.query.get("name").map(String::as_str).unwrap_or("")) {
                Ok(body) => respond(&s, 200, "application/json", &body),
                Err(e) => err(&s, 404, &e),
            },
            _ => err(&s, 404, "not found"),
        };
    }
    if req.method != "POST" {
        return err(&s, 405, "method not allowed");
    }
    if req.headers.get("x-dsp").map(String::as_str) != Some("1") {
        return err(&s, 403, "missing X-DSP header");
    }
    let q = |k: &str| req.query.get(k).cloned();
    match req.path.as_str() {
        "/api/connect" => {
            let target = match q("target").map(|t| Target::parse(&t)) {
                Some(Ok(t)) => t,
                Some(Err(e)) => return err(&s, 400, &e),
                None => return err(&s, 400, "missing target"),
            };
            if let Some(d) = q("dev") {
                match d.parse::<u8>() {
                    Ok(n) if (1..=250).contains(&n) => st.lock().unwrap().dev = n,
                    _ => return err(&s, 400, "device ID must be 1..250"),
                }
            }
            match open_link(&st, &target) {
                Ok((d, kind)) => ok(&s, &format!(",\"link\":{},\"kind\":\"{}\"", json_str(&d), if kind == Kind::Serial { "serial" } else { "usb" })),
                Err(e) => {
                    st.lock().unwrap().log("err", format!("Connect failed: {e}"));
                    err(&s, 409, &e)
                }
            }
        }
        "/api/shared" => {
            if req.body.is_empty() || !req.body.starts_with(b"{") {
                return err(&s, 400, "expected a JSON object");
            }
            let text = String::from_utf8_lossy(&req.body).into_owned();
            let mut g = st.lock().unwrap();
            g.shared_rev += 1;
            let rev = g.shared_rev;
            let _ = std::fs::create_dir_all(crate::lan::config_dir());
            let _ = std::fs::write(session_path(), &text);
            g.shared = Some(text);
            ok(&s, &format!(",\"rev\":{rev}"))
        }
        "/api/lan-set" if local => {
            let on = q("enable").as_deref() == Some("1");
            let mut g = st.lock().unwrap();
            g.lan.lan = on;
            if let Err(e) = g.lan.save() {
                return err(&s, 500, &format!("can't save settings: {e}"));
            }
            g.log("info", if on { "Turning network access on…" } else { "Turning network access off…" });
            drop(g);
            restart_self();
            ok(&s, "")
        }
        "/api/lan-newpin" if local => {
            let mut g = st.lock().unwrap();
            g.lan.pin = crate::lan::new_pin();
            g.lan.tokens.clear();
            let _ = g.lan.save();
            g.log("info", "New PIN made; all phones and computers have to sign in again.");
            ok(&s, "")
        }
        "/api/autostart" if local => match crate::lan::set_autostart(q("on").as_deref() == Some("1")) {
            Ok(()) => ok(&s, &format!(",\"autostart\":\"{}\"", crate::lan::autostart_status())),
            Err(e) => err(&s, 409, &format!("couldn't change autostart: {e}")),
        },
        "/api/preset-save" => match crate::presets::write(&q("name").unwrap_or_default(), &req.body) {
            Ok(()) => {
                st.lock().unwrap().log("info", format!("Saved preset “{}”", q("name").unwrap_or_default().trim()));
                ok(&s, "")
            }
            Err(e) => err(&s, 400, &e),
        },
        "/api/preset-delete" => match crate::presets::delete(&q("name").unwrap_or_default()) {
            Ok(()) => ok(&s, ""),
            Err(e) => err(&s, 400, &e),
        },
        "/api/disconnect" => {
            *REPLIES.lock().unwrap() = None;
            let mut g = st.lock().unwrap();
            g.auto_paused = true;
            g.generation += 1;
            if g.link.take().is_some() {
                g.log("info", "Disconnected.");
            }
            ok(&s, "")
        }
        "/api/dev" => match q("id").and_then(|d| d.parse::<u8>().ok()) {
            Some(n) if (1..=250).contains(&n) => {
                let mut g = st.lock().unwrap();
                g.dev = n;
                g.log("info", format!("Device ID set to {n}"));
                ok(&s, "")
            }
            _ => err(&s, 400, "device ID must be 1..250"),
        },
        "/api/send" => {
            let kind = q("type").unwrap_or_default();
            let get = |k: &str| q(k);
            let cmd = match Params::new(&get).command(&kind) {
                Ok(c) => c,
                Err(e) => return err(&s, 400, &e),
            };
            let (dev, link_kind) = {
                let g = st.lock().unwrap();
                (g.dev, g.link.as_ref().map(|l| l.kind()))
            };
            // Over RS-232 the DSP only understands the documented remote protocol.
            if link_kind == Some(Kind::Serial) {
                let r = match to_remote(&cmd) {
                    Some(r) => r,
                    None => return err(&s, 409, "over RS-232 the DSP only accepts level and mute changes; connect over USB for the rest"),
                };
                let frame = r.encode(dev);
                return reply(&s, request(&st, &frame, format!("{} (remote)  [{}]", cmd.describe(), proto::hex(&frame)), false));
            }
            let frame = cmd.encode(dev);
            reply(&s, request(&st, &frame, format!("{}  [{}]", cmd.describe(), proto::hex(&frame)), true))
        }
        "/api/readback" => {
            let dev = st.lock().unwrap().dev;
            let mut image = vec![0u8; 450];
            for i in 0..9u8 {
                let frame = proto::encode(dev, proto::cmd::READ_CHANNEL, &[i]);
                match request(&st, &frame, String::new(), true) {
                    Ok(Some(f)) if f.cmd == proto::cmd::CHANNEL_PAGE && f.data.len() >= 50 => {
                        let (idx, page) = if f.data.len() >= 51 { (f.data[0] as usize, &f.data[1..51]) } else { (i as usize, &f.data[..50]) };
                        let idx = if idx < 9 { idx } else { i as usize };
                        image[idx * 50..idx * 50 + 50].copy_from_slice(page);
                    }
                    Ok(Some(f)) => return err(&s, 502, &format!("unexpected reply 0x{:02X} while reading page {i}", f.cmd)),
                    Ok(None) => return err(&s, 409, "dry run: nothing to read"),
                    Err(e) => return err(&s, 409, &e),
                }
            }
            st.lock().unwrap().log("info", "Read the current settings from the DSP.");
            ok(&s, &format!(",\"image\":\"{}\"", proto::hex(&image).replace(' ', "")))
        }
        "/api/levels" => {
            let dev = st.lock().unwrap().dev;
            let frame = proto::encode(dev, proto::cmd::LEVELS, &[]);
            match request(&st, &frame, String::new(), true) {
                // 3 bytes per channel; decoded by the page (see levelsFromData in ui.html)
                Ok(Some(f)) if f.cmd == proto::cmd::LEVELS && f.data.len() >= 24 => {
                    ok(&s, &format!(",\"data\":\"{}\"", proto::hex(&f.data).replace(' ', "")))
                }
                Ok(_) => err(&s, 502, "no level data"),
                Err(e) => err(&s, 409, &e),
            }
        }
        // Browser USB (WebHID) mode: the page owns the device; the server only
        // builds frames and keeps the activity log.
        "/api/encode" => {
            let kind = q("type").unwrap_or_default();
            let get = |k: &str| q(k);
            let cmd = match Params::new(&get).command(&kind) {
                Ok(c) => c,
                Err(e) => return err(&s, 400, &e),
            };
            let mut g = st.lock().unwrap();
            let frame = cmd.encode(g.dev);
            let text = format!("{}  [{}]", cmd.describe(), proto::hex(&frame));
            if g.dry_run {
                g.log("tx", format!("(dry run) {text}"));
                return ok(&s, ",\"frame\":\"\"");
            }
            g.log("tx", format!("{text} via browser USB"));
            ok(&s, &format!(",\"frame\":\"{}\"", proto::hex(&frame).replace(' ', "")))
        }
        "/api/browser-log" => {
            let mut g = st.lock().unwrap();
            let msg = q("text").unwrap_or_default();
            match q("kind").as_deref() {
                Some("rx") => match proto::parse_hex(&q("hex").unwrap_or_default()) {
                    Ok(bytes) => {
                        let items = g.browser_parser.push(&bytes);
                        for item in items {
                            match item {
                                Parsed::Frame(f) => g.log("rx", format!("cmd 0x{:02X} from ID {}: {}", f.cmd, f.dev, proto::hex(&f.data))),
                                Parsed::BadChecksum(b) => g.log("err", format!("bad checksum: {}", proto::hex(&b))),
                            }
                        }
                    }
                    Err(e) => return err(&s, 400, &e),
                },
                Some("err") => g.log("err", msg.chars().take(300).collect::<String>()),
                Some("tx") => g.log("tx", format!("{} via browser", msg.chars().take(300).collect::<String>())),
                _ => g.log("info", msg.chars().take(300).collect::<String>()),
            }
            ok(&s, "")
        }
        "/api/remote" => {
            let op = q("op").unwrap_or_default();
            let get = |k: &str| q(k);
            let r = match Params::new(&get).remote(&op) {
                Ok(r) => r,
                Err(e) => return err(&s, 400, &e),
            };
            let (dev, kind) = {
                let g = st.lock().unwrap();
                (g.dev, g.link.as_ref().map(|l| l.kind()))
            };
            if kind == Some(Kind::Usb) {
                return err(&s, 409, "the documented remote protocol is for the RS-232 port; connect over serial");
            }
            let frame = r.encode(dev);
            reply(&s, request(&st, &frame, format!("remote {op}  [{}]", proto::hex(&frame)), false))
        }
        _ => err(&s, 404, "not found"),
    }
}

/// Replies from the device, forwarded by the reader thread. Holding this lock
/// also serializes requests: one outstanding request at a time.
static REPLIES: Mutex<Option<mpsc::Receiver<proto::Frame>>> = Mutex::new(None);

const REPLY_WAIT: Duration = Duration::from_millis(400);
const ATTEMPTS: usize = 3;

/// Send a frame and (if `want_reply`) wait for the device's answer, resending
/// up to 3 times. Returns Ok(None) in dry-run mode or when no reply is wanted.
fn request(st: &Shared, frame: &[u8], text: String, want_reply: bool) -> Result<Option<proto::Frame>, String> {
    let io = REPLIES.lock().unwrap();
    for attempt in 0..ATTEMPTS {
        if let Some(rx) = io.as_ref() {
            while rx.try_recv().is_ok() {}
        }
        {
            let mut g = st.lock().unwrap();
            if g.dry_run {
                if !text.is_empty() {
                    g.log("tx", format!("(dry run) {text}"));
                }
                return Ok(None);
            }
            let Some(l) = g.link.as_mut() else {
                if !text.is_empty() {
                    g.log("err", format!("Not connected — not sent: {text}"));
                }
                return Err("not connected".into());
            };
            if let Err(e) = l.send(frame) {
                g.link = None;
                g.generation += 1;
                g.log("err", format!("Send failed, disconnected: {e}"));
                return Err(e.to_string());
            }
            if attempt == 0 && !text.is_empty() {
                g.log("tx", text.clone());
            }
        }
        if !want_reply {
            return Ok(None);
        }
        let Some(rx) = io.as_ref() else { return Err("not connected".into()) };
        match rx.recv_timeout(REPLY_WAIT) {
            Ok(f) => return Ok(Some(f)),
            Err(mpsc::RecvTimeoutError::Timeout) => continue,
            Err(mpsc::RecvTimeoutError::Disconnected) => return Err("link lost".into()),
        }
    }
    let msg = format!(
        "no reply from the DSP to command 0x{:02X} (check the device ID; it's 1 unless you changed it on the DSP)",
        frame.get(5).copied().unwrap_or(0)
    );
    if !text.is_empty() {
        st.lock().unwrap().log("err", msg.clone());
    }
    Err(msg)
}

fn reply(s: &TcpStream, r: Result<Option<proto::Frame>, String>) -> io::Result<()> {
    match r {
        Ok(_) => ok(s, ""),
        Err(e) => err(s, 409, &e),
    }
}

/// Wake the DSP the way the original editor does (status, then version).
fn wake(st: &Shared) {
    let dev = st.lock().unwrap().dev;
    let status = request(st, &proto::encode(dev, proto::cmd::STATUS, &[]), String::new(), true);
    let version = request(st, &proto::encode(dev, proto::cmd::VERSION, &[]), String::new(), true);
    let mut g = st.lock().unwrap();
    match (status, version) {
        (Ok(_), Ok(Some(v))) => {
            let name: String = v.data.iter().take_while(|&&b| b != 0).map(|&b| if (0x20..0x7f).contains(&b) { b as char } else { ' ' }).collect();
            g.log("info", format!("DSP answered: {}", name.trim()));
        }
        (_, Err(e)) | (Err(e), _) => g.log("err", format!("The DSP didn't answer the wake-up query: {e}")),
        _ => {}
    }
}

/// Map an editor command to the documented RS-232 remote protocol, where possible.
fn to_remote(c: &proto::Command) -> Option<remote::Remote> {
    use proto::Command;
    let dir = |ch: u8| if ch < 4 { remote::Dir::In } else { remote::Dir::Out };
    match *c {
        Command::Gain { ch, db } => Some(remote::Remote::Volume { dir: dir(ch), ch: ch % 4, db }),
        Command::Mute { ch, on } => Some(remote::Remote::Mute { dir: dir(ch), ch: ch % 4, on }),
        _ => None,
    }
}

fn spawn_reader(st: Shared, mut r: LinkReader, gen: u64, kind: Kind, tx: mpsc::Sender<proto::Frame>) {
    thread::spawn(move || {
        let mut p = proto::Parser::default();
        let mut remote_buf: Vec<u8> = Vec::new();
        let mut buf = [0u8; 512];
        loop {
            let res = r.read(&mut buf);
            // forward replies first, without the state lock (a request may be waiting on them)
            let parsed = match &res {
                Ok(n) if *n > 0 => p.push(&buf[..*n]),
                _ => Vec::new(),
            };
            for item in &parsed {
                if let Parsed::Frame(f) = item {
                    let _ = tx.send(f.clone());
                }
            }
            let mut g = st.lock().unwrap();
            if g.generation != gen {
                return;
            }
            match res {
                Ok(0) if kind == Kind::Serial => continue,
                Ok(0) => {
                    g.link = None;
                    g.generation += 1;
                    g.log("err", "Link closed by the device.");
                    return;
                }
                Ok(n) => {
                    for item in parsed {
                        match item {
                            // meters and settings pages are frequent and bulky: don't log them
                            Parsed::Frame(f) if f.cmd == proto::cmd::LEVELS || f.cmd == proto::cmd::CHANNEL_PAGE => {}
                            Parsed::Frame(f) => {
                                let t = format!("reply 0x{:02X}: {}", f.cmd, proto::hex(&f.data));
                                g.log("rx", t);
                            }
                            Parsed::BadChecksum(b) => g.log("err", format!("bad checksum: {}", proto::hex(&b))),
                        }
                    }
                    if kind == Kind::Serial {
                        remote_buf.extend_from_slice(&buf[..n]);
                        for fr in remote::scan(&remote_buf) {
                            g.log("rx", format!("remote reply: {}", proto::hex(&fr)));
                        }
                        if remote_buf.len() > 64 {
                            let cut = remote_buf.len() - 8;
                            remote_buf.drain(..cut);
                        } else if !remote::scan(&remote_buf).is_empty() {
                            remote_buf.clear();
                        }
                    }
                }
                Err(e) if e.kind() == io::ErrorKind::Interrupted || e.kind() == io::ErrorKind::WouldBlock || e.kind() == io::ErrorKind::TimedOut => continue,
                Err(e) => {
                    g.link = None;
                    g.generation += 1;
                    g.log("err", format!("Link lost: {e}"));
                    return;
                }
            }
        }
    });
}

fn state(s: &TcpStream, st: &Shared, req: &Req) -> io::Result<()> {
    LAST_POLL.store(now_secs(), std::sync::atomic::Ordering::Relaxed);
    let after: u64 = req.query.get("after").and_then(|v| v.parse().ok()).unwrap_or(0);
    let g = st.lock().unwrap();
    let lines: Vec<String> = g
        .log
        .iter()
        .filter(|l| l.id > after)
        .map(|l| format!("{{\"id\":{},\"t\":{:.2},\"kind\":\"{}\",\"text\":{}}}", l.id, l.t, l.kind, json_str(&l.text)))
        .collect();
    let link = g.link.as_ref().map(|l| json_str(&l.description)).unwrap_or_else(|| "null".into());
    let body = format!(
        "{{\"sharedRev\":{},\"lan\":{},\"connected\":{},\"link\":{},\"dev\":{},\"dryRun\":{},\"version\":{},\"log\":[{}]}}",
        g.shared_rev,
        g.lan.lan,
        g.link.is_some(),
        link,
        g.dev,
        g.dry_run,
        json_str(env!("CARGO_PKG_VERSION")),
        lines.join(",")
    );
    respond(s, 200, "application/json", &body)
}

fn diagnose(s: &TcpStream) -> io::Result<()> {
    let items: Vec<String> = crate::diag::run()
        .iter()
        .map(|c| {
            format!(
                "{{\"ok\":{},\"title\":{},\"detail\":{},\"fix\":{}}}",
                c.ok,
                json_str(&c.title),
                json_str(&c.detail),
                c.fix.as_deref().map(json_str).unwrap_or_else(|| "null".into())
            )
        })
        .collect();
    respond(s, 200, "application/json", &format!("{{\"checks\":[{}]}}", items.join(",")))
}

fn devices(s: &TcpStream) -> io::Result<()> {
    let usb: Vec<String> = link::find_hidraw().iter().map(|p| json_str(&p.display().to_string())).collect();
    let ser: Vec<String> = link::list_serial().iter().map(|p| json_str(&p.display().to_string())).collect();
    respond(s, 200, "application/json", &format!("{{\"usb\":[{}],\"serial\":[{}]}}", usb.join(","), ser.join(",")))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn query_decoding() {
        let q = parse_qs("type=peq&ch=Out1&hz=2.5k&slope=Linkwitz-Riley%2024%20dB&x=a+b&bad=%zz");
        assert_eq!(q["slope"], "Linkwitz-Riley 24 dB");
        assert_eq!(q["x"], "a b");
        assert_eq!(q["bad"], "%zz");
        assert_eq!(q["hz"], "2.5k");
    }

    #[test]
    fn json_escaping() {
        assert_eq!(json_str("a\"b\\c\n"), "\"a\\\"b\\\\c\\n\"");
    }
}
