//! USB diagnostics: is the DSP plugged in, does it have a hidraw node, can
//! this user open it, and what report sizes does it declare.

use std::fs;
use std::path::{Path, PathBuf};

use crate::proto::{USB_PID, USB_VID};

/// Report sizes (bytes, excluding the report ID) from a HID report descriptor.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct ReportSizes {
    pub input: usize,
    pub output: usize,
    pub uses_report_ids: bool,
}

/// Minimal HID report-descriptor walk: sums Report Size × Report Count for
/// Input and Output main items (largest report per type wins).
pub fn report_sizes(desc: &[u8]) -> ReportSizes {
    use std::collections::HashMap;
    let (mut size, mut count, mut id) = (0u32, 0u32, 0u8);
    let mut stack: Vec<(u32, u32, u8)> = Vec::new();
    let mut inp: HashMap<u8, u32> = HashMap::new();
    let mut out: HashMap<u8, u32> = HashMap::new();
    let mut ids = false;
    let mut i = 0;
    while i < desc.len() {
        let b = desc[i];
        if b == 0xfe {
            // long item
            let n = *desc.get(i + 1).unwrap_or(&0) as usize;
            i += 3 + n;
            continue;
        }
        let n = match b & 3 {
            3 => 4,
            k => k as usize,
        };
        let mut v = 0u32;
        for k in 0..n {
            v |= (*desc.get(i + 1 + k).unwrap_or(&0) as u32) << (8 * k);
        }
        match b & 0xfc {
            0x74 => size = v,                // Report Size
            0x94 => count = v,               // Report Count
            0x84 => {
                id = v as u8;                // Report ID
                ids = true;
            }
            0xa4 => stack.push((size, count, id)), // Push
            0xb4 => {
                if let Some(s) = stack.pop() {
                    (size, count, id) = s;
                }
            }
            0x80 => *inp.entry(id).or_default() += size * count, // Input
            0x90 => *out.entry(id).or_default() += size * count, // Output
            _ => {}
        }
        i += 1 + n;
    }
    let bytes = |m: &HashMap<u8, u32>| m.values().map(|b| (*b as usize).div_ceil(8)).max().unwrap_or(0);
    ReportSizes { input: bytes(&inp), output: bytes(&out), uses_report_ids: ids }
}

/// Output report size for a hidraw node (falls back to 64).
pub fn output_report_len(hidraw: &Path) -> usize {
    hidraw
        .file_name()
        .map(|n| Path::new("/sys/class/hidraw").join(n).join("device/report_descriptor"))
        .and_then(|p| fs::read(p).ok())
        .map(|d| report_sizes(&d).output)
        .filter(|&n| n > 0 && n <= 1024)
        .unwrap_or(crate::proto::HID_REPORT_LEN)
}

pub struct Check {
    pub ok: bool,
    pub title: String,
    pub detail: String,
    pub fix: Option<String>,
}

fn read(p: &Path) -> String {
    fs::read_to_string(p).map(|s| s.trim().to_string()).unwrap_or_default()
}

/// USB devices on the bus with the DSP's IDs (sysfs dirs).
fn usb_devices() -> Vec<PathBuf> {
    let want_v = format!("{USB_VID:04x}");
    let want_p = format!("{USB_PID:04x}");
    let mut v: Vec<PathBuf> = fs::read_dir("/sys/bus/usb/devices")
        .into_iter()
        .flatten()
        .flatten()
        .map(|e| e.path())
        .filter(|p| read(&p.join("idVendor")) == want_v && read(&p.join("idProduct")) == want_p)
        .collect();
    v.sort();
    v
}

/// Other HID devices whose name suggests a DSP, in case a unit uses different IDs.
fn lookalikes() -> Vec<String> {
    let mut out = Vec::new();
    for e in fs::read_dir("/sys/class/hidraw").into_iter().flatten().flatten() {
        let u = read(&e.path().join("device/uevent"));
        let name = u.lines().find_map(|l| l.strip_prefix("HID_NAME=")).unwrap_or("").to_string();
        let id = u.lines().find_map(|l| l.strip_prefix("HID_ID=")).unwrap_or("").to_string();
        let l = name.to_ascii_lowercase();
        if (l.contains("dsp") || l.contains("audio") || l.contains("t.racks") || l.contains("processor")) && !id.to_ascii_uppercase().ends_with(&format!("{USB_PID:08X}")) {
            out.push(format!("/dev/{} {} ({})", e.file_name().to_string_lossy(), name, id));
        }
    }
    out
}

fn groups() -> Vec<String> {
    std::process::Command::new("id")
        .arg("-Gn")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).split_whitespace().map(String::from).collect())
        .unwrap_or_default()
}

const RULE: &str = "/usr/lib/udev/rules.d/70-dsp4x4-editor.rules";

pub fn run() -> Vec<Check> {
    let mut c = Vec::new();
    let usb = usb_devices();
    c.push(if usb.is_empty() {
        let mut detail = format!("No USB device with ID {USB_VID:04x}:{USB_PID:04x} is connected.");
        let look = lookalikes();
        if !look.is_empty() {
            detail.push_str(&format!(" Possibly related HID devices: {}.", look.join("; ")));
        }
        Check {
            ok: false,
            title: "DSP on the USB bus".into(),
            detail,
            fix: Some("Check the USB cable and that the DSP is switched on. Run `lsusb` and look for 0168:0821. If you're running Linux in a virtual machine, pass the USB device through to it.".into()),
        }
    } else {
        let p = &usb[0];
        Check {
            ok: true,
            title: "DSP on the USB bus".into(),
            detail: format!("Found {} {} ({})", read(&p.join("manufacturer")), read(&p.join("product")), p.file_name().unwrap().to_string_lossy()).replace("  ", " "),
            fix: None,
        }
    });

    let nodes = crate::link::find_hidraw();
    if !usb.is_empty() {
        c.push(if nodes.is_empty() {
            Check {
                ok: false,
                title: "HID interface".into(),
                detail: "The DSP is connected but Linux created no /dev/hidraw node for it.".into(),
                fix: Some("Unplug and replug the DSP. If it stays missing, run `sudo dmesg | tail -30` right after plugging it in and send me the output.".into()),
            }
        } else {
            Check { ok: true, title: "HID interface".into(), detail: nodes.iter().map(|p| p.display().to_string()).collect::<Vec<_>>().join(", "), fix: None }
        });
    }

    let rule = Path::new(RULE).exists() || Path::new("/etc/udev/rules.d/70-dsp4x4-editor.rules").exists();
    c.push(Check {
        ok: rule,
        title: "USB permission rule".into(),
        detail: if rule { format!("{RULE} is installed") } else { "The udev rule that lets you open the DSP without root is not installed.".into() },
        fix: (!rule).then(|| "Install the .deb package, or copy packaging/70-dsp4x4-editor.rules to /etc/udev/rules.d/ and run `sudo udevadm control --reload-rules && sudo udevadm trigger`.".into()),
    });

    for n in &nodes {
        let can = fs::OpenOptions::new().read(true).write(true).open(n);
        let sizes = n
            .file_name()
            .and_then(|f| fs::read(Path::new("/sys/class/hidraw").join(f).join("device/report_descriptor")).ok())
            .map(|d| report_sizes(&d));
        let size_txt = sizes
            .map(|s| format!(" Reports: {} bytes out, {} bytes in{}.", s.output, s.input, if s.uses_report_ids { ", numbered" } else { "" }))
            .unwrap_or_default();
        c.push(match can {
            Ok(_) => Check { ok: true, title: format!("Access to {}", n.display()), detail: format!("You can read and write it.{size_txt}"), fix: None },
            Err(e) => {
                let in_plugdev = groups().iter().any(|g| g == "plugdev");
                Check {
                    ok: false,
                    title: format!("Access to {}", n.display()),
                    detail: format!("{e}.{size_txt}"),
                    fix: Some(if e.kind() == std::io::ErrorKind::PermissionDenied {
                        format!(
                            "Unplug the DSP and plug it back in so the rule applies.{} As a quick test you can run `sudo chmod 666 {}` (lasts until the next replug).",
                            if in_plugdev { "" } else { " If that's not enough, run `sudo usermod -aG plugdev $USER`, then log out and back in." },
                            n.display()
                        )
                    } else {
                        "Unplug and replug the DSP, then try again.".into()
                    }),
                }
            }
        });
    }
    c
}

pub fn print(checks: &[Check]) -> bool {
    let mut all = true;
    for k in checks {
        all &= k.ok;
        println!("[{}] {}: {}", if k.ok { " OK " } else { "FAIL" }, k.title, k.detail);
        if let Some(f) = &k.fix {
            println!("       fix: {f}");
        }
    }
    if all {
        println!("\nEverything looks fine. Start the editor with `dsp4x4-editor`.");
    }
    all
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vendor_defined_64_byte_reports() {
        // Typical vendor HID: usage page 0xFF00, 64-byte input and output, no report IDs
        let d = [
            0x06, 0x00, 0xff, 0x09, 0x01, 0xa1, 0x01, 0x15, 0x00, 0x26, 0xff, 0x00, 0x75, 0x08, 0x95, 0x40, 0x09, 0x01,
            0x81, 0x02, 0x95, 0x40, 0x09, 0x01, 0x91, 0x02, 0xc0,
        ];
        assert_eq!(report_sizes(&d), ReportSizes { input: 64, output: 64, uses_report_ids: false });
    }

    #[test]
    fn small_output_report() {
        let d = [0x06, 0x00, 0xff, 0xa1, 0x01, 0x75, 0x08, 0x95, 0x20, 0x81, 0x02, 0x95, 0x10, 0x91, 0x02, 0xc0];
        assert_eq!(report_sizes(&d).output, 16);
        assert_eq!(report_sizes(&d).input, 32);
    }
}
