//! Preset library: one JSON file per preset in
//! $XDG_CONFIG_HOME/dsp4x4-editor/presets (default ~/.config/dsp4x4-editor/presets).

use std::fs;
use std::io;
use std::path::PathBuf;
use std::time::UNIX_EPOCH;

pub const MAX_SIZE: usize = 512 * 1024;

pub fn dir() -> PathBuf {
    let base = std::env::var_os("XDG_CONFIG_HOME")
        .map(PathBuf::from)
        .filter(|p| p.is_absolute())
        .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
        .unwrap_or_else(|| PathBuf::from("."));
    base.join("dsp4x4-editor").join("presets")
}

/// Names become file names, so only allow letters, digits and a few safe marks.
pub fn check_name(name: &str) -> Result<String, String> {
    let n = name.trim();
    if n.is_empty() {
        return Err("give the preset a name".into());
    }
    if n.chars().count() > 60 {
        return Err("preset names can be at most 60 characters".into());
    }
    if n.starts_with('.') {
        return Err("preset names can't start with a dot".into());
    }
    if let Some(c) = n.chars().find(|c| !(c.is_alphanumeric() || " _-.()+&,#'".contains(*c))) {
        return Err(format!("preset names can't contain “{c}”"));
    }
    Ok(n.to_string())
}

fn path(name: &str) -> Result<PathBuf, String> {
    Ok(dir().join(format!("{}.json", check_name(name)?)))
}

pub struct Entry {
    pub name: String,
    pub modified: u64,
}

pub fn list() -> Vec<Entry> {
    let mut v: Vec<Entry> = fs::read_dir(dir())
        .into_iter()
        .flatten()
        .flatten()
        .filter_map(|e| {
            let p = e.path();
            let name = p.file_name()?.to_str()?.strip_suffix(".json")?.to_string();
            check_name(&name).ok()?;
            let modified = e.metadata().ok()?.modified().ok()?.duration_since(UNIX_EPOCH).ok()?.as_secs();
            Some(Entry { name, modified })
        })
        .collect();
    v.sort_by(|a, b| b.modified.cmp(&a.modified).then(a.name.cmp(&b.name)));
    v
}

pub fn read(name: &str) -> Result<String, String> {
    let p = path(name)?;
    fs::read_to_string(&p).map_err(|e| if e.kind() == io::ErrorKind::NotFound { format!("there's no preset called “{}”", name.trim()) } else { e.to_string() })
}

pub fn write(name: &str, body: &[u8]) -> Result<(), String> {
    let p = path(name)?;
    if body.len() > MAX_SIZE {
        return Err("preset is too large".into());
    }
    let text = std::str::from_utf8(body).map_err(|_| "preset must be UTF-8 JSON".to_string())?;
    if !text.trim_start().starts_with('{') {
        return Err("preset must be a JSON object".into());
    }
    fs::create_dir_all(dir()).map_err(|e| format!("can't create {}: {e}", dir().display()))?;
    let tmp = p.with_extension("json.tmp");
    fs::write(&tmp, body).map_err(|e| format!("can't save: {e}"))?;
    fs::rename(&tmp, &p).map_err(|e| format!("can't save: {e}"))
}

pub fn delete(name: &str) -> Result<(), String> {
    fs::remove_file(path(name)?).map_err(|e| e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn names() {
        assert!(check_name("Club night (main)").is_ok());
        assert!(check_name("Dvorana Šibenik 2").is_ok());
        assert!(check_name("../etc/passwd").is_err());
        assert!(check_name("a/b").is_err());
        assert!(check_name(".hidden").is_err());
        assert!(check_name("   ").is_err());
        assert_eq!(check_name("  Gig  ").unwrap(), "Gig");
    }

    #[test]
    fn roundtrip_in_temp_config() {
        let d = std::env::temp_dir().join(format!("dsp4x4-presets-{}", std::process::id()));
        // only this test touches XDG_CONFIG_HOME
        std::env::set_var("XDG_CONFIG_HOME", &d);
        write("Test A", b"{\"x\":1}").unwrap();
        write("Test B", b"{\"x\":2}").unwrap();
        assert_eq!(read("Test A").unwrap(), "{\"x\":1}");
        let names: Vec<String> = list().into_iter().map(|e| e.name).collect();
        assert!(names.contains(&"Test A".to_string()) && names.contains(&"Test B".to_string()));
        assert!(write("Bad", b"[1]").is_err());
        delete("Test A").unwrap();
        assert!(read("Test A").is_err());
        fs::remove_dir_all(&d).ok();
    }
}
