//! dsp4x4-editor — unofficial Linux editor for the t.racks DSP 4x4 Mini.

mod diag;
mod lan;
mod link;
mod params;
mod presets;
mod proto;
mod remote;
mod web;

use std::collections::HashMap;
use std::process::ExitCode;
use std::time::{Duration, Instant};

use link::{Link, Target};
use params::Params;

const HELP: &str = "\
dsp4x4-editor — unofficial Linux editor for the t.racks DSP 4x4 Mini
Author: Maskov.  Credits: protocol checked against openDSP-4x4 by glassontin.

USAGE:
    dsp4x4-editor [ui] [--port N] [--no-browser] [--dry-run] [--exit-when-idle]
    dsp4x4-editor serve                  run in the background (used by autostart)
    dsp4x4-editor network [on|off|new-pin]  phones and other computers on your network
    dsp4x4-editor autostart [on|off]     start in the background when you log in
    dsp4x4-editor list
    dsp4x4-editor doctor                 check USB connection and permissions
    dsp4x4-editor send   [--link L] [--id N] [--dry-run] <command> key=value...
    dsp4x4-editor remote [--link L] [--id N] [--dry-run] <operation> key=value...

LINKS (--link, default: usb):
    usb                    first DSP found on USB (VID 0168, PID 0821)
    /dev/hidrawN           a specific USB device
    serial:/dev/ttyUSB0    RS-232 port, 115200 8N1
    tcp:HOST:PORT          network connection

CHANNELS:  InA InB InC InD  Out1 Out2 Out3 Out4

COMMANDS (send):
    gain   ch=Out1 db=-6                 level, -60..+12 dB
    mute   ch=InA on=1                   on=0 to unmute
    phase  ch=Out2 invert=1
    delay  ch=Out3 ms=2.5                0..680 ms (outputs)
    hpf    ch=Out1 hz=80 slope=\"LR 24\"   crossover high-pass (outputs)
    lpf    ch=Out4 hz=120 slope=\"BW 12\"  crossover low-pass  (outputs)
    peq    ch=Out1 band=1..7 hz=2.5k db=-3 q=1.4 [type=peak] [bypass=0]
    comp   ch=Out1 threshold=-10 ratio=4 knee=0 attack=10 release=200
    gate   ch=InA threshold=-70 attack=5 hold=100 release=300
    route  ch=Out1 inputs=A,B            which inputs feed an output
    signal source=pink                   test signal: off, pink, white, sine [hz=1k]
    raw    cmd=35 data=\"04 01\"           any command byte + payload (hex)

  Slopes: bypass, BW/Bessel 6..48, LR 12/24/36/48.  PEQ types: peak, low shelf,
  high shelf, low cut, high cut, allpass 1, allpass 2.

OPERATIONS (remote; documented RS-232 control protocol):
    volume dir=out ch=2 db=-3    up|down dir=in ch=A    mute dir=in ch=A on=1
    recall preset=U01            get-gain dir=in ch=A   get-mute dir=out ch=1
    get-preset

The editor UI runs locally in your web browser. Settings you change are sent
to the DSP immediately; use Save to keep them as a preset file.
";

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    match run(args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("dsp4x4-editor: {e}");
            ExitCode::FAILURE
        }
    }
}

struct Opts {
    link: String,
    id: u8,
    dry_run: bool,
    port: u16,
    browser: bool,
    exit_when_idle: bool,
    rest: Vec<String>,
}

fn parse_opts(args: Vec<String>) -> Result<Opts, String> {
    let mut o = Opts { link: "usb".into(), id: 1, dry_run: false, port: 8484, browser: true, exit_when_idle: false, rest: vec![] };
    let mut it = args.into_iter();
    while let Some(a) = it.next() {
        let mut val = |name: &str| it.next().ok_or_else(|| format!("{name} needs a value"));
        match a.as_str() {
            "--link" | "-l" => o.link = val("--link")?,
            "--id" => {
                o.id = val("--id")?.parse().ok().filter(|n| (1..=250).contains(n)).ok_or("--id must be 1..250")?;
            }
            "--port" => o.port = val("--port")?.parse().map_err(|_| "--port must be a number")?,
            "--dry-run" | "-n" => o.dry_run = true,
            "--no-browser" => o.browser = false,
            "--exit-when-idle" => o.exit_when_idle = true,
            _ if a.starts_with("--link=") => o.link = a[7..].into(),
            _ if a.starts_with("--id=") => o.id = a[5..].parse().ok().filter(|n| (1..=250).contains(n)).ok_or("--id must be 1..250")?,
            _ => o.rest.push(a),
        }
    }
    Ok(o)
}

fn kv(rest: &[String]) -> Result<HashMap<String, String>, String> {
    rest.iter()
        .map(|a| a.split_once('=').map(|(k, v)| (k.to_ascii_lowercase(), v.to_string())).ok_or_else(|| format!("expected key=value, got '{a}'")))
        .collect()
}

fn run(args: Vec<String>) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help" || a == "help") {
        print!("{HELP}");
        return Ok(());
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("dsp4x4-editor {} by Maskov", env!("CARGO_PKG_VERSION"));
        return Ok(());
    }
    let mut o = parse_opts(args)?;
    let sub = if o.rest.is_empty() { "ui".to_string() } else { o.rest.remove(0) };
    match sub.as_str() {
        "ui" => web::serve(o.port, o.browser, o.dry_run, o.exit_when_idle, false).map_err(|e| e.to_string()),
        // background mode (autostart): no browser, connects to the DSP by itself
        "serve" => web::serve(o.port, false, o.dry_run, false, true).map_err(|e| e.to_string()),
        "autostart" => match o.rest.first().map(String::as_str) {
            Some("on") => lan::set_autostart(true).map(|_| println!("Autostart is on: the editor starts in the background when you log in.")),
            Some("off") => lan::set_autostart(false).map(|_| println!("Autostart is off.")),
            _ => {
                println!("autostart: {}", lan::autostart_status());
                Ok(())
            }
        },
        "network" => {
            let mut s = lan::Settings::load();
            match o.rest.first().map(String::as_str) {
                Some("on") | Some("off") => {
                    s.lan = o.rest[0] == "on";
                    s.save().map_err(|e| e.to_string())?;
                    println!("Network access is {}. Restart the editor (or the autostart service) to apply.", o.rest[0]);
                }
                Some("new-pin") => {
                    s.pin = lan::new_pin();
                    s.tokens.clear();
                    s.save().map_err(|e| e.to_string())?;
                    println!("New PIN: {}", s.pin);
                }
                _ => {
                    println!("network access: {}", if s.lan { "on" } else { "off" });
                    println!("PIN: {}", s.pin);
                    if let Some(ip) = lan::primary_ipv4() {
                        println!("phones: http://{ip}:{}/remote", o.port);
                    }
                }
            }
            Ok(())
        }
        "doctor" | "check" => {
            if diag::print(&diag::run()) { Ok(()) } else { Err("some checks failed (see the fixes above)".into()) }
        }
        "list" => {
            let usb = link::find_hidraw();
            let ser = link::list_serial();
            if usb.is_empty() {
                println!("USB:    no DSP found (VID {:04x} PID {:04x})", proto::USB_VID, proto::USB_PID);
            }
            for p in usb {
                println!("USB:    {}", p.display());
            }
            for p in ser {
                println!("serial: {}", p.display());
            }
            Ok(())
        }
        "send" => {
            let kind = o.rest.first().cloned().ok_or("send needs a command; see --help")?;
            let m = kv(&o.rest[1..])?;
            let get = |k: &str| m.get(k).cloned();
            let cmd = Params::new(&get).command(&kind)?;
            let frame = cmd.encode(o.id);
            println!("{}", cmd.describe());
            println!("frame: {}", proto::hex(&frame));
            if !o.dry_run {
                send_and_listen(&o.link, &frame)?;
            }
            Ok(())
        }
        "remote" => {
            let op = o.rest.first().cloned().ok_or("remote needs an operation; see --help")?;
            let m = kv(&o.rest[1..])?;
            let get = |k: &str| m.get(k).cloned();
            let r = Params::new(&get).remote(&op)?;
            let frame = r.encode(o.id);
            println!("frame: {}", proto::hex(&frame));
            if !o.dry_run {
                if o.link == "usb" {
                    return Err("the remote protocol is for the RS-232 port: add --link serial:/dev/ttyUSB0".into());
                }
                send_and_listen(&o.link, &frame)?;
            }
            Ok(())
        }
        other => Err(format!("unknown subcommand '{other}'; see --help")),
    }
}

/// Send one frame and print anything the device answers within half a second.
fn send_and_listen(target: &str, frame: &[u8]) -> Result<(), String> {
    let t = Target::parse(target)?;
    let (mut l, mut r) = Link::open(&t).map_err(|e| e.to_string())?;
    let (tx, rx) = std::sync::mpsc::channel();
    std::thread::spawn(move || {
        let mut buf = [0u8; 512];
        while let Ok(n) = r.read(&mut buf) {
            if tx.send(buf[..n].to_vec()).is_err() {
                break;
            }
        }
    });
    let mut p = proto::Parser::default();
    let mut all = Vec::new();
    // Wait for one reply frame (up to `ms`), printing it; returns whether one arrived.
    let mut wait = |ms: u64, show: bool, all: &mut Vec<u8>| -> bool {
        let end = Instant::now() + Duration::from_millis(ms);
        while let Some(left) = end.checked_duration_since(Instant::now()) {
            let Ok(b) = rx.recv_timeout(left) else { break };
            all.extend_from_slice(&b);
            for item in p.push(&b) {
                match item {
                    proto::Parsed::Frame(f) => {
                        if show {
                            println!("reply: cmd 0x{:02X} {}", f.cmd, proto::hex(&f.data));
                        }
                        return true;
                    }
                    proto::Parsed::BadChecksum(b) => println!("reply with bad checksum: {}", proto::hex(&b)),
                }
            }
        }
        false
    };
    let serial = matches!(t, Target::Serial(_));
    if !serial && frame.len() > 3 {
        // wake the DSP like the original editor: status, then version
        let dev = frame[3];
        for c in [proto::cmd::STATUS, proto::cmd::VERSION] {
            l.send(&proto::encode(dev, c, &[])).map_err(|e| format!("send failed: {e}"))?;
            if !wait(400, false, &mut all) {
                eprintln!("dsp4x4-editor: no answer to wake-up query 0x{c:02X}");
            }
        }
    }
    let mut answered = false;
    for _ in 0..3 {
        l.send(frame).map_err(|e| format!("send failed: {e}"))?;
        if wait(400, true, &mut all) {
            answered = true;
            break;
        }
        if serial {
            break;
        }
    }
    println!("sent via {}", l.description);
    for f in remote::scan(&all) {
        println!("reply: {}", proto::hex(&f));
    }
    if !answered && !serial {
        return Err("no reply from the DSP (check the device ID with --id; default 1)".into());
    }
    Ok(())
}
