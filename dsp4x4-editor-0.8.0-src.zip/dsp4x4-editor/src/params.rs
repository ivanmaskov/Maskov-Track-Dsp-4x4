//! Turning key=value parameters (from the CLI or the web UI) into commands.

use crate::proto::{self, Command, COMP_RATIOS, PEQ_TYPES, XOVER_TYPES};
use crate::remote::{Dir, Remote};

pub struct Params<'a> {
    get: &'a dyn Fn(&str) -> Option<String>,
}

impl<'a> Params<'a> {
    pub fn new(get: &'a dyn Fn(&str) -> Option<String>) -> Self {
        Params { get }
    }

    fn raw(&self, k: &str) -> Result<String, String> {
        (self.get)(k).filter(|v| !v.is_empty()).ok_or_else(|| format!("missing '{k}'"))
    }

    fn opt(&self, k: &str) -> Option<String> {
        (self.get)(k).filter(|v| !v.is_empty())
    }

    pub fn f64(&self, k: &str) -> Result<f64, String> {
        let v = self.raw(k)?;
        let t = v.trim().trim_end_matches(|c: char| c.is_ascii_alphabetic()).trim();
        let mul = if v.trim().to_ascii_lowercase().ends_with("khz") || v.trim().to_ascii_lowercase().ends_with('k') { 1000.0 } else { 1.0 };
        t.parse::<f64>()
            .ok()
            .filter(|x| x.is_finite())
            .map(|x| x * mul)
            .ok_or_else(|| format!("'{k}' must be a number, got '{v}'"))
    }

    pub fn u8(&self, k: &str) -> Result<u8, String> {
        let v = self.raw(k)?;
        v.trim().parse::<u8>().map_err(|_| format!("'{k}' must be a whole number 0..255, got '{v}'"))
    }

    pub fn bool(&self, k: &str, default: Option<bool>) -> Result<bool, String> {
        match self.opt(k) {
            None => default.ok_or_else(|| format!("missing '{k}'")),
            Some(v) => match v.trim().to_ascii_lowercase().as_str() {
                "1" | "true" | "on" | "yes" | "invert" | "inverted" | "mute" | "muted" => Ok(true),
                "0" | "false" | "off" | "no" | "normal" | "unmute" => Ok(false),
                _ => Err(format!("'{k}' must be on/off, got '{v}'")),
            },
        }
    }

    pub fn channel(&self) -> Result<u8, String> {
        let v = self.raw("ch")?;
        proto::parse_channel(&v).ok_or_else(|| format!("unknown channel '{v}' (use InA..InD, Out1..Out4 or 0..7)"))
    }

    fn index_or_name(&self, k: &str, names: &[&str]) -> Result<u8, String> {
        let v = self.raw(k)?;
        if let Ok(n) = v.trim().parse::<usize>() {
            if n < names.len() {
                return Ok(n as u8);
            }
        }
        let canon = |s: &str| {
            s.to_ascii_lowercase()
                .replace([' ', '-', '/', '_', '.'], "")
                .replace("butterworth", "bw")
                .replace("butter", "bw")
                .replace("linkwitzriley", "lr")
                .replace("linkr", "lr")
                .replace("db", "")
        };
        let want = canon(&v);
        names
            .iter()
            .position(|n| canon(n) == want)
            .map(|i| i as u8)
            .ok_or_else(|| format!("unknown {k} '{v}'; one of: {}", names.join(", ")))
    }

    /// Compressor ratio given as its value ("4", "4:1", "2.5") or "limit".
    fn ratio(&self) -> Result<u8, String> {
        let v = self.raw("ratio")?;
        let t = v.trim().to_ascii_lowercase();
        let t = t.trim_end_matches(":1");
        if t == "limit" || t == "limiter" || t == "inf" {
            return Ok(15);
        }
        let x: f64 = t.parse().map_err(|_| format!("ratio must be one of {} or limit", COMP_RATIOS[..15].join(", ")))?;
        COMP_RATIOS[..15]
            .iter()
            .position(|r| (r.parse::<f64>().unwrap() - x).abs() < 1e-6)
            .map(|i| i as u8)
            .ok_or_else(|| format!("ratio must be one of {} or limit", COMP_RATIOS[..15].join(", ")))
    }

    pub fn command(&self, kind: &str) -> Result<Command, String> {
        let c = match kind.to_ascii_lowercase().as_str() {
            "gain" | "level" | "volume" => Command::Gain { ch: self.channel()?, db: self.f64("db")? },
            "mute" => Command::Mute { ch: self.channel()?, on: self.bool("on", Some(true))? },
            "phase" | "polarity" => Command::Phase { ch: self.channel()?, invert: self.bool("invert", Some(true))? },
            "delay" => Command::Delay { ch: self.channel()?, ms: self.f64("ms")? },
            "hpf" | "highpass" => Command::HighPass { ch: self.channel()?, hz: self.f64("hz")?, slope: self.index_or_name("slope", &XOVER_TYPES)? },
            "lpf" | "lowpass" => Command::LowPass { ch: self.channel()?, hz: self.f64("hz")?, slope: self.index_or_name("slope", &XOVER_TYPES)? },
            "peq" | "eq" => {
                let band = self.u8("band")?;
                if !(1..=proto::PEQ_BANDS).contains(&band) {
                    return Err(format!("band must be 1..{}", proto::PEQ_BANDS));
                }
                Command::Peq {
                    ch: self.channel()?,
                    band: band - 1,
                    hz: self.f64("hz")?,
                    db: self.f64("db")?,
                    q: self.f64("q")?,
                    // CLI: type=low-shelf; web UI: kind=1 (there "type" names the command)
                    kind: if self.opt("kind").is_some() {
                        self.index_or_name("kind", &PEQ_TYPES)?
                    } else if self.opt("type").is_some_and(|t| !matches!(t.to_ascii_lowercase().as_str(), "peq" | "eq")) {
                        self.index_or_name("type", &PEQ_TYPES)?
                    } else {
                        0
                    },
                    bypass: self.bool("bypass", Some(false))?,
                }
            }
            "comp" | "compressor" | "limiter" => Command::Compressor {
                ch: self.channel()?,
                ratio: self.ratio()?,
                knee_db: self.u8("knee").or_else(|_| if self.opt("knee").is_none() { Ok(0) } else { Err("bad knee".to_string()) })?,
                attack_ms: self.f64("attack")?,
                release_ms: self.f64("release")?,
                threshold_db: self.f64("threshold")?,
            },
            "gate" => Command::Gate {
                ch: self.channel()?,
                attack_ms: self.f64("attack")?,
                hold_ms: self.f64("hold")?,
                release_ms: self.f64("release")?,
                threshold_db: self.f64("threshold")?,
            },
            "route" | "routing" | "matrix" => {
                let v = self.raw("inputs")?;
                let mask = parse_inputs(&v)?;
                Command::Routing { ch: self.channel()?, mask }
            }
            "signal" | "noise" | "generator" | "test" => {
                let src = self.opt("source").unwrap_or_else(|| "analog".into());
                let source = match src.trim().to_ascii_lowercase().as_str() {
                    "0" | "off" | "analog" | "analog input" | "input" => 0,
                    "1" | "pink" | "pink noise" => 1,
                    "2" | "white" | "white noise" => 2,
                    "3" | "sine" | "sine wave" | "tone" => 3,
                    _ => return Err("source must be off, pink, white or sine".into()),
                };
                let freq = match (self.opt("freq"), self.opt("hz")) {
                    (Some(i), _) => i.trim().parse::<u8>().map_err(|_| "freq must be an index 0..30".to_string())?,
                    (None, Some(_)) => {
                        let hz = self.f64("hz")?;
                        if !(19.0..=20500.0).contains(&hz) {
                            return Err("sine frequency must be 20 Hz..20 kHz".into());
                        }
                        proto::sine_index(hz)
                    }
                    (None, None) => proto::sine_index(1000.0),
                };
                Command::Signal { source, freq }
            }
            "raw" => {
                let c = self.raw("cmd")?;
                let cmd = u8::from_str_radix(c.trim().trim_start_matches("0x"), 16).map_err(|_| "cmd must be a hex byte".to_string())?;
                let data = proto::parse_hex(&self.opt("data").unwrap_or_default())?;
                Command::Raw { cmd, data }
            }
            other => return Err(format!("unknown command '{other}'")),
        };
        // range checks on numeric inputs that would otherwise be clamped silently
        match &c {
            Command::Gain { db, .. } if !(-60.0..=12.0).contains(db) => return Err("level must be -60..+12 dB".into()),
            Command::Delay { ms, .. } if !(0.0..=680.0).contains(ms) => return Err("delay must be 0..680 ms".into()),
            Command::HighPass { hz, .. } | Command::LowPass { hz, .. } if !(19.0..=20500.0).contains(hz) => return Err("frequency must be 20 Hz..20 kHz".into()),
            Command::Peq { hz, db, q, .. } => {
                if !(19.0..=20500.0).contains(hz) {
                    return Err("frequency must be 20 Hz..20 kHz".into());
                }
                if !(-12.0..=12.0).contains(db) {
                    return Err("EQ gain must be -12..+12 dB".into());
                }
                if !(0.39..=128.0).contains(q) {
                    return Err("Q must be 0.4..128".into());
                }
            }
            Command::Compressor { threshold_db, attack_ms, release_ms, .. } => {
                if !(-90.0..=20.0).contains(threshold_db) { return Err("threshold must be -90..+20 dB".into()); }
                if !(1.0..=999.0).contains(attack_ms) { return Err("attack must be 1..999 ms".into()); }
                if !(10.0..=3000.0).contains(release_ms) { return Err("release must be 10..3000 ms".into()); }
            }
            Command::Gate { threshold_db, attack_ms, hold_ms, release_ms, .. } => {
                if !(-90.0..=0.0).contains(threshold_db) { return Err("threshold must be -90..0 dB".into()); }
                if !(1.0..=999.0).contains(attack_ms) { return Err("attack must be 1..999 ms".into()); }
                if !(10.0..=999.0).contains(hold_ms) { return Err("hold must be 10..999 ms".into()); }
                if !(1.0..=3000.0).contains(release_ms) { return Err("release must be 1..3000 ms".into()); }
            }
            _ => {}
        }
        c.validate()?;
        Ok(c)
    }

    pub fn remote(&self, op: &str) -> Result<Remote, String> {
        let dir = || -> Result<Dir, String> {
            match self.raw("dir")?.to_ascii_lowercase().as_str() {
                "in" | "input" => Ok(Dir::In),
                "out" | "output" => Ok(Dir::Out),
                v => Err(format!("dir must be in or out, got '{v}'")),
            }
        };
        let ch = || -> Result<u8, String> {
            let v = self.raw("ch")?;
            let t = v.trim().to_ascii_lowercase();
            let t = t.trim_start_matches("in").trim_start_matches("out");
            match t {
                "a" | "1" => Ok(0),
                "b" | "2" => Ok(1),
                "c" | "3" => Ok(2),
                "d" | "4" => Ok(3),
                _ => Err(format!("channel must be A..D or 1..4, got '{v}'")),
            }
        };
        let r = match op {
            "volume" => {
                let db = self.f64("db")?;
                if !(-60.0..=12.0).contains(&db) {
                    return Err("level must be -60..+12 dB".into());
                }
                Remote::Volume { dir: dir()?, ch: ch()?, db }
            }
            "up" | "down" => Remote::GainStep { dir: dir()?, ch: ch()?, down: op == "down" },
            "mute" => Remote::Mute { dir: dir()?, ch: ch()?, on: self.bool("on", Some(true))? },
            "recall" => {
                let p = self.raw("preset")?.to_ascii_uppercase();
                if p == "F00" || p == "F" || p == "FACTORY" {
                    Remote::Recall { user: false, preset: 0 }
                } else {
                    let n: u8 = p.trim_start_matches('U').parse().map_err(|_| "preset must be F00 or U01..U30".to_string())?;
                    Remote::Recall { user: true, preset: n }
                }
            }
            "get-gain" => Remote::GetGain { dir: dir()?, ch: ch()? },
            "get-mute" => Remote::GetMute { dir: dir()?, ch: ch()? },
            "get-preset" => Remote::GetPreset,
            other => return Err(format!("unknown remote operation '{other}'")),
        };
        r.validate()?;
        Ok(r)
    }
}

/// "A,C", "InA+InB", "ac", "none", or a number 0..15.
pub fn parse_inputs(v: &str) -> Result<u8, String> {
    let t = v.trim().to_ascii_lowercase();
    if t == "none" || t == "-" {
        return Ok(0);
    }
    if let Ok(n) = t.parse::<u8>() {
        return if n <= 15 { Ok(n) } else { Err("routing mask must be 0..15".into()) };
    }
    let mut m = 0;
    for c in t.replace("in", "").chars() {
        match c {
            'a'..='d' => m |= 1 << (c as u8 - b'a'),
            ',' | '+' | ' ' => {}
            _ => return Err(format!("inputs must be letters A..D, got '{v}'")),
        }
    }
    Ok(m)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    fn cmd(kind: &str, kv: &[(&str, &str)]) -> Result<Command, String> {
        let m: HashMap<String, String> = kv.iter().map(|(k, v)| (k.to_string(), v.to_string())).collect();
        let f = move |k: &str| m.get(k).cloned();
        Params::new(&f).command(kind)
    }

    #[test]
    fn parses_signal() {
        assert_eq!(cmd("signal", &[("source", "pink")]).unwrap(), Command::Signal { source: 1, freq: 17 });
        assert_eq!(cmd("signal", &[("source", "sine"), ("hz", "100")]).unwrap(), Command::Signal { source: 3, freq: 7 });
        assert_eq!(cmd("signal", &[("source", "3"), ("freq", "30")]).unwrap(), Command::Signal { source: 3, freq: 30 });
        assert_eq!(cmd("noise", &[("source", "off")]).unwrap(), Command::Signal { source: 0, freq: 17 });
        assert!(cmd("signal", &[("source", "brown")]).is_err());
        assert!(cmd("signal", &[("source", "sine"), ("freq", "31")]).is_err());
    }

    #[test]
    fn parses_commands() {
        assert_eq!(cmd("gain", &[("ch", "Out2"), ("db", "-3")]).unwrap(), Command::Gain { ch: 5, db: -3.0 });
        assert_eq!(
            cmd("peq", &[("ch", "Out1"), ("band", "3"), ("hz", "2.5k"), ("db", "-4"), ("q", "1.4"), ("type", "low shelf")]).unwrap(),
            Command::Peq { ch: 4, band: 2, hz: 2500.0, db: -4.0, q: 1.4, kind: 1, bypass: false }
        );
        assert_eq!(cmd("hpf", &[("ch", "Out4"), ("hz", "80"), ("slope", "LR 24")]).unwrap(), Command::HighPass { ch: 7, hz: 80.0, slope: 10 });
        assert_eq!(cmd("lpf", &[("ch", "Out1"), ("hz", "3k"), ("slope", "BUTTER-12dB")]).unwrap(), Command::LowPass { ch: 4, hz: 3000.0, slope: 3 });
        assert!(cmd("hpf", &[("ch", "Out4"), ("hz", "80"), ("slope", "steep")]).is_err());
        assert_eq!(
            cmd("hpf", &[("ch", "Out4"), ("hz", "80"), ("slope", "Linkwitz-Riley 24 dB")]).unwrap(),
            Command::HighPass { ch: 7, hz: 80.0, slope: 10 }
        );
        assert_eq!(cmd("hpf", &[("ch", "Out4"), ("hz", "80"), ("slope", "10")]).unwrap(), Command::HighPass { ch: 7, hz: 80.0, slope: 10 });
        // web UI form: type=peq is the command, kind= the filter
        assert_eq!(
            cmd("peq", &[("type", "peq"), ("ch", "Out2"), ("band", "7"), ("hz", "16000"), ("db", "2"), ("q", "0.7"), ("kind", "2"), ("bypass", "1")]).unwrap(),
            Command::Peq { ch: 5, band: 6, hz: 16000.0, db: 2.0, q: 0.7, kind: 2, bypass: true }
        );
        assert_eq!(cmd("route",&[("ch", "Out3"), ("inputs", "A,C")]).unwrap(), Command::Routing { ch: 6, mask: 0b101 });
        assert!(cmd("gain", &[("ch", "Out2"), ("db", "20")]).is_err());
        assert!(cmd("delay", &[("ch", "InA"), ("ms", "2")]).is_err());
        assert_eq!(
            cmd("comp", &[("ch", "Out1"), ("ratio", "limit"), ("attack", "5"), ("release", "100"), ("threshold", "-10")]).unwrap(),
            Command::Compressor { ch: 4, ratio: 15, knee_db: 0, attack_ms: 5.0, release_ms: 100.0, threshold_db: -10.0 }
        );
        let comp = |r: &str| match cmd("comp", &[("ch", "Out1"), ("ratio", r), ("attack", "5"), ("release", "100"), ("threshold", "-10")]) {
            Ok(Command::Compressor { ratio, .. }) => Ok(ratio),
            Ok(_) => unreachable!(),
            Err(e) => Err(e),
        };
        assert_eq!(comp("10").unwrap(), 13);
        assert_eq!(comp("4:1").unwrap(), 9);
        assert_eq!(comp("2.5").unwrap(), 6);
        assert!(comp("7").is_err());
        assert_eq!(cmd("raw", &[("cmd", "0x35"), ("data", "04 01")]).unwrap(), Command::Raw { cmd: 0x35, data: vec![4, 1] });
    }

    #[test]
    fn inputs() {
        assert_eq!(parse_inputs("InA+InD").unwrap(), 0b1001);
        assert_eq!(parse_inputs("none").unwrap(), 0);
        assert!(parse_inputs("e").is_err());
    }
}
