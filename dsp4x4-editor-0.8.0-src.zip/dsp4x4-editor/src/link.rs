//! Transports: USB HID (Linux hidraw), RS-232 serial (termios) and TCP.
//! Standard library only; termios is reached through glibc via FFI.

use std::fs::{self, OpenOptions};
use std::io::{self, Read, Write};
use std::net::{TcpStream, ToSocketAddrs};
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use crate::proto::{HID_REPORT_LEN, USB_PID, USB_VID};
#[allow(unused_imports)]
use crate::diag;

/// Where to connect.
#[derive(Debug, Clone, PartialEq)]
pub enum Target {
    /// First matching hidraw node, or an explicit /dev/hidrawN.
    Usb(Option<PathBuf>),
    Serial(PathBuf),
    Tcp(String),
}

impl Target {
    /// "usb", "usb:/dev/hidraw3", "serial:/dev/ttyUSB0", "/dev/ttyUSB0", "tcp:192.168.1.101:5000"
    pub fn parse(s: &str) -> Result<Target, String> {
        let s = s.trim();
        if s == "usb" {
            return Ok(Target::Usb(None));
        }
        if let Some(p) = s.strip_prefix("usb:") {
            return Ok(Target::Usb(Some(p.into())));
        }
        if let Some(p) = s.strip_prefix("serial:") {
            return Ok(Target::Serial(p.into()));
        }
        if let Some(h) = s.strip_prefix("tcp:") {
            if !h.contains(':') {
                return Err("tcp target needs host:port".into());
            }
            return Ok(Target::Tcp(h.into()));
        }
        if s.starts_with("/dev/hidraw") {
            return Ok(Target::Usb(Some(s.into())));
        }
        if s.starts_with("/dev/") {
            return Ok(Target::Serial(s.into()));
        }
        Err(format!("unknown link '{s}' (use usb, serial:/dev/ttyUSB0 or tcp:host:port)"))
    }
}

pub struct Link {
    kind: Kind,
    writer: Box<dyn Write + Send>,
    last_write: Instant,
    /// USB output report size in bytes (without the report ID byte).
    report_len: usize,
    pub description: String,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    Usb,
    Serial,
    Tcp,
}

/// The reading half, handed to a background thread.
pub struct LinkReader(Box<dyn Read + Send>);

impl LinkReader {
    pub fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        self.0.read(buf)
    }
}

/// Minimum spacing between frames (the device documentation asks for >= 20 ms).
const MIN_GAP: Duration = Duration::from_millis(20);

impl Link {
    pub fn open(t: &Target) -> io::Result<(Link, LinkReader)> {
        match t {
            Target::Usb(path) => {
                let path = match path {
                    Some(p) => p.clone(),
                    None => find_hidraw().into_iter().next().ok_or_else(|| {
                        io::Error::new(
                            io::ErrorKind::NotFound,
                            format!(
                                "no DSP found on USB (looking for {USB_VID:04x}:{USB_PID:04x}); \
                                 check the cable and that the udev rule is installed"
                            ),
                        )
                    })?,
                };
                let f = OpenOptions::new().read(true).write(true).open(&path).map_err(|e| perm_hint(e, &path))?;
                let r = f.try_clone()?;
                let report_len = diag::output_report_len(&path);
                Ok((
                    Link { kind: Kind::Usb, writer: Box::new(f), last_write: Instant::now() - MIN_GAP, report_len, description: format!("USB {} ({report_len}-byte reports)", path.display()) },
                    LinkReader(Box::new(r)),
                ))
            }
            Target::Serial(path) => {
                let f = OpenOptions::new().read(true).write(true).open(path).map_err(|e| perm_hint(e, path))?;
                termios::configure(&f, crate::remote::BAUD)?;
                let r = f.try_clone()?;
                Ok((
                    Link { kind: Kind::Serial, writer: Box::new(f), last_write: Instant::now() - MIN_GAP, report_len: HID_REPORT_LEN, description: format!("serial {} 115200 8N1", path.display()) },
                    LinkReader(Box::new(r)),
                ))
            }
            Target::Tcp(hp) => {
                let addr = hp
                    .to_socket_addrs()?
                    .next()
                    .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "cannot resolve address"))?;
                let s = TcpStream::connect_timeout(&addr, Duration::from_secs(3))?;
                s.set_nodelay(true)?;
                let r = s.try_clone()?;
                Ok((
                    Link { kind: Kind::Tcp, writer: Box::new(s), last_write: Instant::now() - MIN_GAP, report_len: HID_REPORT_LEN, description: format!("TCP {addr}") },
                    LinkReader(Box::new(r)),
                ))
            }
        }
    }

    pub fn kind(&self) -> Kind {
        self.kind
    }

    /// Send one frame. USB frames are split into output reports (size taken from
    /// the device's report descriptor) with report ID 0, zero-padded, like the
    /// Windows editor does.
    pub fn send(&mut self, frame: &[u8]) -> io::Result<()> {
        let since = self.last_write.elapsed();
        if since < MIN_GAP {
            std::thread::sleep(MIN_GAP - since);
        }
        match self.kind {
            Kind::Usb => {
                for chunk in frame.chunks(self.report_len) {
                    let mut report = vec![0u8; self.report_len + 1];
                    report[1..1 + chunk.len()].copy_from_slice(chunk);
                    self.writer.write_all(&report).map_err(|e| {
                        io::Error::new(e.kind(), format!("USB write of {} bytes failed: {e}", report.len()))
                    })?;
                }
            }
            _ => self.writer.write_all(frame)?,
        }
        self.writer.flush()?;
        self.last_write = Instant::now();
        Ok(())
    }
}

fn perm_hint(e: io::Error, p: &Path) -> io::Error {
    if e.kind() == io::ErrorKind::PermissionDenied {
        io::Error::new(
            e.kind(),
            format!(
                "permission denied opening {}: reconnect the DSP after installing the package \
                 (the udev rule grants access), or add yourself to the 'dialout' group for serial ports. \
                 Run `dsp4x4-editor doctor` for a full check",
                p.display()
            ),
        )
    } else {
        io::Error::new(e.kind(), format!("{}: {e}", p.display()))
    }
}

/// hidraw nodes whose HID_ID matches the DSP.
pub fn find_hidraw() -> Vec<PathBuf> {
    find_hidraw_in(Path::new("/sys/class/hidraw"))
}

pub fn find_hidraw_in(sys: &Path) -> Vec<PathBuf> {
    let want = format!(":{:08X}:{:08X}", USB_VID, USB_PID);
    let mut out: Vec<PathBuf> = fs::read_dir(sys)
        .into_iter()
        .flatten()
        .flatten()
        .filter(|e| {
            fs::read_to_string(e.path().join("device/uevent"))
                .map(|u| u.lines().any(|l| l.starts_with("HID_ID=") && l.to_ascii_uppercase().ends_with(&want)))
                .unwrap_or(false)
        })
        .map(|e| Path::new("/dev").join(e.file_name()))
        .collect();
    out.sort();
    out
}

/// Candidate serial ports.
pub fn list_serial() -> Vec<PathBuf> {
    let mut v: Vec<PathBuf> = fs::read_dir("/dev")
        .into_iter()
        .flatten()
        .flatten()
        .map(|e| e.path())
        .filter(|p| {
            let n = p.file_name().and_then(|n| n.to_str()).unwrap_or("");
            n.starts_with("ttyUSB") || n.starts_with("ttyACM")
        })
        .collect();
    if let Ok(rd) = fs::read_dir("/dev/serial/by-id") {
        for e in rd.flatten() {
            v.push(e.path());
        }
    }
    v.sort();
    v
}

mod termios {
    use std::fs::File;
    use std::io;
    use std::os::raw::c_int;
    use std::os::unix::io::AsRawFd;

    // glibc struct termios layout (x86_64, aarch64, armhf, i386)
    #[repr(C)]
    #[derive(Clone, Copy)]
    struct Termios {
        c_iflag: u32,
        c_oflag: u32,
        c_cflag: u32,
        c_lflag: u32,
        c_line: u8,
        c_cc: [u8; 32],
        c_ispeed: u32,
        c_ospeed: u32,
    }

    extern "C" {
        fn tcgetattr(fd: c_int, t: *mut Termios) -> c_int;
        fn tcsetattr(fd: c_int, act: c_int, t: *const Termios) -> c_int;
        fn cfmakeraw(t: *mut Termios);
        fn cfsetispeed(t: *mut Termios, speed: u32) -> c_int;
        fn cfsetospeed(t: *mut Termios, speed: u32) -> c_int;
        fn tcflush(fd: c_int, q: c_int) -> c_int;
    }

    const TCSANOW: c_int = 0;
    const TCIOFLUSH: c_int = 2;
    const CLOCAL: u32 = 0o4000;
    const CREAD: u32 = 0o200;
    const CSTOPB: u32 = 0o100;
    const PARENB: u32 = 0o400;
    const CRTSCTS: u32 = 0o20000000000;
    const VTIME: usize = 5;
    const VMIN: usize = 6;

    fn speed(baud: u32) -> io::Result<u32> {
        Ok(match baud {
            9600 => 0o15,
            19200 => 0o16,
            38400 => 0o17,
            57600 => 0o10001,
            115200 => 0o10002,
            _ => return Err(io::Error::new(io::ErrorKind::InvalidInput, "unsupported baud rate")),
        })
    }

    pub fn configure(f: &File, baud: u32) -> io::Result<()> {
        let fd = f.as_raw_fd();
        unsafe {
            let mut t: Termios = std::mem::zeroed();
            if tcgetattr(fd, &mut t) != 0 {
                return Err(io::Error::new(io::ErrorKind::Other, "not a serial port"));
            }
            cfmakeraw(&mut t);
            t.c_cflag |= CLOCAL | CREAD;
            t.c_cflag &= !(CSTOPB | PARENB | CRTSCTS);
            t.c_cc[VMIN] = 0;
            t.c_cc[VTIME] = 2; // 200 ms read timeout
            let s = speed(baud)?;
            cfsetispeed(&mut t, s);
            cfsetospeed(&mut t, s);
            if tcsetattr(fd, TCSANOW, &t) != 0 {
                return Err(io::Error::last_os_error());
            }
            tcflush(fd, TCIOFLUSH);
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs::File;

    #[test]
    fn targets() {
        assert_eq!(Target::parse("usb").unwrap(), Target::Usb(None));
        assert_eq!(Target::parse("/dev/hidraw2").unwrap(), Target::Usb(Some("/dev/hidraw2".into())));
        assert_eq!(Target::parse("/dev/ttyUSB0").unwrap(), Target::Serial("/dev/ttyUSB0".into()));
        assert_eq!(Target::parse("tcp:10.0.0.5:6000").unwrap(), Target::Tcp("10.0.0.5:6000".into()));
        assert!(Target::parse("tcp:10.0.0.5").is_err());
        assert!(Target::parse("bogus").is_err());
    }

    #[test]
    fn hidraw_discovery_from_sysfs() {
        let root = std::env::temp_dir().join(format!("dsp4x4-sys-{}", std::process::id()));
        for (n, id) in [("hidraw0", "0003:0000046D:0000C52B"), ("hidraw3", "0003:00000168:00000821")] {
            let d = root.join(n).join("device");
            fs::create_dir_all(&d).unwrap();
            fs::write(d.join("uevent"), format!("DRIVER=hid-generic\nHID_ID={id}\nHID_NAME=x\n")).unwrap();
        }
        let found = find_hidraw_in(&root);
        fs::remove_dir_all(&root).ok();
        assert_eq!(found, vec![PathBuf::from("/dev/hidraw3")]);
    }

    #[test]
    fn usb_send_pads_reports() {
        // Exercise the report splitting against a file-backed writer.
        let p = std::env::temp_dir().join(format!("dsp4x4-hid-{}", std::process::id()));
        let f = File::create(&p).unwrap();
        let mut l = Link { kind: Kind::Usb, writer: Box::new(f), last_write: Instant::now(), report_len: 64, description: String::new() };
        let frame = crate::proto::encode(1, 0x35, &[4, 1]);
        l.send(&frame).unwrap();
        let written = fs::read(&p).unwrap();
        fs::remove_file(&p).ok();
        assert_eq!(written.len(), 65);
        assert_eq!(written[0], 0);
        assert_eq!(&written[1..1 + frame.len()], &frame[..]);
        assert!(written[1 + frame.len()..].iter().all(|&b| b == 0));
    }
}
