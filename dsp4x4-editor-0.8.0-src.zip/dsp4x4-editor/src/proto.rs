//! Editor protocol used by the original Windows editor over USB HID.
//!
//! Frame layout (recovered from the editor's serializer at 0x412ea4, and
//! confirmed against captures of the real device by the openDSP-4x4 project):
//!
//! ```text
//! request: 10 02 00 <dev> <len> <cmd> <data ...> 10 03 <xor>
//! reply:   10 02 <dev> 00 <len> <cmd> <data ...> 10 03 <xor>
//! ```
//!
//! * `len` = number of data bytes + 1 (the command byte)
//! * `xor` = XOR of every byte before it, including the leading `10 02`
//!   (equivalently: XOR of the bytes between `10 02` and `10 03`, then ^ 1)
//! * No byte stuffing: data bytes equal to 0x10 are sent as-is.
//! * Every request gets one reply; send the next request only after it.
//!
//! Channel numbers: inputs A..D are 0..3, outputs 1..4 are 4..7.

pub const USB_VID: u16 = 0x0168;
pub const USB_PID: u16 = 0x0821;
pub const HID_REPORT_LEN: usize = 64;

pub const DLE: u8 = 0x10;
pub const STX: u8 = 0x02;
pub const ETX: u8 = 0x03;

pub const PEQ_BANDS: u8 = 7;

/// Crossover slopes; the index is the wire code. The DSP 4x4 Mini accepts
/// codes 0..=10 (up to 24 dB/oct); the editor's 30..48 dB entries belong to
/// other models.
pub const XOVER_TYPES: [&str; 11] = [
    "Bypass",
    "Butterworth 6 dB",
    "Bessel 6 dB",
    "Butterworth 12 dB",
    "Bessel 12 dB",
    "Linkwitz-Riley 12 dB",
    "Butterworth 18 dB",
    "Bessel 18 dB",
    "Butterworth 24 dB",
    "Bessel 24 dB",
    "Linkwitz-Riley 24 dB",
];

/// PEQ filter types in the order the editor lists them.
pub const PEQ_TYPES: [&str; 7] = [
    "Peak",
    "Low Shelf",
    "High Shelf",
    "Low Cut",
    "High Cut",
    "Allpass 1",
    "Allpass 2",
];

/// Test signal sources for command 0x39 (the original editor's "Input Signal Select").
pub const SIGNAL_SOURCES: [&str; 4] = ["Analog input", "Pink noise", "White noise", "Sine wave"];

/// Sine generator frequencies (1/3 octave, 20 Hz..20 kHz), indexed by the frequency byte.
pub const SINE_FREQS: [f64; 31] = [
    20.0, 25.0, 31.5, 40.0, 50.0, 63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0, 500.0, 630.0,
    800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0, 10000.0, 12500.0,
    16000.0, 20000.0,
];

/// Index of the sine frequency nearest to `hz` (on a log scale).
pub fn sine_index(hz: f64) -> u8 {
    let mut best = 0;
    for (i, f) in SINE_FREQS.iter().enumerate() {
        if (f.ln() - hz.ln()).abs() < (SINE_FREQS[best].ln() - hz.ln()).abs() {
            best = i;
        }
    }
    best as u8
}

/// Compressor ratios, indexed by the ratio byte.
pub const COMP_RATIOS: [&str; 16] = [
    "1.0", "1.1", "1.3", "1.5", "1.7", "2.0", "2.5", "3.0", "3.5", "4.0", "5.0", "6.0", "8.0",
    "10", "20", "Limit",
];

#[allow(dead_code)]
pub mod cmd {
    pub const STATUS: u8 = 0x10;
    pub const INIT_DONE: u8 = 0x12;
    pub const VERSION: u8 = 0x13;
    pub const RECALL_PRESET: u8 = 0x20;
    pub const STORE_PRESET: u8 = 0x21;
    pub const CHANNEL_PAGE: u8 = 0x24;
    pub const READ_CHANNEL: u8 = 0x27;
    pub const LEVELS: u8 = 0x40;
    pub const COMPRESSOR: u8 = 0x30;
    pub const LOW_PASS: u8 = 0x31;
    pub const HIGH_PASS: u8 = 0x32;
    pub const PEQ: u8 = 0x33;
    pub const GAIN: u8 = 0x34;
    pub const MUTE: u8 = 0x35;
    pub const PHASE: u8 = 0x36;
    pub const DELAY: u8 = 0x38;
    pub const ROUTING: u8 = 0x3a;
    pub const GATE: u8 = 0x3e;
    /// Input signal select: analog input, pink/white noise or sine (CM_MCS_WORK_MODE).
    pub const SIGNAL: u8 = 0x39;
}

/// A decoded frame.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Frame {
    pub dev: u8,
    pub cmd: u8,
    pub data: Vec<u8>,
}

/// Build a complete frame.
pub fn encode(dev: u8, cmd: u8, data: &[u8]) -> Vec<u8> {
    assert!(data.len() < 255, "payload too long");
    let mut f = Vec::with_capacity(data.len() + 9);
    f.extend_from_slice(&[DLE, STX, 0x00, dev, (data.len() + 1) as u8, cmd]);
    f.extend_from_slice(data);
    f.extend_from_slice(&[DLE, ETX]);
    let x = f.iter().fold(0u8, |a, b| a ^ b);
    f.push(x);
    f
}

/// Incremental parser for a byte stream that may contain partial frames,
/// HID padding, or noise between frames.
#[derive(Default)]
pub struct Parser {
    buf: Vec<u8>,
}

#[derive(Debug, PartialEq, Eq)]
pub enum Parsed {
    Frame(Frame),
    /// A frame whose checksum didn't match (bytes kept for logging).
    BadChecksum(Vec<u8>),
}

impl Parser {
    pub fn push(&mut self, bytes: &[u8]) -> Vec<Parsed> {
        self.buf.extend_from_slice(bytes);
        let mut out = Vec::new();
        loop {
            // resync on DLE STX
            match self.buf.windows(2).position(|w| w == [DLE, STX]) {
                Some(0) => {}
                Some(p) => {
                    self.buf.drain(..p);
                }
                None => {
                    let keep = if self.buf.last() == Some(&DLE) { 1 } else { 0 };
                    let n = self.buf.len() - keep;
                    self.buf.drain(..n);
                    break;
                }
            }
            if self.buf.len() < 5 {
                break;
            }
            let len = self.buf[4] as usize;
            let total = len + 8;
            if len == 0 {
                self.buf.drain(..2);
                continue;
            }
            if self.buf.len() < total {
                break;
            }
            let f: Vec<u8> = self.buf.drain(..total).collect();
            let ok_tail = f[total - 3] == DLE && f[total - 2] == ETX;
            let x = f[..total - 1].iter().fold(0u8, |a, b| a ^ b);
            if ok_tail && x == f[total - 1] {
                out.push(Parsed::Frame(Frame {
                    // requests carry 00 <dev>, replies <dev> 00
                    dev: if f[2] != 0 { f[2] } else { f[3] },
                    cmd: f[5],
                    data: f[6..total - 3].to_vec(),
                }));
            } else {
                out.push(Parsed::BadChecksum(f));
            }
        }
        out
    }
}

// ---------------------------------------------------------------------------
// Channels
// ---------------------------------------------------------------------------

/// Parse "InA".."InD" (or "In1".."In4"), "Out1".."Out4", or a wire number 0..7.
pub fn parse_channel(s: &str) -> Option<u8> {
    let t = s.trim().to_ascii_lowercase();
    if let Some(r) = t.strip_prefix("in") {
        let c = r.chars().next()?;
        return match c {
            'a'..='d' if r.len() == 1 => Some(c as u8 - b'a'),
            '1'..='4' if r.len() == 1 => Some(c as u8 - b'1'),
            _ => None,
        };
    }
    if let Some(r) = t.strip_prefix("out") {
        let n: u8 = r.parse().ok()?;
        return (1..=4).contains(&n).then(|| n + 3);
    }
    let n: u8 = t.parse().ok()?;
    (n < 8).then_some(n)
}

pub fn channel_name(ch: u8) -> String {
    if ch < 4 {
        format!("In{}", (b'A' + ch) as char)
    } else {
        format!("Out{}", ch - 3)
    }
}

pub fn is_output(ch: u8) -> bool {
    (4..8).contains(&ch)
}

// ---------------------------------------------------------------------------
// Value conversions (recovered from the editor's converters)
// ---------------------------------------------------------------------------

/// Frequency index: 1/30-octave steps, index 170 = 1 kHz, 0..300 covers ~19.7 Hz..20.2 kHz.
/// Editor: round(ln(f/1000) / ln(1.0233738919968) + 170).
pub fn freq_to_idx(hz: f64) -> u16 {
    let i = ((hz / 1000.0).ln() / 1.023_373_891_996_775_f64.ln() + 170.0).round();
    i.clamp(0.0, 300.0) as u16
}

#[allow(dead_code)]
pub fn idx_to_freq(idx: u16) -> f64 {
    1000.0 * 1.023_373_891_996_775_f64.powf(idx as f64 - 170.0)
}

/// PEQ gain: 0.1 dB steps, 120 = 0 dB, range -12..+12 dB.
pub fn eq_gain_to_raw(db: f64) -> u16 {
    ((db * 10.0).round() + 120.0).clamp(0.0, 240.0) as u16
}

#[allow(dead_code)]
pub fn raw_to_eq_gain(raw: u16) -> f64 {
    (raw as f64 - 120.0) / 10.0
}

/// Q index 0..100, Q = 128 / 1.0596^(100 - idx)  (≈0.4 .. 128).
pub fn q_to_idx(q: f64) -> u8 {
    let n = ((128.0 / q).ln() / 1.0596f64.ln()).round();
    (100.0 - n).clamp(0.0, 100.0) as u8
}

#[allow(dead_code)]
pub fn idx_to_q(idx: u8) -> f64 {
    128.0 / 1.0596f64.powf(100.0 - idx as f64)
}

/// Channel level 0..400: 0..80 = -60..-20 dB in 0.5 dB steps,
/// 80..400 = -20..+12 dB in 0.1 dB steps (280 = 0 dB).
pub fn level_to_raw(db: f64) -> u16 {
    let db = db.clamp(-60.0, 12.0);
    if db < -20.0 {
        ((db + 60.0) * 2.0).round() as u16
    } else {
        ((db * 10.0).round() + 280.0) as u16
    }
}

#[allow(dead_code)]
pub fn raw_to_level(raw: u16) -> f64 {
    let raw = raw.min(400) as f64;
    if raw < 80.0 {
        -60.0 + raw * 0.5
    } else {
        (raw - 280.0) / 10.0
    }
}

/// Gate / compressor threshold: 0.5 dB steps, wire = dB*2 + 180.
pub fn thr_to_raw(db: f64, max_db: f64) -> u16 {
    ((db.clamp(-90.0, max_db) * 2.0).round() as i32 + 180) as u16
}

/// Delay in samples at 48 kHz, max 32640 (680 ms).
pub const SAMPLE_RATE: f64 = 48_000.0;
pub const MAX_DELAY_SAMPLES: u16 = 32_640;

pub fn delay_ms_to_raw(ms: f64) -> u16 {
    (ms * SAMPLE_RATE / 1000.0)
        .round()
        .clamp(0.0, MAX_DELAY_SAMPLES as f64) as u16
}

/// Time controls (attack/hold/release) are sent as milliseconds - 1.
pub fn ms_to_time_raw(ms: f64, min: u16, max: u16) -> u16 {
    ((ms.round() - 1.0).max(0.0) as u16).clamp(min, max)
}

// ---------------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub enum Command {
    /// Input or output level in dB (-60..+12).
    Gain { ch: u8, db: f64 },
    Mute { ch: u8, on: bool },
    Phase { ch: u8, invert: bool },
    /// Output delay in milliseconds.
    Delay { ch: u8, ms: f64 },
    HighPass { ch: u8, hz: f64, slope: u8 },
    LowPass { ch: u8, hz: f64, slope: u8 },
    Peq { ch: u8, band: u8, hz: f64, db: f64, q: f64, kind: u8, bypass: bool },
    Compressor { ch: u8, ratio: u8, knee_db: u8, attack_ms: f64, release_ms: f64, threshold_db: f64 },
    Gate { ch: u8, attack_ms: f64, hold_ms: f64, release_ms: f64, threshold_db: f64 },
    /// Which inputs feed an output: bit0 = InA .. bit3 = InD.
    Routing { ch: u8, mask: u8 },
    /// Test signal generator: source 0 = analog input, 1 = pink noise, 2 = white noise,
    /// 3 = sine wave at SINE_FREQS[freq].
    Signal { source: u8, freq: u8 },
    /// Any command byte with a raw payload.
    Raw { cmd: u8, data: Vec<u8> },
}

fn le(v: u16) -> [u8; 2] {
    v.to_le_bytes()
}

impl Command {
    pub fn validate(&self) -> Result<(), String> {
        let out_only = |ch: u8, what: &str| {
            if is_output(ch) {
                Ok(())
            } else {
                Err(format!("{what} is only available on outputs (Out1..Out4)"))
            }
        };
        let in_only = |ch: u8, what: &str| {
            if ch < 4 {
                Ok(())
            } else {
                Err(format!("{what} is only available on inputs (InA..InD)"))
            }
        };
        let any = |ch: u8| if ch < 8 { Ok(()) } else { Err("channel must be 0..7".into()) };
        match self {
            Command::Gain { ch, .. } | Command::Mute { ch, .. } | Command::Phase { ch, .. } => any(*ch),
            Command::Delay { ch, .. } => out_only(*ch, "delay"),
            Command::HighPass { ch, slope, .. } | Command::LowPass { ch, slope, .. } => {
                out_only(*ch, "crossover")?;
                if (*slope as usize) < XOVER_TYPES.len() { Ok(()) } else { Err("slope index out of range".into()) }
            }
            Command::Peq { ch, band, kind, .. } => {
                out_only(*ch, "PEQ")?;
                if *band >= PEQ_BANDS {
                    return Err(format!("band must be 0..{}", PEQ_BANDS - 1));
                }
                if (*kind as usize) < PEQ_TYPES.len() { Ok(()) } else { Err("PEQ type out of range".into()) }
            }
            Command::Compressor { ch, ratio, knee_db, .. } => {
                out_only(*ch, "compressor")?;
                if (*ratio as usize) >= COMP_RATIOS.len() {
                    return Err("ratio index must be 0..15".into());
                }
                if *knee_db > 12 { Err("knee must be 0..12 dB".into()) } else { Ok(()) }
            }
            Command::Gate { ch, .. } => in_only(*ch, "noise gate"),
            Command::Routing { ch, mask } => {
                out_only(*ch, "routing")?;
                if *mask > 0x0f { Err("routing mask must be 0..15".into()) } else { Ok(()) }
            }
            Command::Signal { source, freq } => {
                if (*source as usize) >= SIGNAL_SOURCES.len() {
                    return Err("signal source must be 0..3 (analog, pink, white, sine)".into());
                }
                if (*freq as usize) < SINE_FREQS.len() { Ok(()) } else { Err("sine frequency index must be 0..30".into()) }
            }
            Command::Raw { .. } => Ok(()),
        }
    }

    pub fn cmd_byte(&self) -> u8 {
        match self {
            Command::Gain { .. } => cmd::GAIN,
            Command::Mute { .. } => cmd::MUTE,
            Command::Phase { .. } => cmd::PHASE,
            Command::Delay { .. } => cmd::DELAY,
            Command::HighPass { .. } => cmd::HIGH_PASS,
            Command::LowPass { .. } => cmd::LOW_PASS,
            Command::Peq { .. } => cmd::PEQ,
            Command::Compressor { .. } => cmd::COMPRESSOR,
            Command::Gate { .. } => cmd::GATE,
            Command::Routing { .. } => cmd::ROUTING,
            Command::Signal { .. } => cmd::SIGNAL,
            Command::Raw { cmd, .. } => *cmd,
        }
    }

    pub fn payload(&self) -> Vec<u8> {
        let mut p = Vec::new();
        match *self {
            Command::Gain { ch, db } => {
                p.push(ch);
                p.extend(le(level_to_raw(db)));
            }
            Command::Mute { ch, on } => p.extend([ch, on as u8]),
            Command::Phase { ch, invert } => p.extend([ch, invert as u8]),
            Command::Delay { ch, ms } => {
                p.push(ch);
                p.extend(le(delay_ms_to_raw(ms)));
            }
            Command::HighPass { ch, hz, slope } | Command::LowPass { ch, hz, slope } => {
                p.push(ch);
                p.extend(le(freq_to_idx(hz)));
                p.push(slope);
            }
            Command::Peq { ch, band, hz, db, q, kind, bypass } => {
                // gain before frequency (capture-verified)
                p.extend([ch, band]);
                p.extend(le(eq_gain_to_raw(db)));
                p.extend(le(freq_to_idx(hz)));
                p.extend([q_to_idx(q), kind, bypass as u8]);
            }
            Command::Compressor { ch, ratio, knee_db, attack_ms, release_ms, threshold_db } => {
                p.extend([ch, ratio, knee_db]);
                p.extend(le(ms_to_time_raw(attack_ms, 0, 998)));
                p.extend(le(ms_to_time_raw(release_ms, 9, 2999)));
                p.extend(le(thr_to_raw(threshold_db, 20.0)));
            }
            Command::Gate { ch, attack_ms, hold_ms, release_ms, threshold_db } => {
                // attack, release, hold (matches the device's state image)
                p.push(ch);
                p.extend(le(ms_to_time_raw(attack_ms, 0, 998)));
                p.extend(le(ms_to_time_raw(release_ms, 0, 2999)));
                p.extend(le(ms_to_time_raw(hold_ms, 9, 998)));
                p.extend(le(thr_to_raw(threshold_db, 0.0)));
            }
            Command::Routing { ch, mask } => p.extend([ch, mask]),
            Command::Signal { source, freq } => p.extend([source, freq]),
            Command::Raw { ref data, .. } => p.extend_from_slice(data),
        }
        p
    }

    pub fn encode(&self, dev: u8) -> Vec<u8> {
        encode(dev, self.cmd_byte(), &self.payload())
    }

    pub fn describe(&self) -> String {
        match self {
            Command::Gain { ch, db } => format!("{} level {:+.1} dB", channel_name(*ch), db),
            Command::Mute { ch, on } => format!("{} {}", channel_name(*ch), if *on { "mute" } else { "unmute" }),
            Command::Phase { ch, invert } => format!("{} phase {}", channel_name(*ch), if *invert { "180°" } else { "0°" }),
            Command::Delay { ch, ms } => format!("{} delay {:.3} ms", channel_name(*ch), ms),
            Command::HighPass { ch, hz, slope } => format!("{} high-pass {:.1} Hz {}", channel_name(*ch), hz, XOVER_TYPES[*slope as usize]),
            Command::LowPass { ch, hz, slope } => format!("{} low-pass {:.1} Hz {}", channel_name(*ch), hz, XOVER_TYPES[*slope as usize]),
            Command::Peq { ch, band, hz, db, q, kind, bypass } => format!(
                "{} EQ{} {} {:.1} Hz {:+.1} dB Q {:.2}{}",
                channel_name(*ch), band + 1, PEQ_TYPES[*kind as usize], hz, db, q,
                if *bypass { " (bypassed)" } else { "" }
            ),
            Command::Compressor { ch, ratio, knee_db, attack_ms, release_ms, threshold_db } => format!(
                "{} compressor {:.1} dB ratio {} knee {} dB attack {} ms release {} ms",
                channel_name(*ch), threshold_db, COMP_RATIOS[*ratio as usize], knee_db, attack_ms, release_ms
            ),
            Command::Gate { ch, attack_ms, hold_ms, release_ms, threshold_db } => format!(
                "{} gate {:.1} dB attack {} ms hold {} ms release {} ms",
                channel_name(*ch), threshold_db, attack_ms, hold_ms, release_ms
            ),
            Command::Routing { ch, mask } => {
                let ins: Vec<String> = (0..4).filter(|i| mask & (1 << i) != 0).map(channel_name).collect();
                format!("{} ← {}", channel_name(*ch), if ins.is_empty() { "nothing".into() } else { ins.join("+") })
            }
            Command::Signal { source, freq } => {
                if *source == 3 {
                    format!("test signal: sine {} Hz", SINE_FREQS[*freq as usize])
                } else {
                    format!("test signal: {}", SIGNAL_SOURCES[*source as usize].to_lowercase())
                }
            }
            Command::Raw { cmd, data } => format!("raw cmd 0x{:02X} {}", cmd, hex(data)),
        }
    }
}

pub fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02X}")).collect::<Vec<_>>().join(" ")
}

pub fn parse_hex(s: &str) -> Result<Vec<u8>, String> {
    let clean: String = s.chars().filter(|c| c.is_ascii_hexdigit()).collect();
    if clean.len() % 2 != 0 {
        return Err("odd number of hex digits".into());
    }
    (0..clean.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&clean[i..i + 2], 16).map_err(|e| e.to_string()))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn signal_frames() {
        // same bytes the original editor's "Input Signal Select" dialog sends
        assert_eq!(Command::Signal { source: 1, freq: 0 }.encode(1), vec![0x10, 0x02, 0x00, 0x01, 0x03, 0x39, 0x01, 0x00, 0x10, 0x03, 0x3b]);
        assert_eq!(Command::Signal { source: 3, freq: 17 }.payload(), vec![3, 17]);
        assert_eq!(SINE_FREQS[sine_index(1000.0) as usize], 1000.0);
        assert_eq!(SINE_FREQS[sine_index(3000.0) as usize], 3150.0);
        assert!(Command::Signal { source: 4, freq: 0 }.validate().is_err());
    }

    #[test]
    fn matches_captured_frames() {
        // From USB captures of a real DSP 4x4 Mini (openDSP-4x4 PROTOCOL.md)
        assert_eq!(encode(1, cmd::LEVELS, &[]), vec![0x10, 0x02, 0x00, 0x01, 0x01, 0x40, 0x10, 0x03, 0x41]);
        assert_eq!(Command::Mute { ch: 4, on: true }.encode(1), vec![0x10, 0x02, 0x00, 0x01, 0x03, 0x35, 0x04, 0x01, 0x10, 0x03, 0x33]);
    }

    #[test]
    fn parses_device_reply() {
        // reply header is <dev> 00 (swapped vs. requests)
        let mut r = vec![0x10, 0x02, 0x01, 0x00, 0x02, 0x13, 0x41, 0x10, 0x03];
        r.push(r.iter().fold(0, |a, b| a ^ b));
        r.resize(64, 0);
        let got = Parser::default().push(&r);
        assert_eq!(got, vec![Parsed::Frame(Frame { dev: 1, cmd: 0x13, data: vec![0x41] })]);
    }

    #[test]
    fn frame_layout_and_checksum() {
        let f = encode(1, cmd::GAIN, &[4, 0x18, 0x01]);
        assert_eq!(&f[..6], &[0x10, 0x02, 0x00, 0x01, 0x04, 0x34]);
        assert_eq!(&f[6..9], &[4, 0x18, 0x01]);
        assert_eq!(&f[9..11], &[0x10, 0x03]);
        let x = f[..11].iter().fold(0, |a, b| a ^ b);
        assert_eq!(f[11], x);
        // total length is len + 8, which is what the receiver checks
        assert_eq!(f.len(), f[4] as usize + 8);
    }

    #[test]
    fn parser_roundtrip_with_noise_and_split() {
        let a = encode(1, cmd::MUTE, &[5, 1]);
        let b = encode(1, cmd::PEQ, &[4, 0, 0xaa, 0, 0x78, 0, 50, 0, 0]);
        let mut stream = vec![0u8, 0xff, 0x10];
        stream.extend(&a);
        stream.extend([0u8; 40]); // HID padding
        stream.extend(&b);
        let mut p = Parser::default();
        let (h1, h2) = stream.split_at(17);
        let mut got = p.push(h1);
        got.extend(p.push(h2));
        assert_eq!(got.len(), 2);
        assert_eq!(got[0], Parsed::Frame(Frame { dev: 1, cmd: cmd::MUTE, data: vec![5, 1] }));
        match &got[1] {
            Parsed::Frame(f) => assert_eq!(f.cmd, cmd::PEQ),
            _ => panic!(),
        }
    }

    #[test]
    fn parser_flags_bad_checksum() {
        let mut f = encode(1, cmd::MUTE, &[5, 1]);
        let n = f.len();
        f[n - 1] ^= 0xff;
        let got = Parser::default().push(&f);
        assert!(matches!(got[0], Parsed::BadChecksum(_)));
    }

    #[test]
    fn frequency_index() {
        assert_eq!(freq_to_idx(1000.0), 170);
        assert_eq!(freq_to_idx(20.0), 1);
        assert_eq!(freq_to_idx(20000.0), 300);
        assert_eq!(freq_to_idx(2000.0), 200); // one octave = 30 steps
        for i in 0..=300 {
            assert_eq!(freq_to_idx(idx_to_freq(i)), i);
        }
    }

    #[test]
    fn eq_gain_and_q() {
        assert_eq!(eq_gain_to_raw(0.0), 120);
        assert_eq!(eq_gain_to_raw(-12.0), 0);
        assert_eq!(eq_gain_to_raw(12.0), 240);
        assert_eq!(eq_gain_to_raw(-3.5), 85);
        assert_eq!(q_to_idx(128.0), 100);
        assert!((idx_to_q(0) - 0.39).abs() < 0.01);
        for i in 0..=100u8 {
            assert_eq!(q_to_idx(idx_to_q(i)), i);
        }
    }

    #[test]
    fn levels_match_documented_scale() {
        // From the RS-232 reference shipped in the editor: 280 = 0 dB, 250 = -3 dB
        assert_eq!(level_to_raw(0.0), 280);
        assert_eq!(level_to_raw(-3.0), 250);
        assert_eq!(level_to_raw(12.0), 400);
        assert_eq!(level_to_raw(-20.0), 80);
        assert_eq!(level_to_raw(-60.0), 0);
        assert_eq!(level_to_raw(-40.0), 40);
        for r in 0..=400 {
            assert_eq!(level_to_raw(raw_to_level(r)), r);
        }
    }

    #[test]
    fn thresholds_delay_times() {
        assert_eq!(thr_to_raw(0.0, 0.0), 180);
        assert_eq!(thr_to_raw(-90.0, 0.0), 0);
        assert_eq!(thr_to_raw(20.0, 20.0), 220);
        assert_eq!(delay_ms_to_raw(1.0), 48);
        assert_eq!(delay_ms_to_raw(1000.0), MAX_DELAY_SAMPLES);
        assert_eq!(ms_to_time_raw(100.0, 0, 998), 99);
    }

    #[test]
    fn payload_layouts() {
        let peq = Command::Peq { ch: 4, band: 2, hz: 1000.0, db: -3.0, q: 128.0, kind: 0, bypass: false };
        assert_eq!(peq.payload(), vec![4, 2, 90, 0, 170, 0, 100, 0, 0]);
        let gate = Command::Gate { ch: 0, attack_ms: 100.0, hold_ms: 100.0, release_ms: 3000.0, threshold_db: -90.0 };
        assert_eq!(gate.payload(), vec![0, 99, 0, 0xb7, 0x0b, 99, 0, 0, 0]);
        let comp = Command::Compressor { ch: 5, ratio: 15, knee_db: 0, attack_ms: 51.0, release_ms: 500.0, threshold_db: 20.0 };
        assert_eq!(comp.payload(), vec![5, 15, 0, 50, 0, 0xf3, 0x01, 220, 0]);
        let xo = Command::HighPass { ch: 7, hz: 20.0, slope: 0 };
        assert_eq!(xo.payload(), vec![7, 1, 0, 0]);
        assert_eq!(xo.cmd_byte(), 0x32);
        assert_eq!(Command::LowPass { ch: 7, hz: 20.0, slope: 0 }.cmd_byte(), 0x31);
        assert_eq!(Command::Phase { ch: 4, invert: true }.payload(), vec![4, 1]);
        assert_eq!(Command::Mute { ch: 4, on: true }.encode(1).len(), 2 + 8 + 1);
    }

    #[test]
    fn validation() {
        assert!(Command::Delay { ch: 0, ms: 1.0 }.validate().is_err());
        assert!(Command::Gate { ch: 4, attack_ms: 1.0, hold_ms: 10.0, release_ms: 10.0, threshold_db: -60.0 }.validate().is_err());
        assert!(Command::Peq { ch: 4, band: 7, hz: 1000.0, db: 0.0, q: 1.0, kind: 0, bypass: false }.validate().is_err());
        assert!(Command::Routing { ch: 4, mask: 0b1010 }.validate().is_ok());
    }

    #[test]
    fn channels() {
        assert_eq!(parse_channel("InA"), Some(0));
        assert_eq!(parse_channel("ind"), Some(3));
        assert_eq!(parse_channel("Out1"), Some(4));
        assert_eq!(parse_channel("OUT4"), Some(7));
        assert_eq!(parse_channel("7"), Some(7));
        assert_eq!(parse_channel("Out5"), None);
        assert_eq!(channel_name(6), "Out3");
    }
}
