//! Network access: settings, PIN pairing, discovery and autostart.

use std::collections::HashMap;
use std::fs;
use std::io::Read;
use std::net::{IpAddr, Ipv4Addr, UdpSocket};
use std::path::PathBuf;
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

pub const DISCOVERY_PORT: u16 = 8485;
pub const DISCOVERY_PROBE: &[u8] = b"DSP4X4-DISCOVER";
const MAX_TOKENS: usize = 20;

pub fn config_dir() -> PathBuf {
    crate::presets::dir().parent().map(|p| p.to_path_buf()).unwrap_or_else(|| PathBuf::from("."))
}

#[derive(Clone, Debug, PartialEq)]
pub struct Settings {
    /// Allow phones and other computers on the local network.
    pub lan: bool,
    pub pin: String,
    /// Login tokens handed to paired devices (kept across restarts).
    pub tokens: Vec<String>,
}

impl Settings {
    fn path() -> PathBuf {
        config_dir().join("settings.conf")
    }

    pub fn load() -> Settings {
        let mut s = Settings { lan: false, pin: String::new(), tokens: Vec::new() };
        if let Ok(text) = fs::read_to_string(Self::path()) {
            for line in text.lines() {
                let Some((k, v)) = line.split_once('=') else { continue };
                match k.trim() {
                    "lan" => s.lan = v.trim() == "1",
                    "pin" if v.trim().len() == 6 && v.trim().bytes().all(|b| b.is_ascii_digit()) => s.pin = v.trim().into(),
                    "tokens" => s.tokens = v.split(',').map(str::trim).filter(|t| t.len() == 32 && t.bytes().all(|b| b.is_ascii_hexdigit())).map(String::from).collect(),
                    _ => {}
                }
            }
        }
        if s.pin.is_empty() {
            s.pin = new_pin();
            let _ = s.save();
        }
        s
    }

    pub fn save(&self) -> std::io::Result<()> {
        fs::create_dir_all(config_dir())?;
        let p = Self::path();
        let tmp = p.with_extension("conf.tmp");
        fs::write(&tmp, format!("lan={}\npin={}\ntokens={}\n", self.lan as u8, self.pin, self.tokens.join(",")))?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = fs::set_permissions(&tmp, fs::Permissions::from_mode(0o600));
        }
        fs::rename(tmp, p)
    }

    pub fn new_token(&mut self) -> String {
        let t = random_hex(16);
        self.tokens.push(t.clone());
        while self.tokens.len() > MAX_TOKENS {
            self.tokens.remove(0);
        }
        t
    }

    pub fn has_token(&self, t: &str) -> bool {
        !t.is_empty() && self.tokens.iter().any(|x| ct_eq(x.as_bytes(), t.as_bytes()))
    }
}

/// Constant-time comparison for secrets.
pub fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    a.len() == b.len() && a.iter().zip(b).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

fn random_bytes(n: usize) -> Vec<u8> {
    let mut b = vec![0u8; n];
    if fs::File::open("/dev/urandom").and_then(|mut f| f.read_exact(&mut b)).is_err() {
        // fallback: time-based (only if /dev/urandom is unavailable)
        let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
        for (i, x) in b.iter_mut().enumerate() {
            *x = (t >> ((i % 16) * 8)) as u8 ^ (i as u8).wrapping_mul(151);
        }
    }
    b
}

pub fn random_hex(n: usize) -> String {
    random_bytes(n).iter().map(|b| format!("{b:02x}")).collect()
}

pub fn new_pin() -> String {
    let b = random_bytes(4);
    format!("{:06}", u32::from_le_bytes([b[0], b[1], b[2], b[3]]) % 1_000_000)
}

/// Limits PIN guessing: 5 wrong tries per address, then a 60 s wait.
#[derive(Default)]
pub struct Throttle {
    fails: HashMap<IpAddr, (u32, Instant)>,
}

impl Throttle {
    pub fn blocked_for(&mut self, ip: IpAddr) -> Option<Duration> {
        let (n, t) = *self.fails.get(&ip)?;
        let wait = Duration::from_secs(60);
        if n >= 5 && t.elapsed() < wait {
            Some(wait - t.elapsed())
        } else {
            if n >= 5 {
                self.fails.remove(&ip);
            }
            None
        }
    }
    pub fn fail(&mut self, ip: IpAddr) {
        let e = self.fails.entry(ip).or_insert((0, Instant::now()));
        e.0 += 1;
        e.1 = Instant::now();
    }
    pub fn ok(&mut self, ip: IpAddr) {
        self.fails.remove(&ip);
    }
}

pub fn hostname() -> String {
    fs::read_to_string("/proc/sys/kernel/hostname")
        .or_else(|_| fs::read_to_string("/etc/hostname"))
        .map(|s| s.trim().to_string())
        .ok()
        .filter(|s| !s.is_empty())
        .unwrap_or_else(|| "dsp4x4".into())
}

/// The address other devices on the network can reach this computer at.
/// (Connecting a UDP socket sends nothing; it only picks the outgoing interface.)
pub fn primary_ipv4() -> Option<Ipv4Addr> {
    for probe in ["192.168.0.1:9", "10.0.0.1:9", "8.8.8.8:9"] {
        if let Ok(s) = UdpSocket::bind("0.0.0.0:0") {
            if s.connect(probe).is_ok() {
                if let Ok(std::net::SocketAddr::V4(a)) = s.local_addr() {
                    let ip = *a.ip();
                    if !ip.is_loopback() && !ip.is_unspecified() {
                        return Some(ip);
                    }
                }
            }
        }
    }
    None
}

/// Answer "DSP4X4-DISCOVER" broadcasts so apps can find the editor without typing an address.
pub fn spawn_discovery(port: u16) {
    std::thread::spawn(move || {
        let Ok(sock) = UdpSocket::bind(("0.0.0.0", DISCOVERY_PORT)) else {
            eprintln!("dsp4x4-editor: discovery port {DISCOVERY_PORT} is busy; discovery by broadcast is off");
            return;
        };
        let mut buf = [0u8; 64];
        loop {
            let Ok((n, from)) = sock.recv_from(&mut buf) else { continue };
            if &buf[..n] == DISCOVERY_PROBE {
                let reply = format!("{{\"service\":\"dsp4x4-editor\",\"name\":\"{}\",\"port\":{},\"path\":\"/remote\"}}", hostname().replace('"', ""), port);
                let _ = sock.send_to(reply.as_bytes(), from);
            }
        }
    });
}

/// Advertise on mDNS / Bonjour via avahi (Debian/Ubuntu package avahi-utils), if installed.
pub fn spawn_mdns(port: u16) -> Option<Child> {
    let name = format!("DSP 4x4 Editor on {}", hostname());
    Command::new("avahi-publish-service")
        .args([name.as_str(), "_http._tcp", &port.to_string(), "path=/remote"])
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .ok()
}

pub fn mdns_available() -> bool {
    std::env::var_os("PATH")
        .map(|p| std::env::split_paths(&p).any(|d| d.join("avahi-publish-service").is_file()))
        .unwrap_or(false)
}

// ---------------------------------------------------------------------------
// Autostart (systemd user service shipped in the package)
// ---------------------------------------------------------------------------

pub const UNIT: &str = "dsp4x4-editor.service";

fn systemctl(args: &[&str]) -> Result<String, String> {
    let out = Command::new("systemctl").arg("--user").args(args).output().map_err(|e| format!("systemctl: {e}"))?;
    let text = String::from_utf8_lossy(&out.stdout).trim().to_string() + String::from_utf8_lossy(&out.stderr).trim();
    if out.status.success() {
        Ok(text)
    } else {
        Err(text)
    }
}

pub fn autostart_status() -> String {
    match systemctl(&["is-enabled", UNIT]) {
        Ok(s) if s.starts_with("enabled") => "on".into(),
        Ok(_) | Err(_) if !std::path::Path::new("/usr/lib/systemd/user").join(UNIT).exists() => "unavailable".into(),
        _ => "off".into(),
    }
}

pub fn set_autostart(on: bool) -> Result<(), String> {
    if on {
        systemctl(&["enable", UNIT]).map(|_| ())
    } else {
        systemctl(&["disable", UNIT]).map(|_| ())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pins_and_tokens() {
        let p = new_pin();
        assert_eq!(p.len(), 6);
        assert!(p.bytes().all(|b| b.is_ascii_digit()));
        assert_eq!(random_hex(16).len(), 32);
        assert_ne!(random_hex(16), random_hex(16));
        let mut s = Settings { lan: true, pin: "123456".into(), tokens: vec![] };
        let t = s.new_token();
        assert!(s.has_token(&t));
        assert!(!s.has_token(""));
        assert!(!s.has_token("00000000000000000000000000000000"));
        for _ in 0..30 {
            s.new_token();
        }
        assert_eq!(s.tokens.len(), MAX_TOKENS);
        assert!(!s.has_token(&t), "oldest token is dropped");
    }

    #[test]
    fn throttle() {
        let ip: IpAddr = "192.168.1.9".parse().unwrap();
        let mut t = Throttle::default();
        for _ in 0..4 {
            t.fail(ip);
            assert!(t.blocked_for(ip).is_none());
        }
        t.fail(ip);
        assert!(t.blocked_for(ip).is_some());
        t.ok(ip);
        assert!(t.blocked_for(ip).is_none());
    }

    #[test]
    fn ct() {
        assert!(ct_eq(b"abc", b"abc"));
        assert!(!ct_eq(b"abc", b"abd"));
        assert!(!ct_eq(b"abc", b"ab"));
    }
}
