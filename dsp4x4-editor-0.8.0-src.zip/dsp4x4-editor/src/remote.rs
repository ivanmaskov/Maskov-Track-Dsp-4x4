//! Documented "Processor Extend Remote Control Protocol" (RS-232), as shipped
//! in the editor's own reference dialog. Meant for control systems: level,
//! mute and preset recall only.
//!
//! ```text
//! 7B 7D <id> <cmd> <d1> <d2> <d3> 7D 7B      115200 baud, 8N1, >= 20 ms between frames
//! ```

pub const BAUD: u32 = 115_200;

pub const GAIN_STEP: u8 = 0x41;
pub const MUTE: u8 = 0x42;
pub const RECALL: u8 = 0x43;
pub const IN_VOLUME: u8 = 0x44;
pub const OUT_VOLUME: u8 = 0x45;
pub const GET_GAIN: u8 = 0x48;
pub const GET_MUTE: u8 = 0x49;
pub const GET_PRESET: u8 = 0x4a;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Dir {
    In = 0,
    Out = 1,
}

pub fn frame(id: u8, cmd: u8, d: [u8; 3]) -> [u8; 9] {
    [0x7b, 0x7d, id, cmd, d[0], d[1], d[2], 0x7d, 0x7b]
}

#[derive(Debug, Clone, PartialEq)]
pub enum Remote {
    /// One step up (`down == false`) or down.
    GainStep { dir: Dir, ch: u8, down: bool },
    Mute { dir: Dir, ch: u8, on: bool },
    /// Factory preset (F00) or user preset U01..U30.
    Recall { user: bool, preset: u8 },
    Volume { dir: Dir, ch: u8, db: f64 },
    GetGain { dir: Dir, ch: u8 },
    GetMute { dir: Dir, ch: u8 },
    GetPreset,
}

impl Remote {
    pub fn encode(&self, id: u8) -> [u8; 9] {
        match *self {
            Remote::GainStep { dir, ch, down } => frame(id, GAIN_STEP, [dir as u8, ch, down as u8]),
            Remote::Mute { dir, ch, on } => frame(id, MUTE, [dir as u8, ch, on as u8]),
            Remote::Recall { user, preset } => frame(id, RECALL, [user as u8, preset, 0]),
            Remote::Volume { dir, ch, db } => {
                let raw = crate::proto::level_to_raw(db);
                let cmd = if dir == Dir::In { IN_VOLUME } else { OUT_VOLUME };
                frame(id, cmd, [ch, (raw >> 8) as u8, raw as u8])
            }
            Remote::GetGain { dir, ch } => frame(id, GET_GAIN, [dir as u8, ch, 0]),
            Remote::GetMute { dir, ch } => frame(id, GET_MUTE, [dir as u8, ch, 0]),
            Remote::GetPreset => frame(id, GET_PRESET, [0, 0, 0]),
        }
    }

    pub fn validate(&self) -> Result<(), String> {
        let ch_ok = |ch: u8| if ch < 4 { Ok(()) } else { Err("channel must be 0..3 (A..D or 1..4)".to_string()) };
        match *self {
            Remote::GainStep { ch, .. } | Remote::Mute { ch, .. } | Remote::Volume { ch, .. } => ch_ok(ch),
            Remote::GetGain { ch, .. } | Remote::GetMute { ch, .. } => ch_ok(ch),
            Remote::Recall { user, preset } => {
                if user && !(1..=30).contains(&preset) {
                    Err("user presets are U01..U30".into())
                } else {
                    Ok(())
                }
            }
            Remote::GetPreset => Ok(()),
        }
    }
}

/// Find complete remote frames in a byte stream (replies use the same framing).
pub fn scan(buf: &[u8]) -> Vec<[u8; 9]> {
    buf.windows(9)
        .filter(|w| w[0] == 0x7b && w[1] == 0x7d && w[7] == 0x7d && w[8] == 0x7b)
        .map(|w| w.try_into().unwrap())
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn documented_examples() {
        // Examples from the reference dialog (with its two typos fixed:
        // recall uses 0x43, and get-preset is a full 9-byte frame).
        assert_eq!(
            Remote::GainStep { dir: Dir::In, ch: 0, down: false }.encode(1),
            [0x7b, 0x7d, 0x01, 0x41, 0x00, 0x00, 0x00, 0x7d, 0x7b]
        );
        assert_eq!(
            Remote::Mute { dir: Dir::Out, ch: 0, on: true }.encode(1),
            [0x7b, 0x7d, 0x01, 0x42, 0x01, 0x00, 0x01, 0x7d, 0x7b]
        );
        assert_eq!(
            Remote::Volume { dir: Dir::In, ch: 0, db: 0.0 }.encode(1),
            [0x7b, 0x7d, 0x01, 0x44, 0x00, 0x01, 0x18, 0x7d, 0x7b]
        );
        assert_eq!(
            Remote::Volume { dir: Dir::Out, ch: 1, db: -3.0 }.encode(1),
            [0x7b, 0x7d, 0x01, 0x45, 0x01, 0x00, 0xfa, 0x7d, 0x7b]
        );
        assert_eq!(
            Remote::GetGain { dir: Dir::In, ch: 0 }.encode(1),
            [0x7b, 0x7d, 0x01, 0x48, 0x00, 0x00, 0x00, 0x7d, 0x7b]
        );
    }

    #[test]
    fn scan_finds_frames() {
        let mut b = vec![0xaa];
        b.extend(Remote::GetPreset.encode(3));
        b.push(0x00);
        assert_eq!(scan(&b).len(), 1);
    }
}
