# t.racks DSP 4x4 Mini — protocol notes

Recovered from the official Windows editor (`the t.racks DSP 4x4 Mini Editor V1.05`,
a C++Builder 2009 program) by static analysis, for interoperability. Addresses refer
to the unpacked `editor.exe` (image base 0x400000).

Several details were corrected using the capture-verified findings of the
[openDSP-4x4](https://github.com/glassontin/opendsp-4x4) project (AGPL-3.0; only
facts about the protocol were used, no code): the wake-up sequence, request/reply
pacing, the reply header, the low-/high-pass command codes, the PEQ and gate field
order, the polarity width, the slope range and the settings read-back.

## Transports

| Link    | Details |
|---------|---------|
| USB HID | VID `0x0168`, PID `0x0821`. 64-byte reports, report ID 0. Frames are written into output reports and padded with zeros. |
| RS-232  | 115200 baud, 8 data bits, no parity, 1 stop bit. Leave at least 20 ms between frames. |
| Network | The editor also has a TCP client and a UDP discovery listener. The port is set at run time and could not be recovered statically. |

## Editor frame (USB)

```
request: 10 02 00 <dev> <len> <cmd> <data…> 10 03 <xor>
reply:   10 02 <dev> 00 <len> <cmd> <data…> 10 03 <xor>
```

* Each frame is padded to one 64-byte HID report.
* Every request gets exactly one reply. Send the next request only after the reply
  arrives; resend after about 400 ms without one.
* No byte stuffing: a data byte of `10` is sent as-is.

### Connecting

Send status `10` and then version `13` (the version is only answered right after a
status query). Then read the nine settings pages with `27 <0..8>` (each answered by
`24 <page> <50 bytes>`). After that the original editor polls levels with `40`.

* `dev` is the device ID, 1–250 (default 1).
* `len` is the number of data bytes plus 1.
* `xor` is the XOR of every preceding byte, including `10 02`.
* The receiver accepts a frame when byte 0 is `10`, byte 1 is `02`, and the total length is `len + 8`.

Serializer: `0x412ea4`. Receive check: `0x41bd34`. Dispatcher switch: `0x42125f`.

### Channels

Inputs A–D are `0`–`3` and outputs 1–4 are `4`–`7`.

### Value scales

| Quantity | Wire value |
|---|---|
| Channel level | u16 0–400. 0–80 covers −60…−20 dB in 0.5 dB steps; 80–400 covers −20…+12 dB in 0.1 dB steps; 280 = 0 dB. |
| Frequency | u16 index 0–300 in 1/30-octave steps, where `f = 1000 · 1.0233739^(i − 170)` (index 170 = 1 kHz). Converter at `0x41f540`. |
| EQ gain | u16, `dB · 10 + 120` (range −12…+12 dB). Converter at `0x41f514`. |
| Q | u8 0–100, where `Q = 128 / 1.0596^(100 − i)` (about 0.4–128). Converter at `0x41f398`. |
| Delay | u16 samples at 48 kHz, 0–32640 (680 ms). |
| Thresholds | u16, `dB · 2 + 180` (0.5 dB steps). Gate −90…0 dB; compressor −90…+20 dB. |
| Times | u16 milliseconds − 1. Attack 1–999 ms, hold 10–999 ms, release up to 3000 ms. |

### Commands (all little-endian)

| cmd  | Name | Data |
|------|------|------|
| `10` | Status (wake) | — |
| `13` | Version | — (reply: ASCII, e.g. `4x4MINIPRO V010`) |
| `20` / `21` | Recall / store preset | slot |
| `27` | Read settings page | page 0–8 (reply `24`: page, 50 bytes) |
| `30` | Compressor | ch, ratio idx (0–15; 15 = limit), knee dB (0–12), attack u16, release u16, threshold u16 |
| `31` | Low-pass | ch, freq idx u16, slope idx |
| `32` | High-pass | ch, freq idx u16, slope idx |
| `33` | PEQ band | ch, band 0–6, gain u16, freq idx u16, Q idx, type, bypass |
| `34` | Level | ch, level u16 |
| `35` | Mute | ch, 0/1 |
| `36` | Polarity | ch, 0/1 (one byte) |
| `38` | Delay | ch, samples u16 |
| `39` | Test signal (CM_MCS_WORK_MODE, “Input Signal Select”) | source (0 analog input, 1 pink noise, 2 white noise, 3 sine), sine frequency idx 0–30 (20 Hz … 20 kHz in 1/3 octaves: 20, 25, 31.5 … 16k, 20k) |
| `3a` | Routing | output ch, input bitmask (bit 0 = InA) |
| `3e` | Noise gate | ch (input), attack u16, release u16, hold u16, threshold u16 |
| `40` | Levels | — (reply: 27 bytes; 3 bytes per channel InA…Out4, see below) |

Constructors are at `0x413f18` (`30`), `0x414c9c` (`31`), `0x414a34` (`32`), `0x414760` (`33`), `0x414f10` (`34`), `0x415954` (`35`), `0x4144e8` (`36`), `0x415140` (`38`), `0x4154fc` (`3a`) and `0x4141d8` (`3e`). Command `39` is built at `0x40e960`, from the `Tag` of the
selected radio button and the frequency list's index (handler `rbAnalogInClick` at `0x40ea98`). The generator
has no level of its own in the original editor; this editor adds its volume to the Out1–Out4 levels it sends while the generator plays.

**Slopes:** 0 Bypass, 1 Butterworth 6, 2 Bessel 6, 3 Butterworth 12, 4 Bessel 12, 5 Linkwitz-Riley 12, 6 Butterworth 18, 7 Bessel 18, 8 Butterworth 24, 9 Bessel 24, 10 Linkwitz-Riley 24. (The editor also lists 30–48 dB slopes; those are for other models.)

**PEQ types:** Peak, Low Shelf, High Shelf, Low Cut, High Cut, Allpass 1, Allpass 2.

**Compressor ratios:** 1.0, 1.1, 1.3, 1.5, 1.7, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 8.0, 10, 20, Limit.

### Levels (`40` reply)

For channel k (InA = 0 … Out4 = 7) with bytes `a = d[3k]`, `b = d[3k+1]`, `c = d[3k+2]`,
the original editor (function at `0x4246f8`) forms `v = b<<24 | a<<16 | c<<8` and shows
`20·log10(v · 2^-27) + 28` dB on LEDs at −40, −30, −20, −10, −5, 0, +5, +10, +11 (clip).
`FF FF FF` means no signal. Reading only `d[3k+2]` gives the least significant byte, which
doesn't follow the music.

### Settings image (450 bytes = pages 0–8)

Inputs at 16 + 24·i: name (10), gate attack, release, hold, threshold (u16 each), level u16 at +18, polarity at +20.
Outputs at 112 + 74·k: name (8), routing at +8, high-pass freq u16 +10, low-pass freq u16 +12,
high-pass slope +14, low-pass slope +15, PEQ bands at +16 + 6·j (gain u16, freq u16, Q, type),
compressor ratio +58, knee +59, attack u16 +60, release u16 +62, threshold u16 +64,
level u16 +66, polarity +68, delay u16 +70. Mute and PEQ bypass are not in the image.

### Not yet decoded

`04`, `14`, `15`, `19`, `1a`, `22`, `25`, `26` (channel name), `29` (preset names), `2c`, `2d`, `2e`, `2f` (lock password), `39` (test tone), `3b`, `3f`.

The RS-232 and network ports use a different (16-bit) checksum for these frames that
isn't documented; over RS-232 use the remote protocol below.

## Documented RS-232 remote protocol

This one is shipped in the editor's own help dialog and is meant for control systems.

```
7B 7D <id> <cmd> <d1> <d2> <d3> 7D 7B
```

| cmd  | Meaning | d1 | d2 | d3 |
|------|---------|----|----|----|
| `41` | Gain step | in 0 / out 1 | ch 0–7 | + 0 / − 1 |
| `42` | Mute | in 0 / out 1 | ch | 0 = unmute, 1 = mute |
| `43` | Recall preset | factory 0 / user 1 | preset 0–30 | 0 |
| `44` | Input volume | ch | level high byte | level low byte |
| `45` | Output volume | ch | level high byte | level low byte |
| `48` | Get gain | in/out | ch | 0 |
| `49` | Get mute | in/out | ch | 0 |
| `4a` | Get preset | 0 | 0 | 0 |

Example: `7B 7D 01 45 01 00 FA 7D 7B` sets Out2 to −3.0 dB.
