import sys
sys.argv=[sys.argv[0],sys.argv[1]]
src=open(sys.argv[0].replace('win_gen.py','standalone.py')).read()
FAKE=src.split('FAKE="""')[1].split('"""')[0]
from playwright.sync_api import sync_playwright
S=sys.argv[1]
hexs=lambda a:' '.join(f'{x:02X}' for x in a)
with sync_playwright() as pw:
  b=pw.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':900})
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('dialog',lambda d:d.accept())
  pg.add_init_script(FAKE); pg.goto('file://'+S+'/win/dsp4x4-editor.html'); pg.wait_for_timeout(500)
  print('test signal before connect:',pg.inner_text('#genopen'))
  pg.click('#genopen'); pg.locator('#gensrc .chip',has_text='Pink noise').click(); pg.wait_for_timeout(200); print('blocked offline:',pg.inner_text('#genmsg')); pg.keyboard.press('Escape')
  pg.select_option('#target','webhid'); pg.click('#connect'); pg.wait_for_timeout(1500)
  n=pg.evaluate('__hid.length')
  pg.click('#genopen'); pg.locator('#gensrc .chip',has_text='Pink noise').click(); pg.wait_for_timeout(800)
  fr=[hexs(r[:r[4]+8]) for r in pg.evaluate('__hid')[n:]]
  print('USB frames:'); [print('  ',f) for f in fr if f.split()[5] in ('34','39')]
  pg.locator('#genstop').click(); pg.wait_for_timeout(800); pg.keyboard.press('Escape')
  pg.click('#aboutopen'); print('about:',pg.inner_text('#aboutver'))
  print('errors',errs)
