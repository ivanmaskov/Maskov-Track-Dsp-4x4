import os,sys,tty,time,select,subprocess,threading,shutil,json,socket,urllib.request,urllib.parse,base64
import numpy as np,cv2
sys.path.insert(0,os.path.dirname(__file__))
from dspsim import Sim
from playwright.sync_api import sync_playwright
S=sys.argv[1]; binary=sys.argv[2]; cfg=S+'/cfg-lan'; shutil.rmtree(cfg,ignore_errors=True)
os.makedirs(cfg+'/dsp4x4-editor'); open(cfg+'/dsp4x4-editor/settings.conf','w').write('lan=1\npin=314159\ntokens=\n')
ip=[a for a in socket.gethostbyname_ex(socket.gethostname())[2] if not a.startswith('127.')]
s0=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s0.connect(('10.0.0.1',9)); ip=s0.getsockname()[0]; s0.close()
print('container address used as "the network":',ip)
m,s=os.openpty(); tty.setraw(s); pts=os.ttyname(s); sim=Sim(); stop=False
def loop():
    while not stop:
        r,_,_=select.select([m],[],[],0.05)
        if r:
            for rep in sim.feed(os.read(m,4096)): os.write(m,rep)
threading.Thread(target=loop,daemon=True).start()
env=dict(os.environ,XDG_CONFIG_HOME=cfg,no_proxy='*',NO_PROXY='*')
for k in ('HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy'): env.pop(k,None); os.environ.pop(k,None)
os.environ['no_proxy']='*'
p=subprocess.Popen([binary,'serve','--port','8600'],stderr=subprocess.PIPE,env=env); time.sleep(0.8)
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
def req(url,method='GET',hdr=None,data=None):
    r=urllib.request.Request(url,method=method,headers=hdr or {},data=data)
    try:
        with opener.open(r,timeout=5) as f: return f.status,f.read().decode(),dict(f.headers)
    except urllib.error.HTTPError as e: return e.code,e.read().decode(),dict(e.headers)
L='http://127.0.0.1:8600'; R=f'http://{ip}:8600'
try:
    print('local editor page:',req(L+'/')[0],'| ping:',req(R+'/api/ping')[1])
    code,body,_=req(R+'/remote'); print('remote without PIN -> login page:',code,'Enter the PIN' in body)
    print('remote API without PIN:',req(R+'/api/state')[0],'| remote /api/lan:',req(R+'/api/lan')[0])
    print('remote POST without X-DSP header:',req(R+'/api/login?pin=314159',method='POST')[0])
    j=json.loads(req(L+'/api/lan')[1]); print('local /api/lan:',{k:j[k] for k in ('lan','pin','port','ip','mdns','autostart')})
    # discovery
    u=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); u.settimeout(2); u.sendto(b'DSP4X4-DISCOVER',('127.0.0.1',8485)); print('UDP discovery reply:',u.recvfrom(256)[0].decode())
    # connect DSP sim from local
    print('connect sim:',json.loads(req(L+'/api/connect?'+urllib.parse.urlencode({'target':'usb:'+pts}),'POST',{'X-DSP':'1'})[1]).get('ok'))
    with sync_playwright() as pw:
        b=pw.chromium.launch(args=['--no-proxy-server'])
        desk=b.new_page(viewport={'width':1280,'height':900}); errs=[]
        desk.on('pageerror',lambda e:errs.append('desk:'+str(e)))
        desk.goto(L+'/'); desk.wait_for_timeout(1500)
        # read back once so the shared session holds the DSP settings
        desk.evaluate("afterConnect()"); desk.wait_for_timeout(1500)
        print('desktop Network button visible:',desk.is_visible('#netopen'))
        desk.click('#netopen'); desk.wait_for_timeout(600)
        qr=desk.evaluate("$('#qr').toDataURL()")
        img=cv2.imdecode(np.frombuffer(base64.b64decode(qr.split(',')[1]),np.uint8),cv2.IMREAD_GRAYSCALE)
        url,_,_=cv2.QRCodeDetector().detectAndDecode(img); print('QR code decodes to:',url)
        desk.screenshot(path=S+'/v5-net.png'); desk.keyboard.press('Escape')
        time.sleep(61) if '--lockout' in sys.argv else None
        phone=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2).new_page()
        phone.on('pageerror',lambda e:errs.append('phone:'+str(e)))
        phone.goto(url.replace(ip,ip)); phone.wait_for_timeout(2500)
        print('phone after QR:',phone.title(),'| status:',phone.inner_text('#status'))
        print('phone Out2 level:',phone.locator('.ch .db').nth(1).inner_text(),'(DSP image has -3.0 dB)')
        # phone moves Out1 fader -> DSP + desktop
        n=len(sim.got)
        phone.locator('.ch').nth(0).locator('.step').nth(0).tap(); phone.wait_for_timeout(200)
        for _ in range(9): phone.locator('.ch').nth(0).locator('.step').nth(0).tap()
        phone.wait_for_timeout(1800)
        print('DSP got from phone:',[(hex(c),d.hex(' ')) for c,d in sim.got[n:] if c==0x34][-1:],'| desktop Out1 shows:',desk.inner_text('#ro4'))
        # phone mute + compare B
        phone.locator('.ch').nth(1).locator('.mute').tap(); phone.wait_for_timeout(1500)
        print('desktop Out2 mute pressed:',desk.locator('.tog.mute').nth(5).get_attribute('aria-pressed'))
        n=len(sim.got); phone.locator('.slot').nth(1).tap(); phone.wait_for_timeout(1500); print('desktop follows phone to slot:',desk.evaluate('SLOT[CMP.active]'))
        desk.evaluate("()=>{const f=document.querySelectorAll('.fader')[6];f.value=200;f.dispatchEvent(new Event('input'))}"); desk.wait_for_timeout(2000)
        print('phone sees desktop change in slot B, Out3:',phone.locator('.ch .db').nth(2).inner_text(),'| desktop active slot:',desk.evaluate('SLOT[CMP.active]'))
        n=len(sim.got); phone.locator('.slot').nth(0).tap(); phone.wait_for_timeout(1200)
        print('phone B -> A sent to DSP:',[(hex(c),d.hex(' ')) for c,d in sim.got[n:] if c!=0x40])
        phone.locator('#tabIn').tap(); phone.wait_for_timeout(300)
        phone.screenshot(path=S+'/v5-phone-in.png'); phone.locator('#tabOut').tap(); phone.wait_for_timeout(1000)
        phone.screenshot(path=S+'/v5-phone.png',full_page=True)
        print('meters moving on phone:',phone.evaluate("[...document.querySelectorAll('.meter i')].map(i=>i.style.width)"))
        print('errors:',errs)
        # switch network access off -> restart; remote refused, local fine
        req(L+'/api/lan-set?enable=0','POST',{'X-DSP':'1'}); time.sleep(2.5)
        try: c=req(R+'/api/ping')[0]
        except Exception as e: c=type(e).__name__
        print('after turning network off: remote ->',c,'| local ->',req(L+'/api/ping')[1])
        b.close()
finally:
    stop=True; p.terminate(); p.wait(timeout=5)
