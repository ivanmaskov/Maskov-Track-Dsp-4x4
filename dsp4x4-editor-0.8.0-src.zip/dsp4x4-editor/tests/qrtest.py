import sys,random,string,base64,numpy as np,cv2
from playwright.sync_api import sync_playwright
qr=open('assets/qr.js').read()
random.seed(3)
texts=["http://192.168.1.23:8484/remote#pin=042517","http://10.0.0.5:8484/remote#pin=999999","http://172.16.254.201:8484/remote#pin=123456","A"]
texts+=["".join(random.choice(string.ascii_letters+string.digits+":/.#=?-") for _ in range(random.randint(1,200))) for _ in range(60)]
with sync_playwright() as pw:
  b=pw.chromium.launch(); pg=b.new_page(); pg.set_content("<canvas id=c></canvas><script>"+qr+"</script>")
  ok=bad=0; vers=set(); st={}
  for t in texts:
    url=pg.evaluate("t=>{const c=document.getElementById('c');QR.draw(c,t,6);return [c.toDataURL(),QR.encode(t).length]}",t)
    vers.add((url[1]-17)//4)
    img=cv2.imdecode(np.frombuffer(base64.b64decode(url[0].split(',')[1]),np.uint8),cv2.IMREAD_GRAYSCALE)
    got,_,_=cv2.QRCodeDetector().detectAndDecode(img)
    st.setdefault((url[1]-17)//4,[0,0])[got==t]+=1
    if got==t: ok+=1
    else:
      bad+=1
      if bad<5: print('FAIL v',(url[1]-17)//4,repr(t[:60]),'->',repr(got[:60]))
  print('decoded OK',ok,'of',len(texts)); print('per version [fail,ok]:',dict(sorted(st.items())))
  b.close()
