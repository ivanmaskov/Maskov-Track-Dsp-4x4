import subprocess,time,sys,json,random,urllib.request,urllib.parse
from playwright.sync_api import sync_playwright
S=sys.argv[1]
srv=subprocess.Popen(['target/release/dsp4x4-editor','ui','--no-browser','--port','8593'],stderr=subprocess.DEVNULL)
time.sleep(0.6)
def rust(params):
    q=urllib.parse.urlencode(params)
    r=urllib.request.Request('http://127.0.0.1:8593/api/encode?'+q,method='POST',headers={'X-DSP':'1'})
    try:
        with urllib.request.urlopen(r) as f: return json.load(f)['frame']
    except urllib.error.HTTPError as e: return 'ERR'
random.seed(7)
fHz=lambda i:1000*1.023373891996775**(i-170)
qV=lambda i:128/1.0596**(100-i)
RAT=["1.0","1.1","1.3","1.5","1.7","2.0","2.5","3.0","3.5","4.0","5.0","6.0","8.0","10","20","Limit"]
IN=["InA","InB","InC","InD"];OUT=["Out1","Out2","Out3","Out4"]
def rnd():
    t=random.choice(["gain","mute","phase","delay","hpf","lpf","peq","comp","gate","route"])
    o=random.choice(OUT); i=random.choice(IN)
    def lv():
        r=random.randint(0,400); return r*0.5-60 if r<80 else (r-280)/10
    return {"gain":lambda:{"type":t,"ch":random.choice(IN+OUT),"db":str(lv())},
     "mute":lambda:{"type":t,"ch":random.choice(IN+OUT),"on":str(random.randint(0,1))},
     "phase":lambda:{"type":t,"ch":random.choice(IN+OUT),"invert":str(random.randint(0,1))},
     "delay":lambda:{"type":t,"ch":o,"ms":"%.4f"%(random.randint(0,32640)/48)},
     "hpf":lambda:{"type":t,"ch":o,"hz":"%.2f"%fHz(random.randint(1,300)),"slope":str(random.randint(0,20))},
     "lpf":lambda:{"type":t,"ch":o,"hz":"%.2f"%fHz(random.randint(1,300)),"slope":str(random.randint(0,20))},
     "peq":lambda:{"type":t,"ch":o,"band":str(random.randint(1,7)),"hz":"%.2f"%fHz(random.randint(1,300)),"db":"%.1f"%(random.randint(-120,120)/10),"q":"%.4f"%qV(random.randint(0,100)),"kind":str(random.randint(0,6)),"bypass":str(random.randint(0,1))},
     "comp":lambda:{"type":t,"ch":o,"threshold":str(random.randint(-180,40)/2),"ratio":random.choice(RAT),"knee":str(random.randint(0,12)),"attack":str(random.randint(1,999)),"release":str(random.randint(10,3000))},
     "gate":lambda:{"type":t,"ch":i,"threshold":str(random.randint(-180,0)/2),"attack":str(random.randint(1,999)),"hold":str(random.randint(10,999)),"release":str(random.randint(1,3000))},
     "route":lambda:{"type":t,"ch":o,"inputs":str(random.randint(0,15))}}[t]()
cases=[rnd() for _ in range(3000)]
try:
  with sync_playwright() as pw:
    b=pw.chromium.launch(); pg=b.new_page()
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file://'+S+'/win/dsp4x4-editor.html'); pg.wait_for_timeout(500)
    print('standalone =',pg.evaluate('STANDALONE'),'| errors:',errs)
    js=pg.evaluate("cs=>cs.map(c=>{try{const [cmd,d]=P.build(c);return P.encode(1,cmd,d).map(x=>x.toString(16).padStart(2,'0').toUpperCase()).join('')}catch(e){return 'ERR'}})",cases)
    bad=[(c,j,r) for c,j in zip(cases,js) for r in [rust(c)] if j!=r]
    from collections import Counter
    print('compared',len(cases),'by type',dict(Counter(c['type'] for c in cases)))
    print('mismatches',len(bad)); [print(x) for x in bad[:5]]
    b.close()
finally: srv.terminate()
