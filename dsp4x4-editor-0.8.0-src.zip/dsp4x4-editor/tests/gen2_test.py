import os,sys,tty,time,select,subprocess,threading,shutil,socket,urllib.request,urllib.parse
sys.path.insert(0,os.path.dirname(__file__))
from dspsim import Sim
from playwright.sync_api import sync_playwright
S=sys.argv[1]; binary=sys.argv[2]; cfg=S+'/cfg-gen2'; shutil.rmtree(cfg,ignore_errors=True)
os.makedirs(cfg+'/dsp4x4-editor'); open(cfg+'/dsp4x4-editor/settings.conf','w').write('lan=1\npin=271828\ntokens=\n')
s0=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s0.connect(('10.0.0.1',9)); ip=s0.getsockname()[0]; s0.close()
m,s=os.openpty(); tty.setraw(s); pts=os.ttyname(s); sim=Sim(); stop=False
def loop():
    while not stop:
        r,_,_=select.select([m],[],[],0.05)
        if r:
            for rep in sim.feed(os.read(m,4096)): os.write(m,rep)
threading.Thread(target=loop,daemon=True).start()
for k in ('HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy'): os.environ.pop(k,None)
p=subprocess.Popen([binary,'serve','--port','8621'],stderr=subprocess.DEVNULL,env=dict(os.environ,XDG_CONFIG_HOME=cfg)); time.sleep(0.8)
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
op.open(urllib.request.Request('http://127.0.0.1:8621/api/connect?'+urllib.parse.urlencode({'target':'usb:'+pts}),method='POST',headers={'X-DSP':'1'})).read()
def frames(n0,cmds=None): return [f"{c:02x}:{d.hex(' ')}" for c,d in sim.got[n0:] if (cmds is None and c!=0x40) or (cmds and c in cmds)]
fail=[]
def check(name,ok,info=''):
    print(('PASS ' if ok else 'FAIL ')+name,info); 
    if not ok: fail.append(name)
try:
  with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--no-proxy-server']); errs=[]
    d=b.new_page(viewport={'width':1280,'height':900}); d.on('pageerror',lambda e:errs.append('desk:'+str(e)))
    d.goto('http://127.0.0.1:8621/'); d.wait_for_timeout(800); d.evaluate("afterConnect()"); d.wait_for_timeout(1500)
    print('outputs before (dB):',d.evaluate("[4,5,6,7].map(c=>lvlDb(S.outputs[c-4].gain))"))
    n=len(sim.got); d.click('#genopen'); d.locator('#gensrc .chip',has_text='Pink noise').click(); d.wait_for_timeout(500); d.keyboard.press('Escape')
    f=frames(n,(0x34,0x39)); check('pink at -30: Out2 (fader -3) gets -33',f==['34:04 3c 00','34:05 36 00','34:06 3c 00','34:07 3c 00','39:01 11'],f)
    n=len(sim.got); d.evaluate("const f=document.querySelectorAll('.fader')[4];f.value=220;f.dispatchEvent(new Event('input'))"); d.wait_for_timeout(400)
    f=frames(n,(0x34,)); check('Out1 fader to -6 sends -36 (master -30 + fader -6)',f==['34:04 30 00'],f)
    check('generator volume untouched',d.evaluate("GEN.level")==60 and d.input_value('#genlvl')=='60' and d.inner_text('#ro4')=='-6.0 dB',(d.evaluate("GEN.level"),d.inner_text('#ro4')))
    d.click('#genopen'); n=len(sim.got); d.evaluate("const r=$('#genlvl');r.value=lvlRaw(-20);r.dispatchEvent(new Event('input'))"); d.wait_for_timeout(500)
    f=frames(n,(0x34,)); check('master -20 keeps the balance (-26,-23,-20,-20)',f==['34:04 44 00','34:05 4a 00','34:06 50 00','34:07 50 00'],f)
    n=len(sim.got); d.click('#genstop'); d.wait_for_timeout(600); d.keyboard.press('Escape')
    f=frames(n,(0x34,0x39)); check('stop: outputs back to fader levels (-6,-3,0,0)',f==['39:00 11','34:04 dc 00','34:05 fa 00','34:06 18 01','34:07 18 01'],f)
    # phone: fader while noise plays
    ph=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2).new_page()
    ph.on('pageerror',lambda e:errs.append('phone:'+str(e)))
    ph.goto(f'http://{ip}:8621/remote#pin=271828'); ph.wait_for_timeout(2500)
    ph.tap('#more'); ph.locator('#gensrc button',has_text='White noise').tap(); ph.wait_for_timeout(500); ph.keyboard.press('Escape'); ph.wait_for_timeout(300)
    n=len(sim.got); ph.locator('.ch').nth(2).locator('.step').nth(0).tap(); ph.wait_for_timeout(500)
    f=frames(n,(0x34,)); check('phone Out3 step down sends -20.1 not -0.1',f==['34:06 50 00'],f)
    check('phone generator volume untouched',ph.evaluate("GEN.level")==80,ph.evaluate("GEN.level"))
    d.wait_for_timeout(1500); check('computer shows Out3 fader -0.1, master -20',d.inner_text('#ro6')=='-0.1 dB' and d.evaluate('GEN.level')==80,d.inner_text('#ro6'))
    n=len(sim.got); ph.tap('#genbarstop'); ph.wait_for_timeout(600)
    f=frames(n,(0x34,0x39)); check('phone stop restores fader levels',f==['39:00 11','34:04 dc 00','34:05 fa 00','34:06 17 01','34:07 18 01'],f)
    check('no page errors',not errs,errs)
finally:
    stop=True; p.terminate()
print('FAILED:',fail if fail else 'none')
