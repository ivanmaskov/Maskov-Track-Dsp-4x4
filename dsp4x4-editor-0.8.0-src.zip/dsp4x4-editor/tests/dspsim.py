"""Simulated t.racks DSP 4x4 Mini (USB HID framing) for tests."""
import struct
def image():
    img=bytearray(450)
    img[2:2+8]=b"TESTPRE\0"
    for i in range(4):
        b=16+24*i; img[b:b+4]=f"IN{i}".encode().ljust(4,b"\0")
        struct.pack_into("<HHHHH",img,b+10,4,299,99,0,280)  # atk,rel,hold,thr(-90),gain 0dB
    for k in range(4):
        b=112+74*k; img[b:b+4]=f"OUT{k}".encode().ljust(4,b"\0")
        img[b+8]=1<<k
        struct.pack_into("<HH",img,b+10,1,300); img[b+14]=0; img[b+15]=0
        for j in range(7): struct.pack_into("<HHBB",img,b+16+6*j,120,[54,95,135,170,210,250,290][j],38,0)
        img[b+58]=0; img[b+59]=0; struct.pack_into("<HHH",img,b+60,49,499,220)
        struct.pack_into("<H",img,b+66,280); img[b+68]=0; struct.pack_into("<H",img,b+70,0)
    # distinctive values to check
    b=112; struct.pack_into("<HH",img,b+10,60,250); img[b+14]=10; img[b+15]=3          # Out1 HPF idx60 LR24, LPF idx250 BW12
    struct.pack_into("<HHBB",img,b+16+12,90,170,50,1)                                   # Out1 band3 -3dB 1kHz q50 lowshelf
    img[b+58]=9; img[b+59]=3; struct.pack_into("<HHH",img,b+60,9,199,160)               # comp 4:1 knee3 atk10 rel200 thr-10
    struct.pack_into("<H",img,112+74+66,250); img[112+74+68]=1                          # Out2 -3dB, inverted
    struct.pack_into("<H",img,112+148+70,96)                                            # Out3 delay 2ms
    img[112+222+8]=0b1001                                                               # Out4 <- InA+InD
    struct.pack_into("<H",img,16+16,40)                                                 # InA gate -70dB
    return bytes(img)
IMG=image()
def reply(cmd,data,dev=1):
    f=[0x10,0x02,dev,0x00,len(data)+1,cmd,*data,0x10,0x03]; x=0
    for v in f: x^=v
    f.append(x); return bytes(f).ljust(64,b"\0")
def level_bytes(dbs):
    """encode display-dB levels the way the DSP does (inverse of the original editor's formula)"""
    d=[0]*27
    for k,db in enumerate(dbs):
        if db is None: d[3*k:3*k+3]=[255,255,255]; continue
        v=int(round(2**27*10**((db-28)/20)))&0xffffff00
        d[3*k]=(v>>16)&255; d[3*k+1]=(v>>24)&255; d[3*k+2]=(v>>8)&255
    return d
LEVELS=[-30.0,-12.0,0.0,6.0,11.0,None,-20.5,3.3]
class Sim:
    def levels(self,t): return LEVELS
    def __init__(self,silent=False,dev=1):
        self.awake=False; self.silent=silent; self.dev=dev; self.got=[]; self.buf=b""; self.t=0
    def feed(self,data):
        """bytes written by the host (may include HID report-id 0 prefix and padding)"""
        self.buf+=data; out=[]
        while True:
            i=self.buf.find(b"\x10\x02\x00")
            if i<0 or len(self.buf)<i+5: break
            n=self.buf[i+4]; tot=n+8
            if len(self.buf)<i+tot: break
            f=self.buf[i:i+tot]; self.buf=self.buf[i+tot:]
            x=0
            for v in f[:-1]: x^=v
            if x!=f[-1] or f[3]!=self.dev: continue
            cmd=f[5]; data=f[6:tot-3]; self.got.append((cmd,bytes(data)))
            if self.silent: continue
            if cmd==0x10: self.awake=True; out.append(reply(0x10,[0])); continue
            if not self.awake: continue                     # asleep: ignore everything else
            if cmd==0x13: out.append(reply(0x13,list(b"4x4MINIPRO V010\0"))); continue
            if cmd==0x27: i_=data[0]; out.append(reply(0x24,[i_,*IMG[i_*50:i_*50+50]])); continue
            if cmd==0x40:
                self.t+=1
                d=level_bytes(self.levels(self.t))
                out.append(reply(0x40,d)); continue
            out.append(reply(cmd,[1]))                      # ack set commands
        return out
