import os,sys,tty,time,select,subprocess,threading,shutil,socket,urllib.request,urllib.parse
sys.path.insert(0,os.path.dirname(__file__))
from dspsim import Sim
from playwright.sync_api import sync_playwright
S=sys.argv[1]; binary=sys.argv[2]; cfg=S+'/cfg-rew'; shutil.rmtree(cfg,ignore_errors=True)
os.makedirs(cfg+'/dsp4x4-editor'); open(cfg+'/dsp4x4-editor/settings.conf','w').write('lan=1\npin=271828\ntokens=\n')
s0=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s0.connect(('10.0.0.1',9)); ip=s0.getsockname()[0]; s0.close()
m,s=os.openpty(); tty.setraw(s); pts=os.ttyname(s); sim=Sim(); stop=False
def loop():
    while not stop:
        r,_,_=select.select([m],[],[],0.05)
        if r:
            for rep in sim.feed(os.read(m,4096)): os.write(m,rep)
threading.Thread(target=loop,daemon=True).start()
for k in ('HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy'): os.environ.pop(k,None)
p=subprocess.Popen([binary,'serve','--port','8631'],stderr=subprocess.DEVNULL,env=dict(os.environ,XDG_CONFIG_HOME=cfg)); time.sleep(0.8)
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
op.open(urllib.request.Request('http://127.0.0.1:8631/api/connect?'+urllib.parse.urlencode({'target':'usb:'+pts}),method='POST',headers={'X-DSP':'1'})).read()
def frames(n0,cmds=None): return [f"{c:02x}:{d.hex(' ')}" for c,d in sim.got[n0:] if (cmds is None and c!=0x40) or (cmds and c in cmds)]
fail=[]
def check(name,ok,info=''):
    print(('PASS ' if ok else 'FAIL ')+name,info); 
    if not ok: fail.append(name)
REW=os.path.join(os.path.dirname(os.path.abspath(__file__)),'example_rew.txt')
try:
  with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--no-proxy-server']); errs=[]
    d=b.new_page(viewport={'width':1280,'height':1100}); d.on('pageerror',lambda e:errs.append('desk:'+str(e)))
    d.goto('http://127.0.0.1:8631/'); d.wait_for_timeout(800); d.evaluate("afterConnect()"); d.wait_for_timeout(1500)
    d.evaluate("select(5)"); d.wait_for_timeout(300)   # Out2
    before1=d.evaluate("JSON.stringify(S.outputs[0].peq)")
    check('note shown',('Only 7 EQ bands are possible' in d.inner_text('.rewnote')),d.inner_text('.rewnote')[:60])
    n=len(sim.got); d.set_input_files('#rewfile',REW); d.wait_for_timeout(800)
    f=frames(n,(0x33,)); st=d.evaluate("S.outputs[1].peq.map(p=>[PEQT[p.type],+fHz(p.hz).toFixed(1),p.db,+qVal(p.q).toFixed(2)])")
    print('Out2 now:',st)
    check('7 PEQ frames to Out2 (ch 5)',sorted(x[:8] for x in f)==['33:05 0'+str(i) for i in range(7)],f)
    check('band 1 = PK 68.6 Hz -5.3 dB Q 7.5',st[0]==['Peak',68.6,-5.3,7.5],st[0])
    check('band 7 = PK 11.3 kHz -8.5 dB',st[6][0]=='Peak' and st[6][2]==-8.5,st[6])
    check('Out1 untouched',d.evaluate("JSON.stringify(S.outputs[0].peq)")==before1)
    check('message',('Imported 7 filters from example_rew.txt into Out2' in d.inner_text('#rewmsg')),d.inner_text('#rewmsg'))
    check('table shows band 1 gain -5.3',d.locator('tbody tr').nth(0).locator('input').nth(1).input_value()=='-5.3')
    d.locator('.eqwrap').screenshot(path=S+'/v8-rew.png')
    # phone: import into Out4
    ph=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2).new_page()
    ph.on('pageerror',lambda e:errs.append('phone:'+str(e)))
    ph.goto(f'http://{ip}:8631/remote#pin=271828'); ph.wait_for_timeout(2500)
    check('phone sees Out2 import',ph.evaluate("S.outputs[1].peq[0].db")==-5.3)
    ph.locator('.ch').nth(3).locator('.tog.edit').tap(); ph.wait_for_timeout(600)
    n=len(sim.got); ph.locator('.card input[type=file]').set_input_files(REW); ph.wait_for_timeout(800)
    f=frames(n,(0x33,)); check('phone: 7 PEQ frames to Out4 (ch 7)',len(f)==7 and all(x.startswith('33:07') for x in f),f[:2])
    check('phone message',('Imported 7 filters' in ph.inner_text('#rewmsg')),ph.inner_text('#rewmsg'))
    ph.locator('#rewmsg').scroll_into_view_if_needed(); ph.screenshot(path=S+'/v8-phone-rew.png')
    # bad file
    bad=os.path.join(S,'bad.txt'); open(bad,'w').write('hello world')
    d.set_input_files('#rewfile',bad); d.wait_for_timeout(300); check('bad file toast',"Couldn't import" in d.inner_text('#toast'),d.inner_text('#toast'))
    check('no page errors',not errs,errs)
finally:
    stop=True; p.terminate()
print('FAILED:',fail if fail else 'none')
