import os,sys,tty,time,select,subprocess,threading,shutil,socket,urllib.request,urllib.parse
sys.path.insert(0,os.path.dirname(__file__))
from dspsim import Sim
from playwright.sync_api import sync_playwright
S=sys.argv[1]; binary=sys.argv[2]; cfg=S+'/cfg-gen'; shutil.rmtree(cfg,ignore_errors=True)
os.makedirs(cfg+'/dsp4x4-editor'); open(cfg+'/dsp4x4-editor/settings.conf','w').write('lan=1\npin=271828\ntokens=\n')
s0=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s0.connect(('10.0.0.1',9)); ip=s0.getsockname()[0]; s0.close()
m,s=os.openpty(); tty.setraw(s); pts=os.ttyname(s); sim=Sim(); stop=False
def loop():
    while not stop:
        r,_,_=select.select([m],[],[],0.05)
        if r:
            for rep in sim.feed(os.read(m,4096)): os.write(m,rep)
threading.Thread(target=loop,daemon=True).start()
for k in ('HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy'): os.environ.pop(k,None)
p=subprocess.Popen([binary,'serve','--port','8611'],stderr=subprocess.DEVNULL,env=dict(os.environ,XDG_CONFIG_HOME=cfg)); time.sleep(0.8)
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
op.open(urllib.request.Request('http://127.0.0.1:8611/api/connect?'+urllib.parse.urlencode({'target':'usb:'+pts}),method='POST',headers={'X-DSP':'1'})).read()
def frames(n0,cmds=None): return [f"{c:02x}:{d.hex(' ')}" for c,d in sim.got[n0:] if (cmds is None and c!=0x40) or (cmds and c in cmds)]
fail=[]
def check(name,ok,info=''):
    print(('PASS ' if ok else 'FAIL ')+name,info); 
    if not ok: fail.append(name)
try:
  with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--no-proxy-server']); errs=[]
    d=b.new_page(viewport={'width':1280,'height':900}); d.on('pageerror',lambda e:errs.append('desk:'+str(e)))
    d.on('dialog',lambda dl:dl.accept())
    d.goto('http://127.0.0.1:8611/'); d.wait_for_timeout(800); d.evaluate("afterConnect()"); d.wait_for_timeout(1500)
    # --- test signal on the computer
    n=len(sim.got); d.click('#genopen'); d.locator('#gensrc .chip',has_text='Pink noise').click(); d.wait_for_timeout(500)
    f=frames(n,(0x34,0x39)); check('pink on: Out1-Out4 at -30 dB then 0x39 01',f==['34:04 3c 00','34:05 3c 00','34:06 3c 00','34:07 3c 00','39:01 11'],f)
    check('header shows playing',d.inner_text('#genopen')=='Test signal: pink noise' and 'live' in d.get_attribute('#genopen','class'),d.inner_text('#genopen'))
    n=len(sim.got); d.evaluate("const r=$('#genlvl');r.value=lvlRaw(-12);r.dispatchEvent(new Event('input'))"); d.wait_for_timeout(500)
    f=frames(n); check('volume -12 dB sets Out1-Out4 only',f==['34:04 a0 00','34:05 a0 00','34:06 a0 00','34:07 a0 00'],f)
    n=len(sim.got); d.locator('#gensrc .chip',has_text='Sine wave').click(); d.wait_for_timeout(300)
    check('freq row visible for sine',d.is_visible('#genfreqrow'))
    d.select_option('#genfreq','17'); d.wait_for_timeout(400)
    f=frames(n,(0x39,)); check('sine then 1 kHz',f[-1]=='39:03 11' and f[0].startswith('39:03'),f)
    d.screenshot(path=S+'/v7-gen.png')
    d.keyboard.press('Escape')
    # Send all keeps the generator volume on the inputs
    n=len(sim.got); d.click('#sendall'); d.wait_for_timeout(4000)
    g=[x for x in frames(n,(0x34,)) if x[3:5] in ('04','05','06','07')]
    check('send all ends with noise volume on outputs',g[-4:]==['34:04 a0 00','34:05 a0 00','34:06 a0 00','34:07 a0 00'],g[-4:])
    # --- phone sees it and stops it
    ph=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2).new_page()
    ph.on('pageerror',lambda e:errs.append('phone:'+str(e))); ph.on('dialog',lambda dl:dl.accept())
    ph.goto(f'http://{ip}:8611/remote#pin=271828'); ph.wait_for_timeout(2500)
    check('phone banner',ph.is_visible('#genbar') and ph.inner_text('#gentext')=='Sine 1 kHz playing',ph.inner_text('#gentext'))
    ph.screenshot(path=S+'/v7-phone-gen.png')
    n=len(sim.got); ph.tap('#genbarstop'); ph.wait_for_timeout(700)
    f=frames(n); check('phone stop: 0x39 00 then output levels restored to 0 dB',f==['39:00 11','34:04 18 01','34:05 18 01','34:06 18 01','34:07 18 01'],f)
    d.wait_for_timeout(1500); check('computer follows stop',d.inner_text('#genopen')=='Test signal',d.inner_text('#genopen'))
    # phone: start white noise from the sheet, adjust volume with +
    ph.tap('#more'); ph.wait_for_timeout(300)
    n=len(sim.got); ph.locator('#gensrc button',has_text='White noise').tap(); ph.wait_for_timeout(500)
    ph.locator('#genlvlbox .step').nth(1).tap(); ph.wait_for_timeout(400)
    f=frames(n); check('phone white noise + volume step',f[4]=='39:02 11' and f[-1]=='34:07 a1 00',f)
    ph.locator('.sheet').screenshot(path=S+'/v7-phone-sheet.png')
    check('phone about',('Maskov' in ph.inner_text('.about')) and ('0.7.1' in ph.inner_text('#aboutver')),ph.inner_text('#aboutver'))
    ph.locator('#gensrc button',has_text='Off').tap(); ph.wait_for_timeout(500); ph.keyboard.press('Escape')
    d.wait_for_timeout(1500)
    # --- EQ double click reset on the computer (Out1)
    d.evaluate("select(4)"); d.wait_for_timeout(300)
    d.locator("#eq").scroll_into_view_if_needed();d.wait_for_timeout(200);d.evaluate("const p=S.outputs[0].peq[2];p.db=6;p.hz=fIdx(700);p.q=qIdx(3);p.type=0;drawEq()")
    cv=d.locator('#eq').bounding_box(); pos=d.evaluate("(()=>{const g=geom($('#eq')),p=S.outputs[0].peq[2];return [xOf(g,fHz(p.hz)),yOf(g,p.db)]})()")
    n=len(sim.got); d.mouse.dblclick(cv['x']+pos[0],cv['y']+pos[1]); d.wait_for_timeout(500)
    f=frames(n,(0x33,)); st=d.evaluate("S.outputs[0].peq[2]")
    check('desktop double-click resets band 3',st=={'hz':d.evaluate('fIdx(400)'),'db':0,'q':d.evaluate('qIdx(1.4)'),'type':0,'bypass':False} and f and f[-1].startswith('33:04 02 78 00'),(st,f[-1:]))
    check('table row shows 400 Hz / 0 dB',d.locator('tbody tr').nth(2).locator('input').nth(0).input_value()=='396.9' and d.locator('tbody tr').nth(2).locator('input').nth(1).input_value()=='0.0')
    d.evaluate("S.outputs[0].peq.forEach((p,i)=>{p.db=i-3});drawEq()")
    n=len(sim.got); d.mouse.dblclick(cv['x']+cv['width']*0.97,cv['y']+12); d.wait_for_timeout(600)
    f=frames(n,(0x33,)); check('desktop double-click empty space resets all 7',len(f)==7 and all(x.split(' ')[2:4]==['78','00'] for x in f),len(f))
    # --- phone double tap a band
    ph.locator('.ch').nth(1).locator('.tog.edit').tap(); ph.wait_for_timeout(600)
    ph.locator('#curve').scroll_into_view_if_needed();ph.wait_for_timeout(200);ph.evaluate("S.outputs[1].peq[4].db=-8;drawCurve()")
    bb=ph.locator('#curve').bounding_box(); pos=ph.evaluate("(()=>{const r=$('#curve').getBoundingClientRect(),p=S.outputs[1].peq[4];return [gx(r.width,fHz(p.hz)),gy(r.height,p.db)]})()")
    n=len(sim.got); x,y=bb['x']+pos[0],bb['y']+pos[1]
    ph.touchscreen.tap(x,y); ph.wait_for_timeout(120); ph.touchscreen.tap(x,y); ph.wait_for_timeout(600)
    f=frames(n,(0x33,)); check('phone double tap resets band 5',ph.evaluate('S.outputs[1].peq[4].db')==0 and f and f[-1].startswith('33:05 04 78 00'),f[-1:])
    ph.screenshot(path=S+'/v7-phone-eq.png')
    # --- about on the computer
    d.click('#aboutopen'); d.wait_for_timeout(300)
    t=d.inner_text('#about'); check('desktop about',('Version 0.7.1' in t) and ('Maskov' in t) and ('openDSP-4x4' in t),t[:80])
    d.locator('#about form').screenshot(path=S+'/v7-about.png')
    check('no page errors',not errs,errs)
finally:
    stop=True; p.terminate()
print('FAILED:',fail if fail else 'none')
