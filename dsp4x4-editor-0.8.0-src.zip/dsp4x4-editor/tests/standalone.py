import sys
from playwright.sync_api import sync_playwright
S=sys.argv[1]
FAKE="""
(()=>{
  const ack=()=>{const a=[0x10,0x02,0x00,0x01,0x02,0x35,0x01,0x10,0x03];a.push(a.reduce((x,b)=>x^b,0));return a};
  window.__hid=[];window.__ser=[];
  const L={};
  const dev={vendorId:0x0168,productId:0x0821,productName:'DSP 4x4 Mini',opened:false,
    collections:[{outputReports:[{reportId:0,items:[{reportSize:8,reportCount:64}]}]}],
    async open(){this.opened=true},async close(){this.opened=false},
    addEventListener(t,f){(L[t]=L[t]||[]).push(f)},
    async sendReport(id,d){__hid.push(Array.from(d));const b=new Uint8Array(64);b.set(ack());setTimeout(()=>(L.inputreport||[]).forEach(f=>f({data:new DataView(b.buffer)})),5)}};
  Object.defineProperty(navigator,'hid',{value:{async getDevices(){return dev.opened?[dev]:[]},async requestDevice(){return[dev]},addEventListener(){}},configurable:true});
  let push=null;
  const port={async open(o){window.__baud=o.baudRate},async close(){},
    writable:{getWriter(){return{async write(u){__ser.push(Array.from(u));const a=ack();setTimeout(()=>push&&push(new Uint8Array(a)),5)},releaseLock(){}}}},
    readable:{getReader(){return{read(){return new Promise(r=>{push=v=>{push=null;r({value:v,done:false})}})},async cancel(){},releaseLock(){}}}}};
  Object.defineProperty(navigator,'serial',{value:{async requestPort(){return port}},configurable:true});
})();
"""
hexs=lambda a:' '.join(f'{x:02X}' for x in a)
with sync_playwright() as pw:
  b=pw.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':900})
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.add_init_script(FAKE); pg.goto('file://'+S+'/win/dsp4x4-editor.html'); pg.wait_for_timeout(500)
  print('options',pg.eval_on_selector_all('#target option','e=>e.map(x=>x.textContent)'))
  # USB
  pg.select_option('#target','webhid'); pg.click('#connect'); pg.wait_for_timeout(300)
  print('USB status:',pg.inner_text('#status'))
  pg.locator('.tog.mute').nth(4).click(); pg.wait_for_timeout(300)
  d=pg.evaluate('__hid')[-1]; print('USB report',len(d),'bytes:',hexs(d[:11]))
  pg.click('#connect'); pg.wait_for_timeout(200); print('after disconnect:',pg.inner_text('#status'))
  # Serial
  pg.select_option('#target','webserial'); pg.click('#connect'); pg.wait_for_timeout(300)
  print('Serial status:',pg.inner_text('#status'),'baud',pg.evaluate('__baud'))
  pg.fill('#devid','3'); pg.dispatch_event('#devid','change')
  pg.locator('.tog.mute').nth(5).click(); pg.wait_for_timeout(300)
  print('Serial bytes:',hexs(pg.evaluate('__ser')[-1]))
  pg.click('#sendall'); pg.wait_for_timeout(4000); print('send all:',pg.inner_text('#toast'),'| frames',len(pg.evaluate('__ser')))
  pg.click('#logbox summary'); pg.wait_for_timeout(200)
  print('log tail:'); print('\n'.join(pg.inner_text('#log').splitlines()[-3:]))
  pg.click('#check'); pg.wait_for_timeout(400); pg.screenshot(path=S+'/win-check.png')
  pg.keyboard.press('Escape')
  # unsupported browser
  p2=b.new_page(); p2.add_init_script("Object.defineProperty(navigator,'hid',{value:undefined});Object.defineProperty(navigator,'serial',{value:undefined})")
  p2.goto('file://'+S+'/win/dsp4x4-editor.html'); p2.wait_for_timeout(400)
  print('no-WebHID browser notice:',p2.inner_text('#notice'),'| connect disabled',p2.is_disabled('#connect'))
  pg.screenshot(path=S+'/win-main.png')
  print('errors',errs); b.close()
