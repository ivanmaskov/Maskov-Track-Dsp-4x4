import os,sys,tty,time,select,subprocess,threading,shutil,json,socket,urllib.request,urllib.parse
sys.path.insert(0,os.path.dirname(__file__))
from dspsim import Sim
from playwright.sync_api import sync_playwright
S=sys.argv[1]; binary=sys.argv[2]; cfg=S+'/cfg-ph'; shutil.rmtree(cfg,ignore_errors=True)
os.makedirs(cfg+'/dsp4x4-editor'); open(cfg+'/dsp4x4-editor/settings.conf','w').write('lan=1\npin=271828\ntokens=\n')
s0=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s0.connect(('10.0.0.1',9)); ip=s0.getsockname()[0]; s0.close()
m,s=os.openpty(); tty.setraw(s); pts=os.ttyname(s); sim=Sim(); stop=False
def loop():
    while not stop:
        r,_,_=select.select([m],[],[],0.05)
        if r:
            for rep in sim.feed(os.read(m,4096)): os.write(m,rep)
threading.Thread(target=loop,daemon=True).start()
for k in ('HTTP_PROXY','HTTPS_PROXY','http_proxy','https_proxy'): os.environ.pop(k,None)
env=dict(os.environ,XDG_CONFIG_HOME=cfg)
p=subprocess.Popen([binary,'serve','--port','8601'],stderr=subprocess.DEVNULL,env=env); time.sleep(0.8)
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
op.open(urllib.request.Request('http://127.0.0.1:8601/api/connect?'+urllib.parse.urlencode({'target':'usb:'+pts}),method='POST',headers={'X-DSP':'1'})).read()
def last(cmd,n0):
    x=[d.hex(' ') for c,d in sim.got[n0:] if c==cmd]; return x[-1] if x else None
def cnt(cmd,n0): return len([1 for c,d in sim.got[n0:] if c==cmd])
try:
  with sync_playwright() as pw:
    b=pw.chromium.launch(args=['--no-proxy-server']); errs=[]
    desk=b.new_page(viewport={'width':1280,'height':900}); desk.on('pageerror',lambda e:errs.append('desk:'+str(e)))
    desk.goto('http://127.0.0.1:8601/'); desk.wait_for_timeout(800); desk.evaluate("afterConnect()"); desk.wait_for_timeout(1500)
    ph=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2).new_page()
    ph.on('pageerror',lambda e:errs.append('phone:'+str(e)))
    ph.goto(f'http://{ip}:8601/remote#pin=271828'); ph.wait_for_timeout(2500)
    print('signed in:',ph.inner_text('#status'))
    # polarity from list
    n=len(sim.got); ph.locator('.ch').nth(1).locator('.tog.phase').tap(); ph.wait_for_timeout(300); print('Out2 polarity ->',last(0x36,n))
    # open Out1 detail
    ph.locator('.ch').nth(0).locator('.tog.edit').tap(); ph.wait_for_timeout(500)
    print('detail:',ph.inner_text('#dtitle'),'| sections:',[h.inner_text().split('\n')[0] for h in ph.locator('.card h3').all()])
    cards=ph.locator('.card')
    def card(t): return cards.filter(has=ph.locator('h3',has_text=t)).first
    n=len(sim.got); card('Inputs feeding').locator('.chip').nth(2).tap(); ph.wait_for_timeout(300); print('routing +InC ->',last(0x3a,n))
    n=len(sim.got); hp=card('High-pass'); hp.locator('.step').nth(1).tap(); ph.wait_for_timeout(300); hp.locator('select').select_option('8'); ph.wait_for_timeout(300)
    print('high-pass (cmd 0x32) ->',last(0x32,n),'| shows',hp.locator('output').inner_text())
    n=len(sim.got); lp=card('Low-pass'); lp.locator('select').select_option('3'); ph.wait_for_timeout(300); print('low-pass (cmd 0x31) ->',last(0x31,n))
    eq=card('Parametric EQ')
    eq.locator('.bands button').nth(2).tap(); ph.wait_for_timeout(200)
    n=len(sim.got)
    gain=eq.locator('.prm').filter(has=ph.locator('label',has_text='Gain')).first
    for _ in range(5): gain.locator('.step').nth(0).tap()
    ph.wait_for_timeout(400); print('band 3 gain -0.5 dB ->',last(0x33,n),'| shows',gain.locator('output').inner_text())
    n=len(sim.got); eq.locator('select').select_option('2'); ph.wait_for_timeout(300); print('band 3 type high shelf ->',last(0x33,n))
    # drag band 5 on the curve
    bb=ph.locator('#curve').bounding_box(); pos=ph.evaluate("(()=>{const r=$('#curve').getBoundingClientRect(),p=S.outputs[0].peq[4];return [gx(r.width,fHz(p.hz)),gy(r.height,p.db)]})()")
    n=len(sim.got); ph.mouse.move(bb['x']+pos[0],bb['y']+pos[1]); ph.mouse.down(); ph.mouse.move(bb['x']+pos[0]-40,bb['y']+pos[1]-30,steps=6); ph.mouse.up(); ph.wait_for_timeout(400)
    print('drag band 5 ->',last(0x33,n),'| active band button:',eq.locator('.bands [aria-current=true]').inner_text(),'| controls show:',eq.locator('.bb').inner_text(),eq.locator('select').evaluate('e=>e.options[e.selectedIndex].text'),eq.locator('.prm').filter(has=ph.locator('label',has_text='Gain')).first.locator('output').inner_text(),'| state band5 db',ph.evaluate('S.outputs[0].peq[4].db'))
    n=len(sim.got); eq.locator('.tog.eqb').tap(); ph.wait_for_timeout(500); print('Bypass EQ -> PEQ frames',cnt(0x33,n),'bypass bytes',[d[-1] for c,d in sim.got[n:] if c==0x33])
    eq.locator('.tog.eqb').tap(); ph.wait_for_timeout(400)
    n=len(sim.got); cp=card('Compressor'); cp.locator('select').select_option('9'); ph.wait_for_timeout(300); print('ratio 4:1 ->',last(0x30,n))
    dl=card('Delay'); dl.locator('select').select_option('m'); dl.locator('input.txt').fill('2,5'); dl.locator('input.txt').press('Enter'); ph.wait_for_timeout(400)
    n2=last(0x38,0); print('delay 2,5 m ->',n2,'| text:',dl.locator('.hint').inner_text())
    ph.screenshot(path=S+'/v6-detail.png',full_page=True)
    # switch to InA via nav, gate
    ph.locator('#chnav button').nth(0).tap(); ph.wait_for_timeout(300)
    n=len(sim.got); g=card('Noise gate'); g.locator('.prm').first.locator('.step').nth(1).tap(); ph.wait_for_timeout(300); print('InA gate threshold step ->',last(0x3e,n))
    ph.screenshot(path=S+'/v6-input.png',full_page=True)
    ph.go_back(); ph.wait_for_timeout(400); print('Back button returns to list:',ph.is_visible('#main'))
    desk.wait_for_timeout(1500)
    print('desktop sees: Out1 HPF',desk.evaluate('JSON.stringify(S.outputs[0].hpf)'),'| route',desk.evaluate('S.outputs[0].route'),'| delay',desk.evaluate('S.outputs[0].delay'),'| band3',desk.evaluate('JSON.stringify(S.outputs[0].peq[2])'))
    # presets from phone
    ph.locator('#more').tap(); ph.wait_for_timeout(300); ph.fill('#pname','Phone made'); ph.locator('#psave').tap(); ph.wait_for_timeout(600)
    print('save from phone:',ph.inner_text('#pmsg'),'| on disk:',os.listdir(cfg+'/dsp4x4-editor/presets'))
    n=len(sim.got); ph.locator('#sendall').tap(); ph.wait_for_timeout(6000); print('Send all from phone:',len(sim.got)-n-cnt(0x40,n),'frames')
    d=ph.locator('#plist li').first.locator('.tog').nth(1); d.tap(); d.tap(); ph.wait_for_timeout(500); print('delete from phone ->',os.listdir(cfg+'/dsp4x4-editor/presets'))
    ph.keyboard.press('Escape')
    print('errors:',errs); b.close()
finally:
    stop=True; p.terminate()
