# Developing dsp4x4-editor

Notes for changing this project later (by hand or with Claude). Author: Maskov.

## Layout

| Path | What it is |
|------|------------|
| `src/main.rs` | Command line: `ui`, `serve`, `network`, `autostart`, `doctor`, `list`, `send`, `remote` |
| `src/proto.rs` | DSP USB protocol: frames, value scales, the `Command` enum (one variant per DSP command) |
| `src/params.rs` | Turns `key=value` parameters (CLI and `/api/send`) into a `Command` |
| `src/remote.rs` | The documented RS-232 remote protocol (level, mute, presets) |
| `src/link.rs` | Opening USB (hidraw), serial ports (termios) and TCP |
| `src/web.rs` | Built-in web server: pages, `/api/...` routes, shared session for phones, LAN PIN login |
| `src/lan.rs` | Network access settings, PIN/tokens, mDNS and UDP discovery, autostart (systemd) |
| `src/presets.rs` | Preset files in `~/.config/dsp4x4-editor/presets` |
| `src/diag.rs` | `doctor` / Check USB |
| `assets/core.js` | Shared browser code: value scales, packet builder (`P.build`), state ↔ commands (`C`), test signal, EQ maths |
| `assets/ui.html` | Desktop editor (also the Windows version) |
| `assets/remote.html` | Phone remote at `/remote` |
| `assets/login.html`, `assets/qr.js`, `assets/manifest.webmanifest`, `assets/dsp4x4-editor.svg` | PIN page, QR codes, home-screen app, icon |
| `packaging/` | `build-deb.sh`, `build-windows.sh`, udev rule, desktop file, systemd user service |
| `PROTOCOL.md` | Everything known about the DSP's protocol |
| `tests/` | DSP simulator and browser tests (see below) |

The pages are compiled into the binary. `web.rs` replaces `/*@CORE@*/` with `core.js`,
`/*@QR@*/` with `qr.js` and `@VERSION@` with the Cargo version. `build-windows.sh` does
the same to make the single standalone `dsp4x4-editor.html` for Windows.

## Build

Rust 1.75 or newer, no crate dependencies.

```
cargo test
cargo build --release
./packaging/build-deb.sh        # dist/dsp4x4-editor_<version>-1_<arch>.deb (needs dpkg-deb)
./packaging/build-windows.sh    # dist/dsp4x4-editor-<version>-windows.zip (needs python3)
```

After changing the version in `Cargo.toml`, run `cargo generate-lockfile --offline` once
(the build scripts use `--locked`), and update the changelog line in `build-deb.sh` and the
install line in `README.md`.

## Adding a DSP command

1. `src/proto.rs`: add a `cmd::` constant and a `Command` variant; fill in `validate`,
   `cmd_byte`, `payload` and `describe`; add a test with the expected frame.
2. `src/params.rs`: parse it from `key=value` pairs; add a test.
3. `assets/core.js`: add the same case to `P.build` (the Windows page builds frames in
   the browser) and, if it's part of the saved settings, to `C`, `allCommands` and `defaults`.
4. Add the controls to `ui.html` and `remote.html`.
5. Document it in `PROTOCOL.md` and the CLI help in `main.rs`.

Frames: `10 02 00 <id> <len> <cmd> <data…> 10 03 <xor of all previous bytes>`, where
`len` = data length + 1. The DSP answers every request; the editor waits for the reply.

## How some features work

- **Compare A–E and the shared session:** the five slots, their names and the test signal
  state are one JSON object (`CMP`) saved in the browser and, with the Linux editor, on the
  server (`/api/shared`), which phones and other computers poll every second.
- **Test signal (command `0x39`):** source 0 = analog input, 1 = pink, 2 = white, 3 = sine
  (frequency index 0–30). The generator has no level, so its volume works as a master on
  Out1–Out4: every output level sent while it plays is `volume + fader` (`genAdjust` in
  `core.js`, applied in `dispatch` in `ui.html` and `apiSend` in `remote.html`). Stopping it
  sends the plain fader levels.
- **EQ reset:** `onDoubleTap` in `core.js`; a band resets to `flatBand(b)`.
- **REW import:** `parseRew` / `applyRew` in `core.js` read REW's filter text file
  (`Filter N: ON PK Fc … Hz Gain … dB Q …`); used by `importRew` in `ui.html` and the
  EQ card in `remote.html`. Types: PK/MODAL → Peak, LS/LSC → Low Shelf, HS/HSC → High Shelf,
  HP/HPQ → Low Cut, LP/LPQ → High Cut; others are skipped. At most 7 filters are used.

## Tests

`tests/dspsim.py` is a DSP simulator on a pseudo-terminal; the editor talks to it as
`usb:/dev/pts/N`. The other scripts drive the pages in Chromium with Playwright
(`pip install playwright`; some also need `numpy` and `opencv-python`). Run them from the
project root with an existing scratch folder and the binary:

```
python3 tests/gen2_test.py /tmp/dsptest target/release/dsp4x4-editor   # test signal + faders
python3 tests/gen_test.py  /tmp/dsptest target/release/dsp4x4-editor   # test signal, EQ reset, About
python3 tests/phone_full.py /tmp/dsptest target/release/dsp4x4-editor  # phone remote, all controls
python3 tests/rew_test.py  /tmp/dsptest target/release/dsp4x4-editor   # REW import (tests/example_rew.txt)
```

`standalone.py` and `win_gen.py` test the Windows page; copy
`dist/dsp4x4-editor-<version>-windows/dsp4x4-editor.html` to `<scratch>/win/` first.
The phone tests need a non-loopback IPv4 address on the machine.

The editor is tested and working on a real t.racks DSP 4x4 Mini. After changing the
protocol, also check it on the unit (amplifiers down at first) and look at the Activity log
for the frames sent.

## Not possible / out of scope

- Mute and per-band EQ bypass can't be read back from the DSP.
- The DSP's firmware is not modified by this project.
